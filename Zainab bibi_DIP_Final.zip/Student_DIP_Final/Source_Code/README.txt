Digital Image Processing - Final Take-Home Examination
Enhancement of Degraded Historical Document Images for Binarization

HOW TO RUN (from this Source_Code/ folder)
--------------------------------------------
Requires: Python 3, numpy, Pillow, matplotlib
   pip install numpy pillow matplotlib

1. python dip_system.py
   -> Runs the full pipeline (Wiener -> CLAHE -> LBP texture ->
      Retinex -> Sauvola -> morphology) on every image in data/,
      saves intermediate + final outputs under results/<sample>/,
      and prints MSE / PSNR / SSIM for each. Takes a few minutes
      (pure-Python pixel loops, by design, per assignment rules).

2. python failure_cases.py
   -> Runs the two stress tests (extreme noise, extreme illumination)
      on sample1.png, saves outputs under results/failure_noise/ and
      results/failure_illumination/, prints MSE/PSNR/SSIM.

3. python make_figures.py
   -> Regenerates the comparison grid, metrics bar chart, and failure
      grid figures (used in Technical_Report.pdf) into figures/.
      Run AFTER steps 1 and 2.

FILES
-----
dip_system.py    - Core engine. Every filter / threshold / morphological
                    operation is implemented from scratch using explicit
                    pixel loops or manually-derived local-window
                    statistics (Wiener filter, CLAHE, LBP, Retinex,
                    Sauvola threshold, erosion/dilation/opening, MSE,
                    PSNR, SSIM). No high-level toolbox shortcuts
                    (no cv2.fastNlMeans, skimage.filters.threshold_sauvola,
                    cv2.createCLAHE, scipy.signal.wiener, etc.) are used
                    for any core engineering step.
failure_cases.py  - Stress tests pushing the pipeline past its operating
                    envelope (Section 6 of the report).
make_figures.py   - Builds the report's comparison/metrics/failure figures.
data/             - The four baseline test images used throughout
                    (sample1.png, sample2.jpg, sample3.png, sample4.png).
                    Included so the pipeline runs immediately on extraction.

REFERENCE PAPER
----------------
Naik, Y., Shashidhara B., and Vidyasagar K. B. (2024). "Enhancement of
Degraded Historical Document Images for Binarization." Journal of
Electrical Systems, 20-03: 4779-4796.
