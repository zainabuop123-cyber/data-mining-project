"""
utils.py
--------
Small, generic helper functions shared across the project.
Nothing in this file knows about Streamlit, so it can be unit-tested
in isolation.
"""

import logging
import os
import re
import sys
from datetime import datetime

import config


# ----------------------------------------------------------------------
# Logging
# ----------------------------------------------------------------------
def get_logger(name: str = "ai_data_profiler") -> logging.Logger:
    """Return a configured logger that prints to stdout."""
    logger = logging.getLogger(name)
    if not logger.handlers:  # avoid duplicate handlers on Streamlit re-runs
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


logger = get_logger()


# ----------------------------------------------------------------------
# Filesystem helpers
# ----------------------------------------------------------------------
def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def timestamp() -> str:
    """Return a filesystem-safe timestamp string."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def safe_filename(name: str) -> str:
    """Strip characters that are unsafe for filenames."""
    name = name.strip().replace(" ", "_")
    return re.sub(r"[^A-Za-z0-9_.\-]", "", name)


def get_extension(filename: str) -> str:
    return os.path.splitext(filename)[1].lower()


def human_readable_size(num_bytes: float) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if num_bytes < 1024:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.1f} TB"


# ----------------------------------------------------------------------
# Column name standardization
# ----------------------------------------------------------------------
def standardize_column_name(col: str) -> str:
    """
    Convert a column name into a clean, consistent snake_case form:
    "  First Name!! " -> "first_name"
    """
    col = str(col).strip().lower()
    col = re.sub(r"[^\w\s]", "", col)   # remove punctuation/symbols
    col = re.sub(r"\s+", "_", col)      # spaces -> underscore
    col = re.sub(r"_+", "_", col)       # collapse multiple underscores
    col = col.strip("_")
    return col if col else "unnamed_column"


# ----------------------------------------------------------------------
# Simple regex-based detectors reused by profiler & cleaner
# ----------------------------------------------------------------------
DATE_LIKE_PATTERN = re.compile(
    r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}$"
    r"|^\d{1,2}[-/]\d{1,2}[-/]\d{2,4}$"
    r"|^\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4}$"
    r"|^[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{2,4}$"
)


def looks_like_date(value: str) -> bool:
    if not isinstance(value, str):
        return False
    return bool(DATE_LIKE_PATTERN.match(value.strip()))


def has_leading_trailing_whitespace(value) -> bool:
    if not isinstance(value, str):
        return False
    return value != value.strip()
