"""
data_cleaner.py
----------------
Implements step 5 of the agent workflow: "Perform appropriate cleaning".

The DataCleaner class takes a raw DataFrame and returns a cleaned
DataFrame plus a detailed, ordered log of every action it took
(so nothing happens silently -- this log becomes part of the audit
trail requested in the project spec).
"""

from datetime import datetime

import numpy as np
import pandas as pd

import config
from utils import get_logger, standardize_column_name, looks_like_date

logger = get_logger(__name__)


class DataCleaner:
    def __init__(self, df: pd.DataFrame):
        self.original_df = df.copy()
        self.df = df.copy()
        self.log = []  # list of dicts describing each action taken

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def clean(self) -> tuple:
        """Run the full cleaning pipeline. Returns (cleaned_df, log)."""
        self._standardize_column_names()
        self._trim_whitespace()
        self._remove_duplicates()
        self._fix_data_types()
        self._standardize_dates()
        self._handle_missing_values()
        self._flag_anomalies()
        return self.df, self.log

    # ------------------------------------------------------------------
    # Individual cleaning steps
    # ------------------------------------------------------------------
    def _standardize_column_names(self):
        old_cols = list(self.df.columns)
        new_cols = [standardize_column_name(c) for c in old_cols]

        # de-duplicate any resulting name clashes
        seen = {}
        final_cols = []
        for c in new_cols:
            if c in seen:
                seen[c] += 1
                final_cols.append(f"{c}_{seen[c]}")
            else:
                seen[c] = 0
                final_cols.append(c)

        renamed = {o: n for o, n in zip(old_cols, final_cols) if o != n}
        self.df.columns = final_cols
        if renamed:
            self._add_log(
                action="standardize_column_names",
                description="Converted column names to a consistent snake_case format.",
                details=renamed,
                rows_affected=0,
            )

    def _trim_whitespace(self):
        affected_cols = []
        total_cells_changed = 0
        for col in self.df.select_dtypes(include=["object"]).columns:
            before = self.df[col]
            after = before.apply(lambda v: v.strip() if isinstance(v, str) else v)
            changed = (before != after) & before.notna()
            n_changed = int(changed.sum())
            if n_changed > 0:
                self.df[col] = after
                affected_cols.append(col)
                total_cells_changed += n_changed
        if affected_cols:
            self._add_log(
                action="trim_whitespace",
                description="Removed leading/trailing whitespace from text columns.",
                details={"columns": affected_cols},
                rows_affected=total_cells_changed,
            )

    def _remove_duplicates(self):
        before = len(self.df)
        self.df = self.df.drop_duplicates(keep="first").reset_index(drop=True)
        removed = before - len(self.df)
        if removed > 0:
            self._add_log(
                action="remove_duplicates",
                description="Removed exact duplicate rows, keeping the first occurrence.",
                details={},
                rows_affected=removed,
            )

    def _fix_data_types(self):
        """
        Attempt to convert object columns that are 'mostly numeric' into
        real numeric dtypes. Non-convertible cells become NaN and are
        handled later by missing-value imputation.
        """
        for col in self.df.select_dtypes(include=["object"]).columns:
            series = self.df[col]
            non_null = series.dropna().astype(str).str.replace(",", "", regex=False)
            if len(non_null) == 0:
                continue
            numeric_like_ratio = non_null.str.match(r"^-?\d+(\.\d+)?$").mean()
            if numeric_like_ratio >= 0.8:
                converted = pd.to_numeric(
                    series.astype(str).str.replace(",", "", regex=False), errors="coerce"
                )
                newly_invalid = int(converted.isna().sum() - series.isna().sum())
                self.df[col] = converted
                self._add_log(
                    action="fix_data_type",
                    description=f"Converted column '{col}' from text to numeric.",
                    details={
                        "column": col,
                        "values_that_failed_conversion": max(newly_invalid, 0),
                    },
                    rows_affected=int((~converted.isna()).sum()),
                )

    def _standardize_dates(self):
        """Detect date-like object columns and convert to a standard format string."""
        for col in self.df.select_dtypes(include=["object"]).columns:
            series = self.df[col].dropna().astype(str)
            if len(series) == 0:
                continue
            ratio = series.apply(looks_like_date).mean()
            if ratio < 0.6:
                continue

            parsed = pd.to_datetime(self.df[col], errors="coerce")
            success_ratio = parsed.notna().mean()
            if success_ratio >= 0.6:
                formatted = parsed.dt.strftime(config.STANDARD_DATE_FORMAT)
                # Keep original where parsing failed instead of destroying data
                formatted = formatted.where(parsed.notna(), self.df[col])
                n_converted = int(parsed.notna().sum())
                self.df[col] = formatted
                self._add_log(
                    action="standardize_dates",
                    description=(
                        f"Standardized column '{col}' to {config.STANDARD_DATE_FORMAT} format."
                    ),
                    details={"column": col, "format": config.STANDARD_DATE_FORMAT},
                    rows_affected=n_converted,
                )

    def _handle_missing_values(self):
        """
        Sensible defaults:
          - Numeric columns  -> fill with median
          - Text columns     -> fill with mode, or 'Unknown' if no mode
          - Columns with >HIGH_MISSING_THRESHOLD_PCT missing -> flagged, NOT auto-filled
        """
        total_rows = len(self.df) if len(self.df) else 1
        for col in self.df.columns:
            missing_count = int(self.df[col].isna().sum())
            if missing_count == 0:
                continue

            missing_pct = (missing_count / total_rows) * 100
            if missing_pct > config.HIGH_MISSING_THRESHOLD_PCT:
                self._add_log(
                    action="flag_high_missingness",
                    description=(
                        f"Column '{col}' has {missing_pct:.1f}% missing values — "
                        "left as-is rather than auto-imputed since more than "
                        f"{config.HIGH_MISSING_THRESHOLD_PCT}% of the data is missing."
                    ),
                    details={"column": col, "missing_percent": round(missing_pct, 2)},
                    rows_affected=missing_count,
                )
                continue

            if pd.api.types.is_numeric_dtype(self.df[col]):
                fill_value = self.df[col].median()
                method = "median"
            else:
                mode_series = self.df[col].mode(dropna=True)
                fill_value = mode_series.iloc[0] if len(mode_series) > 0 else "Unknown"
                method = "mode" if len(mode_series) > 0 else "constant ('Unknown')"

            self.df[col] = self.df[col].fillna(fill_value)
            self._add_log(
                action="handle_missing_values",
                description=f"Filled missing values in '{col}' using {method}.",
                details={"column": col, "method": method, "fill_value": str(fill_value)},
                rows_affected=missing_count,
            )

    def _flag_anomalies(self):
        """
        Add a boolean flag column for rows containing numeric outliers
        (IQR method), rather than deleting data the user may still need.
        """
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) == 0:
            return

        anomaly_mask = pd.Series(False, index=self.df.index)
        flagged_columns = []
        for col in numeric_cols:
            series = self.df[col].dropna()
            if len(series) < 4:
                continue
            q1, q3 = series.quantile(0.25), series.quantile(0.75)
            iqr = q3 - q1
            if iqr == 0:
                continue
            lower = q1 - config.IQR_MULTIPLIER * iqr
            upper = q3 + config.IQR_MULTIPLIER * iqr
            col_mask = (self.df[col] < lower) | (self.df[col] > upper)
            if col_mask.any():
                flagged_columns.append(col)
            anomaly_mask = anomaly_mask | col_mask.fillna(False)

        if anomaly_mask.any():
            self.df["anomaly_flag"] = anomaly_mask
            self._add_log(
                action="flag_anomalies",
                description=(
                    "Added an 'anomaly_flag' column marking rows with statistical "
                    f"outliers (IQR method) in columns: {', '.join(flagged_columns)}."
                ),
                details={"columns_checked": flagged_columns},
                rows_affected=int(anomaly_mask.sum()),
            )

    # ------------------------------------------------------------------
    # Logging helper
    # ------------------------------------------------------------------
    def _add_log(self, action: str, description: str, details: dict, rows_affected: int):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "description": description,
            "details": details,
            "records_affected": int(rows_affected),
        }
        self.log.append(entry)
        logger.info("CLEANING STEP: %s | %s", action, description)


def build_markdown_summary(log: list, before_shape: tuple, after_shape: tuple) -> str:
    lines = ["# Cleaning Summary Report", ""]
    lines.append(f"**Rows before:** {before_shape[0]}  |  **Rows after:** {after_shape[0]}")
    lines.append(f"**Columns before:** {before_shape[1]}  |  **Columns after:** {after_shape[1]}")
    lines.append("")
    lines.append("## Actions Performed")
    if not log:
        lines.append("- No cleaning actions were necessary; data was already clean.")
    for i, entry in enumerate(log, start=1):
        lines.append(
            f"{i}. **{entry['action']}** — {entry['description']} "
            f"(records affected: {entry['records_affected']})"
        )
    return "\n".join(lines)
