"""
Basic unit tests for data_cleaner.py
Run with:  python -m pytest tests/  (from the project root)
"""

import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_cleaner import DataCleaner


def make_messy_df():
    return pd.DataFrame({
        " Customer ID ": [1, 2, 3, 3],
        "First Name": [" Alice", "Bob ", "Charlie", "Charlie"],
        "Amount": ["10.5", "20", None, None],
        "Signup Date": ["2023-01-01", "01/02/2023", "2023-01-03", "2023-01-03"],
    })


def test_column_names_standardized():
    df = make_messy_df()
    cleaned, log = DataCleaner(df).clean()
    assert all(c == c.lower() and " " not in c for c in cleaned.columns)


def test_duplicates_removed():
    df = make_messy_df()
    cleaned, log = DataCleaner(df).clean()
    assert cleaned.duplicated().sum() == 0
    assert len(cleaned) == 3  # one duplicate row removed


def test_whitespace_trimmed():
    df = make_messy_df()
    cleaned, log = DataCleaner(df).clean()
    name_col = [c for c in cleaned.columns if "first_name" in c][0]
    assert all(not str(v).startswith(" ") and not str(v).endswith(" ") for v in cleaned[name_col])


def test_missing_values_filled():
    df = make_messy_df()
    cleaned, log = DataCleaner(df).clean()
    amount_col = [c for c in cleaned.columns if "amount" in c][0]
    assert cleaned[amount_col].isna().sum() == 0


def test_log_is_populated():
    df = make_messy_df()
    cleaned, log = DataCleaner(df).clean()
    assert isinstance(log, list)
    assert len(log) > 0
    for entry in log:
        assert "action" in entry
        assert "records_affected" in entry


if __name__ == "__main__":
    test_column_names_standardized()
    test_duplicates_removed()
    test_whitespace_trimmed()
    test_missing_values_filled()
    test_log_is_populated()
    print("All data_cleaner tests passed!")
