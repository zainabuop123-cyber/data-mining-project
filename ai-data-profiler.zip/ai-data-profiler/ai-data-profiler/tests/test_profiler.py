"""
Basic unit tests for data_profiler.py
Run with:  python -m pytest tests/  (from the project root)
"""

import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_profiler import DataProfiler


def make_sample_df():
    return pd.DataFrame({
        "id": [1, 2, 3, 4, 4],
        "name": [" Alice", "Bob ", "Charlie", "Dana", "Dana"],
        "amount": [10.5, 20.0, None, 15.5, 15.5],
        "signup_date": ["2023-01-01", "2023-01-02", "01/03/2023", "2023-01-02", "2023-01-02"],
    })


def test_shape_detection():
    df = make_sample_df()
    profile = DataProfiler(df).generate_report()
    assert profile["shape"]["rows"] == 5
    assert profile["shape"]["columns"] == 4


def test_missing_values_detected():
    df = make_sample_df()
    profile = DataProfiler(df).generate_report()
    assert profile["missing_values"]["amount"]["missing_count"] == 1


def test_duplicate_detection():
    df = make_sample_df()
    profile = DataProfiler(df).generate_report()
    assert profile["duplicates"]["duplicate_row_count"] >= 1


def test_whitespace_detection():
    df = make_sample_df()
    profile = DataProfiler(df).generate_report()
    assert profile["whitespace_issues"].get("name", 0) >= 1


def test_date_column_detection():
    df = make_sample_df()
    profile = DataProfiler(df).generate_report()
    detected_cols = [d["column"] for d in profile["date_columns_detected"]]
    assert "signup_date" in detected_cols


if __name__ == "__main__":
    test_shape_detection()
    test_missing_values_detected()
    test_duplicate_detection()
    test_whitespace_detection()
    test_date_column_detection()
    print("All data_profiler tests passed!")
