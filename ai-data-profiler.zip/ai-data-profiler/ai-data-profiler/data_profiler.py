"""
data_profiler.py
-----------------
Implements steps 3 & 4 of the agent workflow:
  "Create a profiling report" and "Identify data-quality problems".

Everything here is read-only: profiling never modifies the DataFrame
that is passed in. That job belongs to data_cleaner.py.
"""

from datetime import datetime

import numpy as np
import pandas as pd

import config
from utils import get_logger, has_leading_trailing_whitespace, looks_like_date

logger = get_logger(__name__)


class DataProfiler:
    """Builds a structured profiling report for a pandas DataFrame."""

    def __init__(self, df: pd.DataFrame):
        self.df = df

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def generate_report(self) -> dict:
        df = self.df
        report = {
            "generated_at": datetime.now().isoformat(),
            "shape": {"rows": int(df.shape[0]), "columns": int(df.shape[1])},
            "columns": self._column_overview(),
            "missing_values": self._missing_values(),
            "duplicates": self._duplicate_summary(),
            "whitespace_issues": self._whitespace_issues(),
            "date_columns_detected": self._date_columns(),
            "inconsistent_dtype_columns": self._inconsistent_dtypes(),
            "numeric_anomalies": self._numeric_anomalies(),
            "memory_usage_bytes": int(df.memory_usage(deep=True).sum()),
        }
        report["quality_issue_count"] = self._count_issues(report)
        return report

    # ------------------------------------------------------------------
    # Section builders
    # ------------------------------------------------------------------
    def _column_overview(self) -> list:
        df = self.df
        overview = []
        for col in df.columns:
            series = df[col]
            overview.append({
                "name": col,
                "dtype": str(series.dtype),
                "unique_values": int(series.nunique(dropna=True)),
                "sample_values": [
                    self._jsonable(v) for v in series.dropna().unique()[:5]
                ],
            })
        return overview

    def _missing_values(self) -> dict:
        df = self.df
        total_rows = len(df) if len(df) else 1
        missing = {}
        for col in df.columns:
            count = int(df[col].isna().sum())
            pct = round((count / total_rows) * 100, 2)
            missing[col] = {"missing_count": count, "missing_percent": pct}
        return missing

    def _duplicate_summary(self) -> dict:
        df = self.df
        dup_mask = df.duplicated(keep="first")
        return {
            "duplicate_row_count": int(dup_mask.sum()),
            "duplicate_percent": round(
                (dup_mask.sum() / len(df) * 100) if len(df) else 0, 2
            ),
        }

    def _whitespace_issues(self) -> dict:
        df = self.df
        issues = {}
        for col in df.select_dtypes(include=["object"]).columns:
            flagged = df[col].apply(has_leading_trailing_whitespace)
            count = int(flagged.sum())
            if count > 0:
                issues[col] = count
        return issues

    def _date_columns(self) -> list:
        """Detect object columns where most non-null values look like dates."""
        df = self.df
        detected = []
        for col in df.select_dtypes(include=["object"]).columns:
            series = df[col].dropna().astype(str)
            if len(series) == 0:
                continue
            matches = series.apply(looks_like_date)
            ratio = matches.mean()
            if ratio >= 0.6:  # at least 60% look like dates
                detected.append({"column": col, "confidence_ratio": round(float(ratio), 2)})
        return detected

    def _inconsistent_dtypes(self) -> list:
        """
        Flag object columns that contain a mix of types, e.g. a column
        that is 'numeric-looking' for 90% of rows but has stray text.
        """
        df = self.df
        flagged = []
        for col in df.select_dtypes(include=["object"]).columns:
            series = df[col].dropna().astype(str)
            if len(series) == 0:
                continue
            numeric_like = series.str.replace(",", "", regex=False).str.match(
                r"^-?\d+(\.\d+)?$"
            )
            ratio_numeric = numeric_like.mean()
            if 0 < ratio_numeric < 0.95:
                flagged.append({
                    "column": col,
                    "issue": "mixed numeric and non-numeric values",
                    "numeric_like_ratio": round(float(ratio_numeric), 2),
                })
        return flagged

    def _numeric_anomalies(self) -> dict:
        """Use the IQR method to flag potential outliers in numeric columns."""
        df = self.df
        anomalies = {}
        for col in df.select_dtypes(include=[np.number]).columns:
            series = df[col].dropna()
            if len(series) < 4:
                continue
            q1, q3 = series.quantile(0.25), series.quantile(0.75)
            iqr = q3 - q1
            if iqr == 0:
                continue
            lower = q1 - config.IQR_MULTIPLIER * iqr
            upper = q3 + config.IQR_MULTIPLIER * iqr
            outliers = series[(series < lower) | (series > upper)]
            if len(outliers) > 0:
                anomalies[col] = {
                    "outlier_count": int(len(outliers)),
                    "lower_bound": round(float(lower), 4),
                    "upper_bound": round(float(upper), 4),
                    "example_values": [self._jsonable(v) for v in outliers.head(5)],
                }
        return anomalies

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _jsonable(value):
        """Convert numpy/pandas scalar types into plain python types for JSON."""
        if isinstance(value, (np.integer,)):
            return int(value)
        if isinstance(value, (np.floating,)):
            return float(value)
        if isinstance(value, (pd.Timestamp,)):
            return str(value)
        return value

    @staticmethod
    def _count_issues(report: dict) -> int:
        count = 0
        count += report["duplicates"]["duplicate_row_count"] > 0
        count += sum(1 for m in report["missing_values"].values() if m["missing_count"] > 0)
        count += len(report["whitespace_issues"])
        count += len(report["inconsistent_dtype_columns"])
        count += len(report["numeric_anomalies"])
        return int(count)


def build_markdown_report(profile: dict, filename: str) -> str:
    """Turn the profile dict into a readable Markdown report."""
    lines = [f"# Data Profiling Report", f"**File:** {filename}",
             f"**Generated:** {profile['generated_at']}", ""]

    lines.append("## Dataset Shape")
    lines.append(f"- Rows: {profile['shape']['rows']}")
    lines.append(f"- Columns: {profile['shape']['columns']}")
    lines.append("")

    lines.append("## Columns")
    for col in profile["columns"]:
        lines.append(f"- **{col['name']}** (`{col['dtype']}`) — "
                      f"{col['unique_values']} unique values")
    lines.append("")

    lines.append("## Missing Values")
    any_missing = False
    for col, info in profile["missing_values"].items():
        if info["missing_count"] > 0:
            any_missing = True
            lines.append(f"- {col}: {info['missing_count']} missing "
                          f"({info['missing_percent']}%)")
    if not any_missing:
        lines.append("- No missing values detected.")
    lines.append("")

    lines.append("## Duplicates")
    lines.append(f"- Duplicate rows: {profile['duplicates']['duplicate_row_count']} "
                  f"({profile['duplicates']['duplicate_percent']}%)")
    lines.append("")

    lines.append("## Whitespace Issues")
    if profile["whitespace_issues"]:
        for col, count in profile["whitespace_issues"].items():
            lines.append(f"- {col}: {count} values with leading/trailing whitespace")
    else:
        lines.append("- None detected.")
    lines.append("")

    lines.append("## Detected Date Columns")
    if profile["date_columns_detected"]:
        for item in profile["date_columns_detected"]:
            lines.append(f"- {item['column']} (confidence: {item['confidence_ratio']})")
    else:
        lines.append("- None detected.")
    lines.append("")

    lines.append("## Inconsistent Data-Type Columns")
    if profile["inconsistent_dtype_columns"]:
        for item in profile["inconsistent_dtype_columns"]:
            lines.append(f"- {item['column']}: {item['issue']} "
                          f"(numeric-like ratio: {item['numeric_like_ratio']})")
    else:
        lines.append("- None detected.")
    lines.append("")

    lines.append("## Numeric Anomalies (IQR method)")
    if profile["numeric_anomalies"]:
        for col, info in profile["numeric_anomalies"].items():
            lines.append(f"- {col}: {info['outlier_count']} potential outliers "
                          f"(expected range {info['lower_bound']} to {info['upper_bound']})")
    else:
        lines.append("- None detected.")
    lines.append("")

    lines.append(f"## Total Quality Issues Flagged: {profile['quality_issue_count']}")

    return "\n".join(lines)
