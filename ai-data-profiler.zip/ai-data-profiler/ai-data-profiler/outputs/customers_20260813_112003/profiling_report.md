# Data Profiling Report
**File:** customers.csv
**Generated:** 2026-08-13T11:20:03.842509

## Dataset Shape
- Rows: 4546
- Columns: 8

## Columns
- **CustomerID** (`int64`) — 4546 unique values
- **CustomerName** (`object`) — 1500 unique values
- **Email** (`object`) — 3764 unique values
- **Phone** (`object`) — 3400 unique values
- **BirthDate** (`object`) — 3972 unique values
- **SignupDate** (`object`) — 1819 unique values
- **GeographyID** (`int64`) — 15 unique values
- **CustomerSegment** (`object`) — 4 unique values

## Missing Values
- Email: 703 missing (15.46%)
- Phone: 1129 missing (24.84%)

## Duplicates
- Duplicate rows: 0 (0.0%)

## Whitespace Issues
- None detected.

## Detected Date Columns
- BirthDate (confidence: 1.0)
- SignupDate (confidence: 1.0)

## Inconsistent Data-Type Columns
- Phone: mixed numeric and non-numeric values (numeric-like ratio: 0.33)

## Numeric Anomalies (IQR method)
- CustomerID: 46 potential outliers (expected range -1271.5 to 7818.5)

## Total Quality Issues Flagged: 4