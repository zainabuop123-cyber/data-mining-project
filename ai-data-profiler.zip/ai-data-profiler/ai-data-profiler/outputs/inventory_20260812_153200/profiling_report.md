# Data Profiling Report
**File:** inventory.csv
**Generated:** 2026-08-12T15:32:00.906118

## Dataset Shape
- Rows: 1560
- Columns: 7

## Columns
- **InventoryID** (`int64`) — 1560 unique values
- **SnapshotDate** (`object`) — 26 unique values
- **ProductID** (`int64`) — 15 unique values
- **StoreID** (`int64`) — 4 unique values
- **StockOnHand** (`int64`) — 93 unique values
- **ReorderPoint** (`float64`) — 3 unique values
- **SafetyStock** (`int64`) — 3 unique values

## Missing Values
- ReorderPoint: 52 missing (3.33%)

## Duplicates
- Duplicate rows: 0 (0.0%)

## Whitespace Issues
- None detected.

## Detected Date Columns
- SnapshotDate (confidence: 1.0)

## Inconsistent Data-Type Columns
- None detected.

## Numeric Anomalies (IQR method)
- None detected.

## Total Quality Issues Flagged: 1