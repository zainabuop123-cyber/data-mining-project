"""
file_processor.py
------------------
Responsible for step 1 of the agent workflow: "Inspect the uploaded file".

Given a path to an uploaded file, this module:
  1. Detects the file type (by extension, with a content sniff as backup).
  2. Loads/extracts tabular data where possible (CSV, XLSX, TXT).
  3. Delegates PDF/image extraction to ocr_processor.py.

Every public function returns a plain dictionary so the rest of the app
never has to guess about return types.
"""

import io
import os

import pandas as pd

import config
from utils import get_extension, get_logger

logger = get_logger(__name__)


def detect_file_type(filename: str) -> str:
    """Return a simple category string based on file extension."""
    ext = get_extension(filename)
    if ext in config.SUPPORTED_TABULAR_EXTENSIONS:
        return "tabular"
    if ext in config.SUPPORTED_TEXT_EXTENSIONS:
        return "text"
    if ext in config.SUPPORTED_PDF_EXTENSIONS:
        return "pdf"
    if ext in config.SUPPORTED_IMAGE_EXTENSIONS:
        return "image"
    return "unsupported"


def load_tabular_file(file_path: str) -> dict:
    """Load a CSV/TSV/XLSX/XLS file into a pandas DataFrame."""
    ext = get_extension(file_path)
    try:
        if ext == ".csv":
            df = _read_csv_with_fallback(file_path, sep=",")
        elif ext == ".tsv":
            df = _read_csv_with_fallback(file_path, sep="\t")
        elif ext in (".xlsx", ".xls"):
            df = pd.read_excel(file_path)
        else:
            return {"success": False, "message": f"Unsupported tabular extension: {ext}"}

        return {
            "success": True,
            "dataframe": df,
            "message": f"Loaded {df.shape[0]} rows x {df.shape[1]} columns.",
        }
    except Exception as exc:  # noqa: BLE001
        logger.exception("Failed to load tabular file")
        return {"success": False, "message": f"Could not read file: {exc}"}


def _read_csv_with_fallback(file_path: str, sep: str) -> pd.DataFrame:
    """Try a couple of encodings so beginners don't hit cryptic errors."""
    encodings = ["utf-8", "utf-8-sig", "latin1", "cp1252"]
    last_error = None
    for enc in encodings:
        try:
            return pd.read_csv(file_path, sep=sep, encoding=enc)
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            continue
    raise last_error


def load_text_file(file_path: str) -> dict:
    """
    Load a .txt file. We try to interpret it as delimited data first
    (comma, tab, semicolon, pipe). If that fails, we return the raw text.
    """
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            raw_text = f.read()

        for sep in [",", "\t", ";", "|"]:
            try:
                df = pd.read_csv(io.StringIO(raw_text), sep=sep)
                if df.shape[1] > 1:  # a real delimiter should create >1 column
                    return {
                        "success": True,
                        "dataframe": df,
                        "raw_text": raw_text,
                        "message": f"Interpreted TXT as delimited data using '{sep}' separator.",
                    }
            except Exception:  # noqa: BLE001
                continue

        # Could not find tabular structure -> return raw text only
        return {
            "success": True,
            "dataframe": None,
            "raw_text": raw_text,
            "message": "TXT file loaded as plain text (no consistent delimiter found).",
        }
    except Exception as exc:  # noqa: BLE001
        logger.exception("Failed to load text file")
        return {"success": False, "message": f"Could not read TXT file: {exc}"}


def process_file(file_path: str, original_filename: str) -> dict:
    """
    Main entry point used by the agent.
    Returns a dict with keys:
        file_type, success, dataframe, raw_text, message, extraction_method
    """
    file_type = detect_file_type(original_filename)
    result = {
        "file_type": file_type,
        "dataframe": None,
        "raw_text": None,
        "extraction_method": None,
        "success": False,
        "message": "",
    }

    if file_type == "unsupported":
        result["message"] = (
            f"'{get_extension(original_filename)}' is not a supported file type. "
            f"Supported types: {', '.join(config.ALL_SUPPORTED_EXTENSIONS)}"
        )
        return result

    if file_type == "tabular":
        loaded = load_tabular_file(file_path)
        result.update(loaded)
        result["extraction_method"] = "direct_load"
        return result

    if file_type == "text":
        loaded = load_text_file(file_path)
        result.update(loaded)
        result["extraction_method"] = "delimiter_sniff"
        return result

    if file_type in ("pdf", "image"):
        # Delegate to the OCR / extraction module (kept separate so this
        # file stays lightweight and doesn't need OCR libraries loaded
        # unless actually required).
        import ocr_processor

        extracted = ocr_processor.extract_from_file(file_path, file_type)
        result.update(extracted)
        return result

    return result
