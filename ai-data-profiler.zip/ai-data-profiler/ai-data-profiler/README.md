# 🧹 AI Data Profiler & Automated Data Cleaner

A beginner-friendly Streamlit application that automatically **profiles**,
**cleans**, and **audits** messy data files — CSV, Excel, PDF, images, and
plain text — using an AI-agent-style workflow.

---

## ✨ Features

- **Automatic file-type detection** for CSV, XLSX/XLS, TSV, TXT, PDF, PNG, JPG, JPEG.
- **Table/text extraction** from PDFs (native + scanned/OCR) and images (OCR).
- **Full data profiling**: shape, dtypes, missing values, uniqueness,
  duplicates, whitespace issues, date-format detection, inconsistent
  dtype detection, and numeric anomaly (outlier) detection.
- **Automated cleaning**: duplicate removal, whitespace trimming, column-name
  standardization, dtype fixing, date standardization, missing-value
  imputation, and anomaly flagging — with **every action logged**.
- **AI Agent workflow** with live step-by-step progress in the UI.
- **Optional AI narrative summaries** via the Anthropic API (works fine
  without a key too — falls back to a rule-based summary).
- **Downloadable outputs**: cleaned CSV/XLSX, JSON audit log, profiling
  report, cleaning summary, and extracted raw data for PDFs/images.

---

## 📁 Project Structure

```
ai-data-profiler/
├── app.py               # Streamlit UI (entry point)
├── agent.py              # AI agent orchestrator (the 8-step workflow)
├── file_processor.py      # File type detection + CSV/XLSX/TXT loading
├── ocr_processor.py       # PDF & image extraction (native + OCR)
├── data_profiler.py       # Profiling & data-quality issue detection
├── data_cleaner.py        # Automated cleaning pipeline + action log
├── audit_logger.py        # JSON audit log builder + validation checks
├── config.py               # All configuration in one place
├── utils.py                # Shared helper functions
├── requirements.txt
├── .env.example
├── sample_data/            # Example messy CSV to try the app with
├── outputs/                 # Generated reports/cleaned files are saved here
└── tests/                    # Unit tests for profiler & cleaner
```

---

## 🚀 Quick Start

### 1. Clone / copy this project and enter the folder
```bash
cd ai-data-profiler
```

### 2. (Recommended) Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate     # Windows: venv\Scripts\activate
```

### 3. Install Python dependencies
```bash
pip install -r requirements.txt
```

### 4. (Optional) Install system packages for OCR / scanned-PDF support
OCR features need Tesseract OCR and Poppler installed on your **system**
(not just Python packages):

- **macOS:** `brew install tesseract poppler`
- **Ubuntu/Debian:** `sudo apt-get install tesseract-ocr poppler-utils`
- **Windows:** install the Tesseract installer from the
  [UB-Mannheim build](https://github.com/UB-Mannheim/tesseract/wiki) and
  [poppler for Windows](https://github.com/oschwartz10612/poppler-windows),
  then add both to your PATH.

> The app still works fully for CSV/XLSX/TXT files without these — OCR is
> only needed for scanned PDFs and images.

### 5. (Optional) Configure the AI narrative
```bash
cp .env.example .env
# then edit .env and add your ANTHROPIC_API_KEY if you have one
```

### 6. Run the app
```bash
streamlit run app.py
```

Then open the URL Streamlit prints (usually `http://localhost:8501`).

---

## 🧪 Try it with the included sample data

Upload `sample_data/sample_customers.csv` — it intentionally contains
duplicate rows, missing values, inconsistent date formats, extra whitespace,
and an outlier, so you can see every feature of the app in action.

---

## 🧠 How the "AI Agent" works

`agent.py` runs a clear, 8-step pipeline every time you upload a file:

1. **Inspect** the uploaded file (detect type, attempt extraction)
2. **Understand** its structure (shape, columns, dtypes)
3. **Generate** a profiling report
4. **Identify** data-quality problems
5. **Clean** the dataset automatically
6. **Validate** the cleaned result against sanity checks
7. **Generate** a full JSON audit report
8. **Prepare** all downloadable outputs

Each step reports its status back to the Streamlit UI in real time, and
step 7 optionally calls the Anthropic API to write a short plain-English
summary of what happened (or uses a built-in rule-based summary if no API
key is configured).

---

## 🧹 Cleaning logic (sensible defaults)

| Problem                        | Action taken                                          |
|---------------------------------|--------------------------------------------------------|
| Duplicate rows                  | Removed (first occurrence kept)                        |
| Leading/trailing whitespace     | Trimmed from all text columns                           |
| Inconsistent column names        | Converted to `snake_case`                              |
| Numeric-looking text columns     | Converted to real numeric dtype                        |
| Date-looking text columns        | Standardized to `YYYY-MM-DD`                             |
| Missing numeric values           | Filled with column median                                |
| Missing text values              | Filled with column mode (or `"Unknown"`)                 |
| Columns >50% missing             | **Flagged, not auto-filled** (too little data to guess) |
| Statistical outliers (IQR)       | Flagged in a new `anomaly_flag` column (not deleted)      |

Every single action is recorded with a timestamp, description, and the
number of records affected — this becomes the JSON audit log.

---

## 📦 Downloadable Outputs

After processing, you can download:

1. **Cleaned dataset** — CSV and XLSX
2. **JSON Data Audit Log** — file metadata, before/after counts, detected
   dtypes, missing values, duplicates, anomalies, every cleaning operation,
   records affected, and final validation results
3. **Data profiling report** — Markdown
4. **Cleaning summary report** — Markdown
5. **Extracted raw data** — CSV/TXT, for PDF/image inputs

All outputs are also saved locally under `outputs/<run_id>/`.

---

## ✅ Running tests

```bash
python -m pytest tests/
```
or, without pytest installed:
```bash
python tests/test_profiler.py
python tests/test_cleaner.py
```

---

## ⚠️ Troubleshooting

- **"OCR libraries are missing"** — run `pip install pytesseract pdf2image
  pillow` and install the system packages listed in step 4 above.
- **PDF extraction returns no tables** — the app automatically falls back
  to OCR for scanned PDFs; if it's still empty, the PDF may have no
  readable text/images at all.
- **Excel download button missing** — make sure `openpyxl` installed
  correctly (`pip install openpyxl`).
- **AI narrative always shows the fallback text** — check that
  `ANTHROPIC_API_KEY` is set in your `.env` file and that the `anthropic`
  package is installed.

---

## 🏗️ Built With

Python · Streamlit · Pandas · NumPy · pdfplumber · pytesseract · pdf2image ·
Pillow · openpyxl · Anthropic API (optional)
