"""
app.py
------
Streamlit dashboard for the AI Data Profiler & Automated Data Cleaner.

Run with:
    streamlit run app.py
"""

import os
import tempfile

import pandas as pd
import streamlit as st

import config
from agent import DataAgent, AGENT_STEPS
from utils import get_logger

logger = get_logger(__name__)

st.set_page_config(page_title=config.APP_TITLE, page_icon="🧹", layout="wide")


# ----------------------------------------------------------------------
# Session state initialization
# ----------------------------------------------------------------------
if "result" not in st.session_state:
    st.session_state.result = None
if "error" not in st.session_state:
    st.session_state.error = None


# ----------------------------------------------------------------------
# Header
# ----------------------------------------------------------------------
st.title("🧹 AI Data Profiler & Automated Data Cleaner")
st.caption(
    "Upload a CSV, Excel, PDF, image, or text file. The AI agent will inspect it, "
    "profile its quality, clean it automatically, and give you downloadable reports."
)

with st.expander("ℹ️ Supported file types & what happens to them", expanded=False):
    st.markdown(
        """
        - **CSV / XLSX / XLS / TSV** — profiled and cleaned directly.
        - **TXT** — parsed as delimited data if possible, otherwise shown as raw text.
        - **PDF** — tables/text extracted with `pdfplumber`; scanned PDFs fall back to OCR.
        - **PNG / JPG / JPEG** — text extracted via OCR (`pytesseract`), and reconstructed
          into a table when the layout allows it.
        - If a file truly cannot be converted into structured data, the app will tell you
          clearly instead of guessing.
        """
    )

# ----------------------------------------------------------------------
# File uploader
# ----------------------------------------------------------------------
uploaded_file = st.file_uploader(
    "Upload a data file",
    type=[ext.lstrip(".") for ext in config.ALL_SUPPORTED_EXTENSIONS],
    help=f"Supported: {', '.join(config.ALL_SUPPORTED_EXTENSIONS)}",
)

process_clicked = st.button("🚀 Run AI Agent", type="primary", disabled=uploaded_file is None)


# ----------------------------------------------------------------------
# Run the agent
# ----------------------------------------------------------------------
def render_progress(progress_bar, status_box):
    """Returns a callback function the agent calls after each step."""
    def _callback(step_index, step_name, status):
        pct = step_index / len(AGENT_STEPS)
        progress_bar.progress(min(pct, 1.0), text=f"Step {step_index}/{len(AGENT_STEPS)}: {step_name}")
        icon = "✅" if status == "done" else ("❌" if status == "failed" else "⏳")
        status_box.markdown(f"{icon} **Step {step_index}:** {step_name}")
    return _callback


if process_clicked and uploaded_file is not None:
    st.session_state.error = None
    st.session_state.result = None

    file_ext = os.path.splitext(uploaded_file.name)[1].lower()
    if file_ext not in config.ALL_SUPPORTED_EXTENSIONS:
        st.error(
            f"'{file_ext}' is not a supported file type. "
            f"Please upload one of: {', '.join(config.ALL_SUPPORTED_EXTENSIONS)}"
        )
    else:
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=file_ext) as tmp:
                tmp.write(uploaded_file.getbuffer())
                tmp_path = tmp.name

            st.markdown("### 🤖 AI Agent Status")
            progress_bar = st.progress(0.0, text="Starting...")
            status_box = st.empty()
            log_lines = st.container()

            callback = render_progress(progress_bar, status_box)

            agent = DataAgent(progress_callback=callback)
            with st.spinner("Agent is working through the pipeline..."):
                result = agent.run(tmp_path, uploaded_file.name)

            os.unlink(tmp_path)
            st.session_state.result = result

            if not result["success"]:
                st.session_state.error = result["message"]
            else:
                st.success("Processing complete!")

        except Exception as exc:  # noqa: BLE001
            logger.exception("Unhandled error while processing file")
            st.session_state.error = (
                f"An unexpected error occurred while processing your file: {exc}"
            )


# ----------------------------------------------------------------------
# Error display
# ----------------------------------------------------------------------
if st.session_state.error:
    st.error(st.session_state.error)

# ----------------------------------------------------------------------
# Results display
# ----------------------------------------------------------------------
result = st.session_state.result

if result and result.get("success"):
    st.divider()
    st.markdown(f"## 📄 Results for `{result['original_filename']}`")
    st.info(f"**File type detected:** {result['file_type'].upper()}  |  "
            f"**Extraction method:** {result.get('extraction_method') or 'n/a'}")
    st.caption(result.get("extraction_message", ""))

    cleaned_df = result.get("cleaned_dataframe")

    if cleaned_df is None:
        # File could not be converted to a table
        st.warning(result["message"])
        raw_text = result.get("raw_text")
        if raw_text:
            st.markdown("### 📃 Extracted Raw Text")
            st.text_area("Raw extracted text", raw_text, height=300)
            st.download_button(
                "⬇️ Download extracted text",
                data=raw_text,
                file_name="extracted_text.txt",
                mime="text/plain",
            )
    else:
        tabs = st.tabs([
            "👀 Preview",
            "📊 Data Profiling",
            "⚠️ Quality Issues",
            "🧽 Cleaning Summary",
            "📈 Before / After",
            "🧠 AI Narrative",
            "⬇️ Downloads",
        ])

        # ---------------- Preview tab ----------------
        with tabs[0]:
            st.markdown("#### Data extracted before cleaning")
            st.dataframe(result["extracted_dataframe_preview"], use_container_width=True)
            st.markdown("#### Data after cleaning")
            st.dataframe(cleaned_df.head(config.MAX_PREVIEW_ROWS), use_container_width=True)

        # ---------------- Profiling tab ----------------
        with tabs[1]:
            profile = result["profile_before"]
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Rows", profile["shape"]["rows"])
            c2.metric("Columns", profile["shape"]["columns"])
            c3.metric("Duplicate rows", profile["duplicates"]["duplicate_row_count"])
            c4.metric("Quality issues flagged", profile["quality_issue_count"])

            st.markdown("##### Column Overview")
            col_df = pd.DataFrame(profile["columns"])
            col_df = col_df.copy()

            if "sample_values" in col_df.columns:
                col_df["sample_values"] = col_df["sample_values"].astype(str)

            st.dataframe(col_df, use_container_width=True)

            st.markdown("##### Missing Values")
            missing_df = pd.DataFrame(profile["missing_values"]).T
            missing_df.index.name = "column"
            st.dataframe(missing_df, use_container_width=True)

        # ---------------- Quality Issues tab ----------------
        with tabs[2]:
            profile = result["profile_before"]

            st.markdown("##### 🔁 Duplicates")
            st.write(profile["duplicates"])

            st.markdown("##### ␣ Whitespace Issues")
            if profile["whitespace_issues"]:
                st.json(profile["whitespace_issues"])
            else:
                st.write("None detected.")

            st.markdown("##### 📅 Detected Date Columns")
            if profile["date_columns_detected"]:
                st.dataframe(pd.DataFrame(profile["date_columns_detected"]), use_container_width=True)
            else:
                st.write("None detected.")

            st.markdown("##### 🔀 Inconsistent Data-Type Columns")
            if profile["inconsistent_dtype_columns"]:
                st.dataframe(pd.DataFrame(profile["inconsistent_dtype_columns"]), use_container_width=True)
            else:
                st.write("None detected.")

            st.markdown("##### 📈 Numeric Anomalies (IQR method)")
            if profile["numeric_anomalies"]:
                for col, info in profile["numeric_anomalies"].items():
                    st.write(f"**{col}**: {info['outlier_count']} outliers "
                              f"(expected range {info['lower_bound']} – {info['upper_bound']})")
            else:
                st.write("None detected.")

        # ---------------- Cleaning Summary tab ----------------
        with tabs[3]:
            cleaning_log = result["cleaning_log"]
            if not cleaning_log:
                st.write("No cleaning actions were necessary — data was already clean.")
            else:
                for i, entry in enumerate(cleaning_log, start=1):
                    with st.expander(f"{i}. {entry['action']} — {entry['records_affected']} records affected"):
                        st.write(entry["description"])
                        st.json(entry["details"])

            st.markdown("##### ✅ Validation Results")
            for check, info in result["validation_results"].items():
                if check == "overall_passed":
                    continue
                icon = "✅" if info["passed"] else "❌"
                st.write(f"{icon} **{check.replace('_', ' ')}** — {info['detail']}")
            overall = result["validation_results"]["overall_passed"]
            (st.success if overall else st.warning)(
                "Overall validation: " + ("PASSED ✅" if overall else "SOME CHECKS FAILED ⚠️")
            )

        # ---------------- Before / After tab ----------------
        with tabs[4]:
            before, after = result["before_shape"], result["after_shape"]
            c1, c2 = st.columns(2)
            with c1:
                st.markdown("##### Before")
                st.metric("Rows", before[0])
                st.metric("Columns", before[1])
                st.metric("Missing cells", int(sum(
                    m["missing_count"] for m in result["profile_before"]["missing_values"].values()
                )))
                st.metric("Duplicate rows", result["profile_before"]["duplicates"]["duplicate_row_count"])
            with c2:
                st.markdown("##### After")
                st.metric("Rows", after[0], delta=after[0] - before[0])
                st.metric("Columns", after[1], delta=after[1] - before[1])
                st.metric("Missing cells", int(sum(
                    m["missing_count"] for m in result["profile_after"]["missing_values"].values()
                )))
                st.metric("Duplicate rows", result["profile_after"]["duplicates"]["duplicate_row_count"])

        # ---------------- AI Narrative tab ----------------
        with tabs[5]:
            st.markdown("##### 🧠 AI Agent Narrative Summary")
            if config.ANTHROPIC_API_KEY:
                st.caption("Generated using the Anthropic API.")
            else:
                st.caption("Generated using a built-in rule-based summary "
                           "(set ANTHROPIC_API_KEY in .env to enable full AI narratives).")
            st.write(result["ai_narrative"])

        # ---------------- Downloads tab ----------------
        with tabs[6]:
            st.markdown("##### Download your outputs")
            outputs = result["outputs"]

            def _download_button(label, key):
                path = outputs.get(key)
                if path and os.path.exists(path):
                    with open(path, "rb") as f:
                        st.download_button(label, data=f.read(),
                                            file_name=os.path.basename(path), key=key)

            col_a, col_b = st.columns(2)
            with col_a:
                _download_button("⬇️ Cleaned Data (CSV)", "cleaned_csv")
                _download_button("⬇️ Profiling Report (Markdown)", "profiling_report_md")
                _download_button("⬇️ Data Audit Log (JSON)", "audit_log_json")
            with col_b:
                _download_button("⬇️ Cleaned Data (XLSX)", "cleaned_xlsx")
                _download_button("⬇️ Cleaning Summary (Markdown)", "cleaning_summary_md")
                _download_button("⬇️ Extracted Raw Data (CSV)", "extracted_data_csv")

elif result and not result.get("success") and not st.session_state.error:
    st.warning(result.get("message", "Processing did not complete successfully."))


# ----------------------------------------------------------------------
# Footer
# ----------------------------------------------------------------------
st.divider()
st.caption(
    "Built with Streamlit, Pandas, pdfplumber, and pytesseract. "
    "All outputs are also saved locally under the `outputs/` folder."
)
