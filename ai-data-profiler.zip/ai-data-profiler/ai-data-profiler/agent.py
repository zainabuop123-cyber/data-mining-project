"""
agent.py
--------
This is the "AI Agent" that ties every module together into the
8-step workflow described in the project requirements:

  1. Inspect the uploaded file           -> file_processor.py
  2. Understand its structure            -> data_profiler.py
  3. Create a profiling report           -> data_profiler.py
  4. Identify data-quality problems      -> data_profiler.py
  5. Perform appropriate cleaning        -> data_cleaner.py
  6. Validate the cleaned dataset        -> audit_logger.py
  7. Generate an audit report            -> audit_logger.py
  8. Allow the user to download outputs  -> app.py (uses paths below)

Each step calls a `progress_callback(step_number, step_name, status)`
function if one is supplied, so the Streamlit UI can show live
AI-agent status/progress without this module knowing anything about
Streamlit.
"""

import os
from datetime import datetime

import pandas as pd

import config
import file_processor
from audit_logger import AuditLogger, validate_cleaned_data
from data_cleaner import DataCleaner, build_markdown_summary
from data_profiler import DataProfiler, build_markdown_report
from utils import get_logger, safe_filename, timestamp

logger = get_logger(__name__)

AGENT_STEPS = [
    "Inspecting uploaded file",
    "Understanding data structure",
    "Generating profiling report",
    "Identifying data-quality issues",
    "Cleaning the dataset",
    "Validating cleaned dataset",
    "Generating audit report",
    "Preparing downloadable outputs",
]


class DataAgent:
    """Runs the full inspect -> profile -> clean -> validate -> report pipeline."""

    def __init__(self, progress_callback=None):
        self.progress_callback = progress_callback

    def _report_progress(self, step_index: int, status: str = "running"):
        if self.progress_callback:
            self.progress_callback(step_index, AGENT_STEPS[step_index - 1], status)

    def run(self, file_path: str, original_filename: str) -> dict:
        """
        Executes the full pipeline for one uploaded file.
        Returns a dictionary containing everything the UI needs to render
        results and offer downloads.
        """
        run_id = f"{safe_filename(os.path.splitext(original_filename)[0])}_{timestamp()}"
        run_output_dir = os.path.join(config.OUTPUT_DIR, run_id)
        os.makedirs(run_output_dir, exist_ok=True)

        result = {
            "run_id": run_id,
            "original_filename": original_filename,
            "success": False,
            "message": "",
            "outputs": {},
        }

        # ---------------- Step 1: Inspect the uploaded file ----------------
        self._report_progress(1)
        extraction = file_processor.process_file(file_path, original_filename)
        result["file_type"] = extraction["file_type"]
        result["extraction_method"] = extraction.get("extraction_method")
        result["extraction_message"] = extraction["message"]
        self._report_progress(1, "done")

        if not extraction["success"]:
            result["message"] = extraction["message"]
            self._report_progress(1, "failed")
            return result

        df = extraction.get("dataframe")
        raw_text = extraction.get("raw_text")

        # Save extracted-but-not-yet-cleaned data (relevant for PDFs/images)
        if df is not None:
            extracted_path = os.path.join(run_output_dir, "extracted_data.csv")
            df.to_csv(extracted_path, index=False)
            result["outputs"]["extracted_data_csv"] = extracted_path
        elif raw_text:
            extracted_text_path = os.path.join(run_output_dir, "extracted_text.txt")
            with open(extracted_text_path, "w", encoding="utf-8") as f:
                f.write(raw_text)
            result["outputs"]["extracted_text"] = extracted_text_path

        if df is None:
            result["message"] = (
                "This file could not be converted into structured tabular data. "
                + extraction["message"]
            )
            result["success"] = True  # extraction ran, just no table available
            result["raw_text"] = raw_text
            return result

        result["extracted_dataframe_preview"] = df.head(config.MAX_PREVIEW_ROWS)
        before_shape = df.shape

        # ---------------- Step 2 & 3: Structure + profiling report ---------
        self._report_progress(2)
        profiler = DataProfiler(df)
        profile_before = profiler.generate_report()
        self._report_progress(2, "done")

        self._report_progress(3)
        profiling_markdown = build_markdown_report(profile_before, original_filename)
        profiling_report_path = os.path.join(run_output_dir, "profiling_report.md")
        AuditLogger.save_text(profiling_markdown, profiling_report_path)
        result["outputs"]["profiling_report_md"] = profiling_report_path
        self._report_progress(3, "done")

        # ---------------- Step 4: Identify data-quality issues -------------
        self._report_progress(4)
        result["profile_before"] = profile_before
        result["quality_issue_count"] = profile_before["quality_issue_count"]
        self._report_progress(4, "done")

        # ---------------- Step 5: Clean the dataset -------------------------
        self._report_progress(5)
        cleaner = DataCleaner(df)
        cleaned_df, cleaning_log = cleaner.clean()
        after_shape = cleaned_df.shape
        result["cleaning_log"] = cleaning_log
        result["cleaned_dataframe"] = cleaned_df

        cleaning_summary_md = build_markdown_summary(cleaning_log, before_shape, after_shape)
        cleaning_summary_path = os.path.join(run_output_dir, "cleaning_summary.md")
        AuditLogger.save_text(cleaning_summary_md, cleaning_summary_path)
        result["outputs"]["cleaning_summary_md"] = cleaning_summary_path
        self._report_progress(5, "done")

        # ---------------- Step 6: Validate cleaned dataset ------------------
        self._report_progress(6)
        validation_results = validate_cleaned_data(cleaned_df)
        result["validation_results"] = validation_results
        self._report_progress(6, "done")

        # ---------------- Step 7: Generate audit report ---------------------
        self._report_progress(7)
        audit_logger = AuditLogger(original_filename, result["file_type"])
        audit_log = audit_logger.build_audit_log(
            profile_before=profile_before,
            cleaning_log=cleaning_log,
            before_shape=before_shape,
            after_shape=after_shape,
            validation_results=validation_results,
            extraction_method=result["extraction_method"],
        )

        # Also compute an "after" profile for a clean before/after comparison
        profile_after = DataProfiler(cleaned_df).generate_report()
        audit_log["profile_after_summary"] = {
            "missing_values_after": profile_after["missing_values"],
            "duplicates_after": profile_after["duplicates"],
            "quality_issue_count_after": profile_after["quality_issue_count"],
        }
        result["profile_after"] = profile_after

        audit_log_path = os.path.join(run_output_dir, "audit_log.json")
        AuditLogger.save_json(audit_log, audit_log_path)
        result["outputs"]["audit_log_json"] = audit_log_path
        result["audit_log"] = audit_log

        # Optional AI narrative summary (uses Anthropic API if configured)
        result["ai_narrative"] = self._generate_ai_narrative(profile_before, cleaning_log,
                                                               validation_results, original_filename)
        self._report_progress(7, "done")

        # ---------------- Step 8: Prepare downloadable outputs ---------------
        self._report_progress(8)
        cleaned_csv_path = os.path.join(run_output_dir, "cleaned_data.csv")
        cleaned_df.to_csv(cleaned_csv_path, index=False)
        result["outputs"]["cleaned_csv"] = cleaned_csv_path

        cleaned_xlsx_path = os.path.join(run_output_dir, "cleaned_data.xlsx")
        try:
            cleaned_df.to_excel(cleaned_xlsx_path, index=False)
            result["outputs"]["cleaned_xlsx"] = cleaned_xlsx_path
        except Exception:  # noqa: BLE001
            logger.warning("Could not write XLSX output (openpyxl missing?).")

        self._report_progress(8, "done")

        result["success"] = True
        result["message"] = "Processing complete."
        result["before_shape"] = before_shape
        result["after_shape"] = after_shape
        return result

    # ------------------------------------------------------------------
    def _generate_ai_narrative(self, profile_before, cleaning_log, validation_results, filename):
        """
        Calls the Anthropic API (if an API key is configured) to produce a
        short, human-friendly narrative summary. Falls back to a simple
        rule-based summary if no key is set or the call fails, so the app
        always works even fully offline.
        """
        fallback = self._rule_based_narrative(profile_before, cleaning_log, validation_results)

        if not config.ENABLE_AI_NARRATIVE or not config.ANTHROPIC_API_KEY:
            return fallback

        try:
            import anthropic

            client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
            prompt = (
                f"You are a data quality analyst. In 4-6 concise sentences, summarize the "
                f"data cleaning results for a non-technical audience.\n\n"
                f"File: {filename}\n"
                f"Quality issues found before cleaning: {profile_before['quality_issue_count']}\n"
                f"Cleaning actions performed: {[c['action'] for c in cleaning_log]}\n"
                f"Total records affected by cleaning: "
                f"{sum(c['records_affected'] for c in cleaning_log)}\n"
                f"Final validation passed: {validation_results['overall_passed']}\n"
            )
            message = client.messages.create(
                model=config.ANTHROPIC_MODEL,
                max_tokens=400,
                messages=[{"role": "user", "content": prompt}],
            )
            text_blocks = [b.text for b in message.content if getattr(b, "type", "") == "text"]
            ai_text = "\n".join(text_blocks).strip()
            return ai_text if ai_text else fallback
        except Exception as exc:  # noqa: BLE001
            logger.warning("AI narrative generation failed, using fallback: %s", exc)
            return fallback

    @staticmethod
    def _rule_based_narrative(profile_before, cleaning_log, validation_results):
        n_issues = profile_before["quality_issue_count"]
        n_actions = len(cleaning_log)
        n_records = sum(c["records_affected"] for c in cleaning_log)
        passed = validation_results["overall_passed"]

        parts = []
        if n_issues == 0:
            parts.append("The uploaded dataset was already in good shape, with no major quality issues detected.")
        else:
            parts.append(
                f"The AI agent detected {n_issues} data-quality issue area(s) in the dataset, "
                f"including things like missing values, duplicates, or inconsistent formatting."
            )
        if n_actions > 0:
            parts.append(
                f"To fix this, {n_actions} automated cleaning step(s) were applied, "
                f"affecting a total of {n_records} record(s)."
            )
        else:
            parts.append("No cleaning steps were required.")
        parts.append(
            "The cleaned dataset "
            + ("passed" if passed else "did NOT fully pass")
            + " final validation checks."
        )
        return " ".join(parts)
