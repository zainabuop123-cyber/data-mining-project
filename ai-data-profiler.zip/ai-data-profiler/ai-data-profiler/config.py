"""
config.py
---------
Central place for all configuration values used across the project.
Keeping settings here means beginners only need to look in ONE file
to change behaviour (folders, thresholds, supported file types, etc).
"""

import os
from dotenv import load_dotenv

# Load variables from a .env file (if present) into the environment
load_dotenv()

# ----------------------------------------------------------------------
# Folders
# ----------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
SAMPLE_DATA_DIR = os.path.join(BASE_DIR, "sample_data")
TEMP_DIR = os.path.join(BASE_DIR, "temp")

for folder in (OUTPUT_DIR, TEMP_DIR):
    os.makedirs(folder, exist_ok=True)

# ----------------------------------------------------------------------
# Supported file types
# ----------------------------------------------------------------------
SUPPORTED_TABULAR_EXTENSIONS = [".csv", ".xlsx", ".xls", ".tsv"]
SUPPORTED_TEXT_EXTENSIONS = [".txt"]
SUPPORTED_PDF_EXTENSIONS = [".pdf"]
SUPPORTED_IMAGE_EXTENSIONS = [".png", ".jpg", ".jpeg"]

ALL_SUPPORTED_EXTENSIONS = (
    SUPPORTED_TABULAR_EXTENSIONS
    + SUPPORTED_TEXT_EXTENSIONS
    + SUPPORTED_PDF_EXTENSIONS
    + SUPPORTED_IMAGE_EXTENSIONS
)

# ----------------------------------------------------------------------
# Data cleaning / profiling thresholds
# ----------------------------------------------------------------------
# If a column has more than this % of missing values, we flag it as
# "high missingness" instead of silently imputing it.
HIGH_MISSING_THRESHOLD_PCT = 50.0

# IQR multiplier used for numeric outlier / anomaly detection
IQR_MULTIPLIER = 1.5

# Standard date output format after cleaning
STANDARD_DATE_FORMAT = "%Y-%m-%d"

# Candidate date formats we try to parse when detecting date-like columns
CANDIDATE_DATE_FORMATS = [
    "%Y-%m-%d",
    "%d-%m-%Y",
    "%m-%d-%Y",
    "%Y/%m/%d",
    "%d/%m/%Y",
    "%m/%d/%Y",
    "%d %b %Y",
    "%d %B %Y",
    "%b %d, %Y",
    "%B %d, %Y",
    "%Y-%m-%d %H:%M:%S",
]

# ----------------------------------------------------------------------
# AI / API configuration
# ----------------------------------------------------------------------
# Optional: if set, the agent will call the Anthropic API to generate a
# natural-language narrative summary of the profiling/cleaning results.
# If not set, the agent falls back to a rule-based (non-AI) summary so
# the app still works fully offline / without any API key.
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")
ENABLE_AI_NARRATIVE = os.getenv("ENABLE_AI_NARRATIVE", "true").lower() == "true"

# ----------------------------------------------------------------------
# OCR configuration
# ----------------------------------------------------------------------
# Path to the tesseract binary. On most Linux systems "tesseract" (on PATH)
# works out of the box once `sudo apt-get install tesseract-ocr` is run.
TESSERACT_CMD = os.getenv("TESSERACT_CMD", "tesseract")

# DPI used when rasterizing PDF pages for OCR
PDF_OCR_DPI = 200

# ----------------------------------------------------------------------
# Misc
# ----------------------------------------------------------------------
APP_TITLE = "AI Data Profiler & Automated Data Cleaner"
MAX_PREVIEW_ROWS = 50
