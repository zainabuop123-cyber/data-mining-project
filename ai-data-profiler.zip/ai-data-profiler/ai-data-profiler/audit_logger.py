"""
audit_logger.py
----------------
Builds the final JSON "Data Audit Log" required by the project spec,
and provides helpers to save all report artifacts to disk.
"""

import json
import os
from datetime import datetime

import config
from utils import get_logger, ensure_dir

logger = get_logger(__name__)


class AuditLogger:
    def __init__(self, original_filename: str, file_type: str):
        self.original_filename = original_filename
        self.file_type = file_type
        self.start_time = datetime.now()

    def build_audit_log(
        self,
        profile_before: dict,
        cleaning_log: list,
        before_shape: tuple,
        after_shape: tuple,
        validation_results: dict,
        extraction_method: str = None,
    ) -> dict:
        audit = {
            "audit_metadata": {
                "original_file_name": self.original_filename,
                "file_type": self.file_type,
                "extraction_method": extraction_method,
                "processed_at": self.start_time.isoformat(),
                "completed_at": datetime.now().isoformat(),
            },
            "row_column_counts": {
                "before": {"rows": before_shape[0], "columns": before_shape[1]},
                "after": {"rows": after_shape[0], "columns": after_shape[1]},
            },
            "detected_data_types": {
                col["name"]: col["dtype"] for col in profile_before["columns"]
            },
            "missing_values_before": profile_before["missing_values"],
            "duplicates_before": profile_before["duplicates"],
            "anomalies_detected_before": profile_before["numeric_anomalies"],
            "whitespace_issues_before": profile_before["whitespace_issues"],
            "date_columns_detected": profile_before["date_columns_detected"],
            "inconsistent_dtype_columns": profile_before["inconsistent_dtype_columns"],
            "cleaning_operations_performed": cleaning_log,
            "total_records_affected": sum(e["records_affected"] for e in cleaning_log),
            "final_validation_results": validation_results,
        }
        return audit

    @staticmethod
    def save_json(audit: dict, output_path: str):
        ensure_dir(os.path.dirname(output_path))
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(audit, f, indent=2, default=str)
        logger.info("Audit log saved to %s", output_path)
        return output_path

    @staticmethod
    def save_text(content: str, output_path: str):
        ensure_dir(os.path.dirname(output_path))
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
        logger.info("Report saved to %s", output_path)
        return output_path


def validate_cleaned_data(df) -> dict:
    """
    Step 6 of the agent workflow: "Validate the cleaned dataset".
    Runs a handful of sanity checks and reports pass/fail per check.
    """
    results = {}

    results["no_duplicate_rows"] = {
        "passed": bool(df.duplicated().sum() == 0),
        "detail": f"{int(df.duplicated().sum())} duplicate rows remaining.",
    }

    total_cells = df.shape[0] * df.shape[1] if df.shape[0] and df.shape[1] else 1
    remaining_missing = int(df.isna().sum().sum())
    results["missing_values_within_tolerance"] = {
        "passed": bool((remaining_missing / total_cells) < 0.05),
        "detail": f"{remaining_missing} missing cells remain "
                  f"({remaining_missing / total_cells * 100:.2f}% of all cells).",
    }

    results["column_names_standardized"] = {
        "passed": bool(all(c == c.lower().strip() and " " not in c for c in df.columns)),
        "detail": "All column names are lower-case, snake_case, and whitespace-free.",
    }

    results["no_fully_empty_columns"] = {
        "passed": bool(not any(df[c].isna().all() for c in df.columns)),
        "detail": "Checked for columns that are entirely empty after cleaning.",
    }

    results["overall_passed"] = all(v["passed"] for v in results.values())
    return results
