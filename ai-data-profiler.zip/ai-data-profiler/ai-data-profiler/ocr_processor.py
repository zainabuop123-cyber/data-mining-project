"""
ocr_processor.py
-----------------
Handles extraction of tabular data / text from PDFs and images.

Strategy:
  PDF:
    1. Try pdfplumber to pull native tables/text (fast, works on
       "digital" PDFs that already contain text).
    2. If no text/tables are found, assume it's a *scanned* PDF and
       fall back to OCR (convert pages to images, run pytesseract).

  Image (PNG/JPG/JPEG):
    1. Run pytesseract OCR directly on the image.
    2. Attempt to reconstruct a table from the OCR'd text using simple
       whitespace/line heuristics.

If none of this produces structured data, we still return whatever raw
text was found and clearly flag that the file could not be converted
into a clean table -- this satisfies the "clearly report if a file
cannot be converted" requirement.
"""

import io

import pandas as pd

import config
from utils import get_logger

logger = get_logger(__name__)


def extract_from_file(file_path: str, file_type: str) -> dict:
    if file_type == "pdf":
        return _extract_from_pdf(file_path)
    if file_type == "image":
        return _extract_from_image(file_path)
    return {
        "success": False,
        "dataframe": None,
        "raw_text": None,
        "extraction_method": None,
        "message": f"OCR processor does not support file type '{file_type}'.",
    }


# ----------------------------------------------------------------------
# PDF handling
# ----------------------------------------------------------------------
def _extract_from_pdf(file_path: str) -> dict:
    try:
        import pdfplumber
    except ImportError:
        return _fail("pdfplumber is not installed. Run: pip install pdfplumber")

    all_text = []
    all_tables = []

    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text() or ""
                all_text.append(text)
                tables = page.extract_tables()
                for table in tables:
                    if table and len(table) > 1:
                        df = pd.DataFrame(table[1:], columns=table[0])
                        all_tables.append(df)
    except Exception as exc:  # noqa: BLE001
        logger.exception("pdfplumber failed")
        return _fail(f"Failed to read PDF with pdfplumber: {exc}")

    combined_text = "\n".join(all_text).strip()

    # Case 1: native tables were found -> best outcome
    if all_tables:
        try:
            merged = pd.concat(all_tables, ignore_index=True)
        except Exception:  # noqa: BLE001
            merged = all_tables[0]
        return {
            "success": True,
            "dataframe": merged,
            "raw_text": combined_text,
            "extraction_method": "pdfplumber_table",
            "message": f"Extracted {len(all_tables)} table(s) directly from the PDF text layer.",
        }

    # Case 2: there is text, but no detectable tables -> try to parse text as data
    if combined_text:
        df = _text_to_dataframe(combined_text)
        if df is not None:
            return {
                "success": True,
                "dataframe": df,
                "raw_text": combined_text,
                "extraction_method": "pdfplumber_text_parsed",
                "message": "No native tables found; reconstructed a table from the PDF's text layer.",
            }
        return {
            "success": True,
            "dataframe": None,
            "raw_text": combined_text,
            "extraction_method": "pdfplumber_text_only",
            "message": (
                "Text was extracted from the PDF, but it could not be converted into "
                "a structured table. Showing raw extracted text instead."
            ),
        }

    # Case 3: no text at all -> this is a scanned PDF, use OCR
    logger.info("No text layer found in PDF, falling back to OCR.")
    return _ocr_scanned_pdf(file_path)


def _ocr_scanned_pdf(file_path: str) -> dict:
    try:
        from pdf2image import convert_from_path
        import pytesseract
    except ImportError:
        return _fail(
            "This looks like a scanned PDF, but OCR libraries are missing. "
            "Run: pip install pdf2image pytesseract  (and install the "
            "'poppler-utils' and 'tesseract-ocr' system packages)."
        )

    try:
        pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_CMD
        pages = convert_from_path(file_path, dpi=config.PDF_OCR_DPI)
        page_texts = [pytesseract.image_to_string(page) for page in pages]
        combined_text = "\n".join(page_texts).strip()
    except Exception as exc:  # noqa: BLE001
        logger.exception("OCR of scanned PDF failed")
        return _fail(
            f"OCR failed on this scanned PDF: {exc}. "
            "Make sure Tesseract OCR and poppler-utils are installed on your system."
        )

    if not combined_text:
        return {
            "success": False,
            "dataframe": None,
            "raw_text": None,
            "extraction_method": "ocr_pdf",
            "message": "OCR ran but no readable text was found in this scanned PDF.",
        }

    df = _text_to_dataframe(combined_text)
    return {
        "success": True,
        "dataframe": df,
        "raw_text": combined_text,
        "extraction_method": "ocr_pdf",
        "message": (
            "Scanned PDF processed with OCR. "
            + ("Reconstructed a table from the OCR text." if df is not None
               else "Could not confidently reconstruct a table; showing raw OCR text.")
        ),
    }


# ----------------------------------------------------------------------
# Image handling
# ----------------------------------------------------------------------
def _extract_from_image(file_path: str) -> dict:
    try:
        from PIL import Image
        import pytesseract
    except ImportError:
        return _fail(
            "OCR libraries are missing. Run: pip install pytesseract pillow "
            "(and install the 'tesseract-ocr' system package)."
        )

    try:
        pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_CMD
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image).strip()
    except Exception as exc:  # noqa: BLE001
        logger.exception("OCR of image failed")
        return _fail(
            f"OCR failed on this image: {exc}. "
            "Make sure Tesseract OCR is installed on your system and on PATH."
        )

    if not text:
        return {
            "success": False,
            "dataframe": None,
            "raw_text": None,
            "extraction_method": "ocr_image",
            "message": "OCR ran but no readable text was found in this image.",
        }

    df = _text_to_dataframe(text)
    return {
        "success": True,
        "dataframe": df,
        "raw_text": text,
        "extraction_method": "ocr_image",
        "message": (
            "Image processed with OCR. "
            + ("Reconstructed a table from the OCR text." if df is not None
               else "Could not confidently reconstruct a table; showing raw OCR text.")
        ),
    }


# ----------------------------------------------------------------------
# Shared helpers
# ----------------------------------------------------------------------
def _text_to_dataframe(text: str):
    """
    Best-effort attempt to turn raw extracted text into a DataFrame.
    Tries common delimiters; falls back to splitting on runs of 2+ spaces
    (typical of OCR'd tables). Returns None if nothing sensible is found.
    """
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if len(lines) < 2:
        return None

    for sep in [",", "\t", ";", "|"]:
        try:
            candidate = pd.read_csv(io.StringIO(text), sep=sep)
            if candidate.shape[1] > 1 and candidate.shape[0] >= 1:
                return candidate
        except Exception:  # noqa: BLE001
            continue

    # Fallback: split on 2+ consecutive spaces (common OCR table layout)
    try:
        rows = [_split_on_multi_space(ln) for ln in lines]
        width = len(rows[0])
        if width > 1 and all(len(r) == width for r in rows[1:]):
            header, *data_rows = rows
            return pd.DataFrame(data_rows, columns=header)
    except Exception:  # noqa: BLE001
        pass

    return None


def _split_on_multi_space(line: str):
    import re
    return [part.strip() for part in re.split(r"\s{2,}", line.strip()) if part.strip()]


def _fail(message: str) -> dict:
    logger.warning(message)
    return {
        "success": False,
        "dataframe": None,
        "raw_text": None,
        "extraction_method": None,
        "message": message,
    }
