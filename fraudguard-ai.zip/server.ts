import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      pipeline: "active",
      service: "FraudGuard AI Core Engine",
      timestamp: new Date().toISOString(),
    });
  });

  // AI Unstructured File / Document Parser (for PDF text/images/DOC/scanned receipts)
  app.post("/api/gemini/parse-unstructured", async (req, res) => {
    try {
      const { textContent, base64Image, mimeType, fileName } = req.body;
      const ai = getAI();

      if (!ai) {
        return res.status(503).json({
          error: "Gemini AI is currently not configured. Standard rule engine will continue.",
          records: [],
        });
      }

      const prompt = `You are a specialized fraud detection data extraction engine. 
Analyze the provided document or text content and extract all financial transactions, payments, or ledger activity into a clean JSON array of normalized transaction records.

For each transaction found, extract or infer these exact fields if present:
- transactionId: string (e.g. TXN-98421 or UUID)
- userId: string (e.g. USR-4821)
- amount: number (e.g. 1420.50)
- currency: string (e.g. "USD", "EUR", "GBP")
- timestamp: ISO 8601 string or date string (e.g. "2026-08-23T14:32:00Z")
- merchant: string (e.g. "CryptoPay Inc", "Apple Store", "Luxury Retail")
- merchantCategory: string (e.g. "Cryptocurrency", "Electronics", "Wire Transfer", "Travel", "Gaming", "Retail", "Jewelry")
- paymentMethod: string (e.g. "Credit Card", "Wire", "Crypto", "Debit Card", "ACH")
- ipAddress: string (e.g. "194.26.29.112")
- deviceId: string (e.g. "DEV-99214")
- isVpnOrProxy: boolean or null
- isEmulator: boolean or null
- kycStatus: "VERIFIED" | "PENDING" | "FAILED" | "NONE"
- accountAgeDays: number or null
- loginPatternConsistent: boolean or null
- city: string or null (e.g. "Lagos", "New York", "London", "Hong Kong", "Moscow", "Tokyo")
- country: string or null (e.g. "Nigeria", "United States", "United Kingdom", "Hong Kong", "Russia", "Japan")
- latitude: number or null (e.g. 6.5244)
- longitude: number or null (e.g. 3.3792)

Return ONLY valid JSON with no markdown backticks, matching this JSON schema:
{
  "extractedCount": number,
  "fileNotes": string,
  "records": [ ...transactions ]
}`;

      let parts: any[] = [];
      if (base64Image) {
        parts.push({
          inlineData: {
            mimeType: mimeType || "image/png",
            data: base64Image.replace(/^data:image\/[a-z]+;base64,/, ""),
          },
        });
      }
      if (textContent) {
        parts.push({
          text: `File name: ${fileName || "document"}\n\nContent to parse:\n${textContent.slice(0, 15000)}`,
        });
      }
      parts.push({ text: prompt });

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: { parts },
        config: {
          responseMimeType: "application/json",
          temperature: 0.1,
        },
      });

      const responseText = response.text || "{}";
      let parsed = JSON.parse(responseText);
      res.json(parsed);
    } catch (err: any) {
      console.error("Gemini parse error:", err);
      res.status(500).json({ error: err.message || "Failed to parse document" });
    }
  });

  // AI Deep Forensic Investigation for a transaction / alert
  app.post("/api/gemini/investigate-transaction", async (req, res) => {
    try {
      const { transaction, contextHistory } = req.body;
      const ai = getAI();

      if (!ai) {
        return res.status(503).json({
          error: "Gemini API unavailable. Using standard heuristics.",
          analysis: "Standard rules flagged this transaction based on multi-stage metrics.",
        });
      }

      const prompt = `You are a Senior Chief Fraud Investigator & ML Security Analyst at FraudGuard AI.
Analyze this specific flagged transaction and its multi-stage risk signals:

Transaction Details:
${JSON.stringify(transaction, null, 2)}

User/Dataset Context:
${JSON.stringify(contextHistory || {}, null, 2)}

Provide a thorough, professional forensic assessment:
1. Executive Risk Summary (2-3 sentences explaining why this was blocked/reviewed).
2. Deep Breakdown of Triggered Vectors (Identity, Behavioral, Network/Device, Geographic).
3. Velocity & Travel Analysis (Speed calculation if impossible travel detected, e.g. Lagos to Frankfurt in 15 mins).
4. Recommended Immediate SecOps Mitigation Actions (e.g. Revoke JWT tokens, initiate Step-up 3DS / biometric challenge, file SAR / STR report, freeze merchant payout).
5. Rule Tuning Recommendations (How FraudOps should update rule weights).

Return JSON format with properties:
{
  "riskRating": "HIGH" | "MEDIUM" | "LOW",
  "summary": string,
  "vectorBreakdown": {
    "identity": string,
    "behavioral": string,
    "networkDevice": string,
    "geographic": string
  },
  "travelVelocityNote": string,
  "recommendedActions": string[],
  "ruleTuningTip": string
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.2,
        },
      });

      const parsed = JSON.parse(response.text || "{}");
      res.json(parsed);
    } catch (err: any) {
      console.error("Investigation error:", err);
      res.status(500).json({ error: err.message || "Forensic analysis failed" });
    }
  });

  // AI Fraud Incident & Audit Report Generation
  app.post("/api/gemini/generate-report", async (req, res) => {
    try {
      const { metrics, flaggedCount, highRiskTransactions } = req.body;
      const ai = getAI();

      if (!ai) {
        return res.status(503).json({ error: "Gemini API key missing" });
      }

      const prompt = `You are an automated Fraud Audit Reporter for FraudGuard AI.
Generate a comprehensive Executive Fraud Intelligence Report based on this dataset:
- Total Monitored: ${metrics.totalTransactions}
- Fraud Detected: ${metrics.fraudCount}
- Fraud Rate: ${metrics.fraudRate}%
- Total Suspicious Volume: $${metrics.suspiciousAmount}
- Average Risk Score: ${metrics.averageRiskScore}
- Flagged Highlights: ${JSON.stringify(highRiskTransactions?.slice(0, 5) || [])}

Include:
- Executive Summary
- Key Threat Vectors Observed
- High-Risk Geographical Clusters
- Financial Impact & Saved Revenue
- Compliance & Policy Recommendations

Return JSON with format:
{
  "reportTitle": string,
  "generatedAt": string,
  "executiveSummary": string,
  "threatVectors": string[],
  "geoClusters": string[],
  "financialImpact": string,
  "complianceNextSteps": string[]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.3,
        },
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (err: any) {
      console.error("Report gen error:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`FraudGuard AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
