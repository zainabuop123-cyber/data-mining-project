import { ColumnMappingConfig, RawTransaction } from "../types";

export interface CanonicalFieldDef {
  key: keyof ColumnMappingConfig;
  label: string;
  category: "CORE" | "IDENTITY" | "NETWORK" | "LOCATION" | "MERCHANT";
  required: boolean;
  description: string;
  synonyms: string[];
}

export const CANONICAL_FIELDS: CanonicalFieldDef[] = [
  {
    key: "transactionId",
    label: "Transaction ID",
    category: "CORE",
    required: true,
    description: "Unique identifier for the financial transaction (e.g. TXN-10928, reference, payment_id)",
    synonyms: [
      "transaction_id",
      "transactionid",
      "trans_id",
      "transid",
      "txid",
      "tx_id",
      "id",
      "reference",
      "ref_id",
      "payment_id",
      "paymentid",
      "order_id",
      "orderid",
      "charge_id",
    ],
  },
  {
    key: "userId",
    label: "User / Customer ID",
    category: "IDENTITY",
    required: true,
    description: "Account or customer reference (e.g. USR-901, customer_id, account_number, uid)",
    synonyms: [
      "user_id",
      "userid",
      "customer_id",
      "customerid",
      "account_id",
      "accountid",
      "user",
      "client_id",
      "clientid",
      "uid",
      "account",
      "cardholder",
      "payer_id",
    ],
  },
  {
    key: "amount",
    label: "Amount",
    category: "CORE",
    required: true,
    description: "Transaction amount in monetary units (e.g. 150.00, value, total, price)",
    synonyms: [
      "amount",
      "transaction_amount",
      "transactionamount",
      "amt",
      "total",
      "total_amount",
      "value",
      "sum",
      "price",
      "trans_amt",
      "payment_amount",
      "charge_amount",
      "cost",
    ],
  },
  {
    key: "currency",
    label: "Currency",
    category: "CORE",
    required: false,
    description: "ISO currency code (e.g. USD, EUR, GBP, JPY)",
    synonyms: ["currency", "curr", "curr_code", "currency_code", "iso_currency"],
  },
  {
    key: "timestamp",
    label: "Date & Time / Timestamp",
    category: "CORE",
    required: false,
    description: "Timestamp or date of the transaction (ISO string, unix ms, YYYY-MM-DD HH:mm:ss)",
    synonyms: [
      "timestamp",
      "datetime",
      "date_time",
      "date",
      "transaction_date",
      "transactiondate",
      "created_at",
      "createdat",
      "trans_date",
      "tx_timestamp",
      "time",
      "tx_date",
    ],
  },
  {
    key: "merchant",
    label: "Merchant / Recipient",
    category: "MERCHANT",
    required: false,
    description: "Merchant name, payee, recipient, or store (e.g. Amazon, Stripe, Coinbase)",
    synonyms: [
      "merchant",
      "merchant_name",
      "store",
      "vendor",
      "recipient",
      "receiver",
      "payee",
      "shop",
      "business",
    ],
  },
  {
    key: "merchantCategory",
    label: "Merchant Category (MCC)",
    category: "MERCHANT",
    required: false,
    description: "Industry or merchant category (e.g. Retail, Crypto, Wire Transfer, Gambling)",
    synonyms: [
      "category",
      "merchant_category",
      "merchantcategory",
      "mcc",
      "mcc_code",
      "industry",
      "sector",
      "merchant_type",
    ],
  },
  {
    key: "paymentMethod",
    label: "Payment Method / Channel",
    category: "CORE",
    required: false,
    description: "Payment channel or instrument (e.g. Credit Card, Wire Transfer, Crypto, ACH)",
    synonyms: [
      "payment_method",
      "paymentmethod",
      "channel",
      "payment_type",
      "card_type",
      "method",
      "type",
      "instrument",
    ],
  },
  {
    key: "kycStatus",
    label: "KYC Verification Status",
    category: "IDENTITY",
    required: false,
    description: "Identity verification level (VERIFIED, PENDING, FAILED, NONE)",
    synonyms: [
      "kyc_status",
      "kycstatus",
      "kyc",
      "identity_status",
      "verification_status",
      "kyc_verified",
      "id_status",
    ],
  },
  {
    key: "accountAgeDays",
    label: "Account Age (Days)",
    category: "IDENTITY",
    required: false,
    description: "Number of days since user account creation (e.g. 450, age_days)",
    synonyms: [
      "account_age_days",
      "accountagedays",
      "account_age",
      "age_days",
      "user_age_days",
      "tenure_days",
      "account_tenure",
    ],
  },
  {
    key: "loginPatternConsistent",
    label: "Login Pattern Consistent",
    category: "IDENTITY",
    required: false,
    description: "Boolean flag (true/false) whether user authentication matched historical profile",
    synonyms: [
      "login_pattern_consistent",
      "loginpatternconsistent",
      "login_consistent",
      "known_device",
      "auth_consistent",
    ],
  },
  {
    key: "ipAddress",
    label: "IP Address",
    category: "NETWORK",
    required: false,
    description: "Client IPv4 or IPv6 address (e.g. 185.220.101.5)",
    synonyms: [
      "ip",
      "ip_address",
      "ipaddress",
      "client_ip",
      "clientip",
      "ip_addr",
      "source_ip",
      "remote_ip",
      "user_ip",
    ],
  },
  {
    key: "deviceId",
    label: "Device ID / Fingerprint",
    category: "NETWORK",
    required: false,
    description: "Hardware fingerprint, device identifier, or terminal ID",
    synonyms: [
      "device_id",
      "deviceid",
      "fingerprint",
      "device_fingerprint",
      "devicefingerprint",
      "hw_id",
      "terminal_id",
      "device",
    ],
  },
  {
    key: "isVpnOrProxy",
    label: "VPN / Proxy Flag",
    category: "NETWORK",
    required: false,
    description: "Boolean or binary (true/false/1/0) indicating VPN, proxy, or datacenter IP",
    synonyms: [
      "is_vpn_or_proxy",
      "isvpnorproxy",
      "is_vpn",
      "is_proxy",
      "vpn",
      "proxy",
      "datacenter_ip",
    ],
  },
  {
    key: "isTor",
    label: "Tor Exit Node Flag",
    category: "NETWORK",
    required: false,
    description: "Boolean or binary indicating Tor darknet routing node",
    synonyms: ["is_tor", "istor", "tor", "tor_exit", "tor_node"],
  },
  {
    key: "isEmulator",
    label: "Emulator / Rooted Device Flag",
    category: "NETWORK",
    required: false,
    description: "Boolean or binary indicating device virtualization or rooted OS",
    synonyms: [
      "is_emulator",
      "isemulator",
      "emulator",
      "is_rooted",
      "rooted",
      "jailbroken",
    ],
  },
  {
    key: "city",
    label: "City / Location",
    category: "LOCATION",
    required: false,
    description: "City name for geographic telemetry (e.g. New York, London, Tokyo, Singapore)",
    synonyms: [
      "city",
      "location",
      "transaction_city",
      "user_city",
      "location_city",
      "town",
      "tx_city",
    ],
  },
  {
    key: "country",
    label: "Country",
    category: "LOCATION",
    required: false,
    description: "Country name or ISO code (e.g. United States, UK, Japan, Germany)",
    synonyms: [
      "country",
      "country_code",
      "geo_country",
      "location_country",
      "tx_country",
      "nation",
      "country_name",
    ],
  },
  {
    key: "latitude",
    label: "Latitude",
    category: "LOCATION",
    required: false,
    description: "GPS Latitude coordinate (-90 to +90)",
    synonyms: ["latitude", "lat", "geo_lat", "location_lat", "tx_lat", "y"],
  },
  {
    key: "longitude",
    label: "Longitude",
    category: "LOCATION",
    required: false,
    description: "GPS Longitude coordinate (-180 to +180)",
    synonyms: ["longitude", "lng", "lon", "geo_lng", "geo_lon", "location_lng", "tx_lng", "x"],
  },
];

/**
 * Clean string for comparison: removes punctuation, whitespace, converts to lowercase
 */
function cleanKey(k: string): string {
  return k.toLowerCase().replace(/[^a-z0-9]/g, "");
}

/**
 * Automatically inspects CSV columns and produces a suggested ColumnMappingConfig
 */
export function autoDetectColumnMapping(headers: string[]): ColumnMappingConfig {
  const mapping: ColumnMappingConfig = {};
  const cleanedHeaderMap = new Map<string, string>();

  headers.forEach((h) => {
    cleanedHeaderMap.set(cleanKey(h), h);
  });

  for (const field of CANONICAL_FIELDS) {
    let matchedHeader: string | undefined;

    // 1. Direct exact match
    for (const syn of field.synonyms) {
      const cleanSyn = cleanKey(syn);
      if (cleanedHeaderMap.has(cleanSyn)) {
        matchedHeader = cleanedHeaderMap.get(cleanSyn);
        break;
      }
    }

    // 2. Substring match fallback if not matched yet
    if (!matchedHeader) {
      for (const h of headers) {
        const cHead = cleanKey(h);
        for (const syn of field.synonyms) {
          const cSyn = cleanKey(syn);
          if (cSyn.length >= 4 && (cHead.includes(cSyn) || cSyn.includes(cHead))) {
            matchedHeader = h;
            break;
          }
        }
        if (matchedHeader) break;
      }
    }

    if (matchedHeader) {
      (mapping as any)[field.key] = matchedHeader;
    }
  }

  return mapping;
}

/**
 * Normalizes a raw CSV record object using the explicit column mapping
 */
export function mapRawRecordWithConfig(
  raw: Record<string, any>,
  index: number,
  mapping?: ColumnMappingConfig
): RawTransaction {
  if (!raw || typeof raw !== "object") {
    return {
      transactionId: `TXN-${100000 + index}`,
      userId: `USR-${1000 + (index % 50)}`,
      amount: 100,
    };
  }

  // If explicit mapping is provided, use mapped column keys
  if (mapping && Object.keys(mapping).length > 0) {
    const getVal = (fieldKey: keyof ColumnMappingConfig) => {
      const colName = mapping[fieldKey];
      if (colName && raw[colName] !== undefined && raw[colName] !== "") {
        return raw[colName];
      }
      return undefined;
    };

    const normalized: RawTransaction = {
      ...raw,
      transactionId: getVal("transactionId") || raw.transactionId || `TXN-${100000 + index}`,
      userId: getVal("userId") || raw.userId || `USR-${1000 + (index % 100)}`,
      amount: getVal("amount") !== undefined ? getVal("amount") : raw.amount,
      currency: getVal("currency") || raw.currency || "USD",
      timestamp: getVal("timestamp") || raw.timestamp,
      merchant: getVal("merchant") || raw.merchant || "Online Gateway / Point-of-Sale",
      merchantCategory: getVal("merchantCategory") || raw.merchantCategory || "General Commerce",
      paymentMethod: getVal("paymentMethod") || raw.paymentMethod || "Credit Card",
      kycStatus: getVal("kycStatus") || raw.kycStatus,
      accountAgeDays: getVal("accountAgeDays") !== undefined ? getVal("accountAgeDays") : raw.accountAgeDays,
      loginPatternConsistent: getVal("loginPatternConsistent") !== undefined ? getVal("loginPatternConsistent") : raw.loginPatternConsistent,
      deviceId: getVal("deviceId") || raw.deviceId,
      ipAddress: getVal("ipAddress") || raw.ipAddress,
      isVpnOrProxy: getVal("isVpnOrProxy") !== undefined ? getVal("isVpnOrProxy") : raw.isVpnOrProxy,
      isTor: getVal("isTor") !== undefined ? getVal("isTor") : raw.isTor,
      isEmulator: getVal("isEmulator") !== undefined ? getVal("isEmulator") : raw.isEmulator,
      city: getVal("city") || raw.city,
      country: getVal("country") || raw.country,
      latitude: getVal("latitude") !== undefined ? getVal("latitude") : raw.latitude,
      longitude: getVal("longitude") !== undefined ? getVal("longitude") : raw.longitude,
    };

    return normalized;
  }

  // Fallback auto-detection across object keys
  const keys = Object.keys(raw);
  const findVal = (...aliases: string[]) => {
    for (const a of aliases) {
      const target = cleanKey(a);
      for (const k of keys) {
        if (cleanKey(k) === target) {
          return raw[k];
        }
      }
    }
    return undefined;
  };

  return {
    ...raw,
    transactionId: findVal("transactionid", "txid", "id", "transid", "reference", "paymentid") || `TXN-${100000 + index}`,
    userId: findVal("userid", "customerid", "accountid", "user", "clientid", "uid") || `USR-${1000 + (index % 100)}`,
    amount: findVal("amount", "amt", "total", "value", "sum", "price"),
    currency: findVal("currency", "curr", "curr_code") || "USD",
    timestamp: findVal("timestamp", "datetime", "date", "createdat", "time", "tx_date"),
    merchant: findVal("merchant", "store", "vendor", "recipient", "receiver") || "Online Gateway / Point-of-Sale",
    merchantCategory: findVal("category", "merchantcategory", "mcc", "industry") || "General Commerce",
    paymentMethod: findVal("paymentmethod", "channel", "type", "method", "cardtype") || "Credit Card",
    kycStatus: findVal("kycstatus", "kyc", "identitystatus", "verificationstatus"),
    accountAgeDays: findVal("accountagedays", "accountage", "age_days", "user_age_days"),
    loginPatternConsistent: findVal("loginpatternconsistent", "login_consistent", "known_device"),
    deviceId: findVal("deviceid", "device_id", "fingerprint", "devicefingerprint", "hw_id"),
    ipAddress: findVal("ipaddress", "ip", "client_ip", "ip_addr"),
    isVpnOrProxy: findVal("isvpnorproxy", "is_vpn", "is_proxy", "vpn", "proxy"),
    isTor: findVal("istor", "is_tor", "tor_exit", "tor"),
    isEmulator: findVal("isemulator", "is_emulator", "is_rooted", "emulator"),
    city: findVal("city", "location_city", "user_city", "town"),
    country: findVal("country", "country_code", "location_country", "geo_country"),
    latitude: findVal("latitude", "lat", "geo_lat"),
    longitude: findVal("longitude", "lng", "lon", "geo_lng"),
  };
}
