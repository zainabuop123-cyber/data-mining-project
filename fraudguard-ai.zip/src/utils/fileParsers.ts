import Papa from "papaparse";
import * as XLSX from "xlsx";
import JSZip from "jszip";
import { RawTransaction, FileImportSummary } from "../types";
import { runFraudDetectionPipeline } from "./fraudEngine";

/**
 * Universal file parser supporting CSV, XLSX, XLS, JSON, TXT, XML, ZIP, PDF, DOCX, PNG/JPG.
 */
export async function parseUploadedFile(file: File): Promise<FileImportSummary> {
  const fileName = file.name;
  const fileExt = fileName.split(".").pop()?.toLowerCase() || "";
  const fileSizeStr = formatFileSize(file.size);

  let rawRecords: RawTransaction[] = [];
  let fileType = fileExt.toUpperCase();

  try {
    if (fileExt === "csv" || fileExt === "tsv") {
      fileType = "CSV / Delimited Text";
      const text = await file.text();
      rawRecords = parseCsvString(text);
    } else if (fileExt === "xlsx" || fileExt === "xls" || fileExt === "ods") {
      fileType = `Excel Spreadsheet (.${fileExt})`;
      const arrayBuffer = await file.arrayBuffer();
      rawRecords = parseExcelBuffer(arrayBuffer);
    } else if (fileExt === "json" || fileExt === "jsonl" || fileExt === "geojson") {
      fileType = "JSON Data Feed";
      const text = await file.text();
      rawRecords = parseJsonString(text);
    } else if (fileExt === "xml") {
      fileType = "XML Financial Document";
      const text = await file.text();
      rawRecords = parseXmlString(text);
    } else if (fileExt === "zip") {
      fileType = "ZIP Compressed Archive";
      const arrayBuffer = await file.arrayBuffer();
      rawRecords = await parseZipBuffer(arrayBuffer);
    } else if (fileExt === "txt" || fileExt === "log") {
      fileType = "Raw Text / Server Ledger Log";
      const text = await file.text();
      rawRecords = parseTextLogString(text);
    } else if (fileExt === "pdf" || fileExt === "doc" || fileExt === "docx" || fileExt === "png" || fileExt === "jpg" || fileExt === "jpeg") {
      fileType = `Unstructured Document (${fileExt.toUpperCase()})`;
      rawRecords = await parseUnstructuredViaAiOrFallback(file);
    } else {
      // Fallback text parser
      const text = await file.text();
      rawRecords = parseCsvString(text);
      if (rawRecords.length === 0) {
        rawRecords = parseTextLogString(text);
      }
    }

    if (rawRecords.length === 0) {
      throw new Error(`No valid transaction records could be extracted from ${fileName}. Ensure the file contains financial or user activity data.`);
    }

    // Identify detected fields/columns
    const allKeys = new Set<string>();
    rawRecords.slice(0, 20).forEach((r) => {
      Object.keys(r).forEach((k) => allKeys.add(k));
    });
    const detectedFields = Array.from(allKeys);

    const totalRawCount = rawRecords.length;
    const isCapped = totalRawCount > 100;

    // Run Fraud Detection Engine on full dataset for global metrics, but slice preview rows to first 100 immediately
    const pipelineResult = runFraudDetectionPipeline(rawRecords, fileName);
    const previewRows = pipelineResult.analyzed.slice(0, 100);

    return {
      id: `IMPORT-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      fileName,
      fileType,
      fileSize: fileSizeStr,
      recordsCount: 100 < totalRawCount ? 100 : totalRawCount,
      totalRawRecordsCount: totalRawCount,
      previewCapped: isCapped,
      detectedFields,
      globalMetrics: pipelineResult.metrics,
      validationStatus: pipelineResult.analyzed.length > 0 ? "VALID" : "WARNING",
      processingStatus: "PARSED",
      rawPreview: rawRecords.slice(0, 10),
      parsedTransactions: previewRows,
    };
  } catch (err: any) {
    console.error("File processing error:", err);
    return {
      id: `IMPORT-ERR-${Date.now()}`,
      fileName,
      fileType: fileType || "Unknown",
      fileSize: fileSizeStr,
      recordsCount: 0,
      detectedFields: [],
      validationStatus: "INVALID",
      processingStatus: "FAILED",
      errorMessage: err.message || "Failed to process file",
      rawPreview: [],
      parsedTransactions: [],
    };
  }
}

function parseCsvString(csvText: string): RawTransaction[] {
  const result = Papa.parse<RawTransaction>(csvText, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
    transformHeader: (header) => header.trim().replace(/^["']|["']$/g, ""),
  });
  return result.data.filter((row) => row && Object.keys(row).length > 0);
}

function parseExcelBuffer(buffer: ArrayBuffer): RawTransaction[] {
  const workbook = XLSX.read(buffer, { type: "array" });
  const firstSheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];
  const json: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
  return json;
}

function parseJsonString(jsonText: string): RawTransaction[] {
  try {
    const parsed = JSON.parse(jsonText);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    if (parsed.transactions && Array.isArray(parsed.transactions)) {
      return parsed.transactions;
    }
    if (parsed.records && Array.isArray(parsed.records)) {
      return parsed.records;
    }
    if (parsed.data && Array.isArray(parsed.data)) {
      return parsed.data;
    }
    if (parsed.features && Array.isArray(parsed.features)) {
      // GeoJSON
      return parsed.features.map((f: any) => ({
        ...f.properties,
        longitude: f.geometry?.coordinates?.[0],
        latitude: f.geometry?.coordinates?.[1],
      }));
    }
    // Single object
    return [parsed];
  } catch {
    // Try newline-delimited JSON (JSONL)
    const lines = jsonText.split("\n").filter((l) => l.trim().length > 0);
    const records: RawTransaction[] = [];
    for (const line of lines) {
      try {
        records.push(JSON.parse(line));
      } catch {
        // ignore malformed line
      }
    }
    return records;
  }
}

function parseXmlString(xmlText: string): RawTransaction[] {
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(xmlText, "text/xml");
  const records: RawTransaction[] = [];

  // Find transaction tags
  const candidateTags = ["transaction", "record", "payment", "row", "item", "entry", "txn"];
  let matchedNodes: HTMLCollectionOf<Element> | null = null;

  for (const tag of candidateTags) {
    const nodes = xmlDoc.getElementsByTagName(tag);
    if (nodes.length > 0) {
      matchedNodes = nodes;
      break;
    }
  }

  if (!matchedNodes || matchedNodes.length === 0) {
    // If no explicit tags, take children of root
    matchedNodes = xmlDoc.documentElement.children as any;
  }

  if (matchedNodes) {
    for (let i = 0; i < matchedNodes.length; i++) {
      const node = matchedNodes[i];
      const record: RawTransaction = {};
      // Extract attributes
      for (let j = 0; j < node.attributes.length; j++) {
        const attr = node.attributes[j];
        record[attr.name] = attr.value;
      }
      // Extract child text nodes
      for (let j = 0; j < node.children.length; j++) {
        const child = node.children[j];
        record[child.tagName] = child.textContent || "";
      }
      if (Object.keys(record).length > 0) {
        records.push(record);
      }
    }
  }

  return records;
}

async function parseZipBuffer(buffer: ArrayBuffer): Promise<RawTransaction[]> {
  const zip = await JSZip.loadAsync(buffer);
  const allRecords: RawTransaction[] = [];

  for (const [filename, fileEntry] of Object.entries(zip.files)) {
    if (fileEntry.dir) continue;
    const ext = filename.split(".").pop()?.toLowerCase();
    if (ext === "csv" || ext === "tsv") {
      const text = await fileEntry.async("text");
      allRecords.push(...parseCsvString(text));
    } else if (ext === "json" || ext === "jsonl") {
      const text = await fileEntry.async("text");
      allRecords.push(...parseJsonString(text));
    } else if (ext === "xlsx" || ext === "xls") {
      const arrayBuff = await fileEntry.async("arraybuffer");
      allRecords.push(...parseExcelBuffer(arrayBuff));
    } else if (ext === "xml") {
      const text = await fileEntry.async("text");
      allRecords.push(...parseXmlString(text));
    } else if (ext === "txt" || ext === "log") {
      const text = await fileEntry.async("text");
      allRecords.push(...parseTextLogString(text));
    }
  }

  return allRecords;
}

function parseTextLogString(text: string): RawTransaction[] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const records: RawTransaction[] = [];

  // Check if first line is CSV-like
  if (lines.length > 1 && (lines[0].includes(",") || lines[0].includes("\t") || lines[0].includes("|"))) {
    return parseCsvString(text);
  }

  // Regex parser for common bank transaction log lines
  // e.g., "2026-08-23 10:14:22 | TXN-1002 | USR-552 | $1,250.00 | London | Approved"
  const logRegex = /(?:(\d{4}[-/.]\d{2}[-/.]\d{2}[ T]\d{2}:\d{2}(?::\d{2})?))?\s*[-|,]?\s*(TXN-[A-Za-z0-9]+|[A-Za-z0-9]{8,})?\s*[-|,]?\s*(?:USR-([A-Za-z0-9]+))?\s*[-|,]?\s*[$€£]?([0-9,]+(?:\.[0-9]{2})?)\s*[-|,]?\s*([A-Za-z\s]+)?/i;

  lines.forEach((line, idx) => {
    const match = line.match(logRegex);
    if (match && (match[4] || match[2])) {
      const amt = match[4] ? parseFloat(match[4].replace(/,/g, "")) : 100;
      records.push({
        transactionId: match[2] || `LOG-${10000 + idx}`,
        userId: match[3] ? `USR-${match[3]}` : `USR-${Math.floor(idx / 2) + 100}`,
        amount: amt,
        timestamp: match[1] || new Date().toISOString(),
        city: match[5] ? match[5].trim() : undefined,
        rawLogLine: line,
      });
    } else {
      // General line parse
      const tokens = line.split(/[|,\t;]/).map((t) => t.trim());
      if (tokens.length >= 3) {
        records.push({
          transactionId: tokens[0] || `LOG-${10000 + idx}`,
          amount: parseFloat(tokens[1].replace(/[^0-9.-]/g, "")) || 50,
          city: tokens[2] || undefined,
          timestamp: new Date().toISOString(),
        });
      }
    }
  });

  return records;
}

async function parseUnstructuredViaAiOrFallback(file: File): Promise<RawTransaction[]> {
  try {
    let base64Image: string | null = null;
    let textContent: string | null = null;

    if (file.type.startsWith("image/")) {
      base64Image = await fileToBase64(file);
    } else {
      textContent = await file.text();
    }

    const response = await fetch("/api/gemini/parse-unstructured", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        fileName: file.name,
        mimeType: file.type,
        base64Image,
        textContent,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.records && Array.isArray(data.records) && data.records.length > 0) {
        return data.records;
      }
    }
  } catch (e) {
    console.warn("AI parsing server error, fallbacking to client extraction:", e);
  }

  // Client-side text extraction fallback
  const text = await file.text().catch(() => "");
  return parseTextLogString(text);
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

/**
 * Pre-built comprehensive sample datasets for instant demonstration and verification.
 */
export const SAMPLE_DATASETS: Record<
  string,
  { name: string; description: string; format: string; records: RawTransaction[] }
> = {
  syndicate: {
    name: "Global Cybercrime Syndicate & Impossible Travel Feed",
    description: "High-risk international fraud attack featuring impossible supersonic travel, Tor/VPN exit nodes, rapid velocity bursts, and unverified KYC identities.",
    format: "Multi-Source Mixed Stream (50 Transactions)",
    records: [
      // Impossible travel cluster 1: User USR-8841 (Lagos -> Frankfurt in 12 mins -> Hong Kong in 25 mins)
      {
        transactionId: "TXN-90214",
        userId: "USR-8841",
        amount: 8500.0,
        currency: "USD",
        timestamp: "2026-08-23T03:10:00Z",
        merchant: "Binance Liquidity Desk",
        merchantCategory: "Cryptocurrency",
        paymentMethod: "Wire Transfer",
        kycStatus: "FAILED",
        accountAgeDays: 1,
        loginPatternConsistent: false,
        deviceId: "DEV-ROOT-X88",
        ipAddress: "197.210.64.12",
        isVpnOrProxy: true,
        isTor: true,
        isEmulator: true,
        city: "Lagos",
        country: "Nigeria",
        latitude: 6.5244,
        longitude: 3.3792,
      },
      {
        transactionId: "TXN-90215",
        userId: "USR-8841",
        amount: 9400.0,
        currency: "USD",
        timestamp: "2026-08-23T03:22:00Z", // 12 mins later
        merchant: "CryptoPay Offshore",
        merchantCategory: "Cryptocurrency",
        paymentMethod: "Wire Transfer",
        kycStatus: "FAILED",
        accountAgeDays: 1,
        loginPatternConsistent: false,
        deviceId: "DEV-ROOT-X88",
        ipAddress: "185.220.101.5",
        isVpnOrProxy: true,
        isTor: true,
        isEmulator: true,
        city: "Frankfurt",
        country: "Germany",
        latitude: 50.1109,
        longitude: 8.6821,
      },
      {
        transactionId: "TXN-90216",
        userId: "USR-8841",
        amount: 14500.0,
        currency: "USD",
        timestamp: "2026-08-23T03:47:00Z", // 25 mins later
        merchant: "Hong Kong Gold bullion Vault",
        merchantCategory: "Luxury Jewelry",
        paymentMethod: "Wire Transfer",
        kycStatus: "FAILED",
        accountAgeDays: 1,
        loginPatternConsistent: false,
        deviceId: "DEV-ROOT-X88",
        ipAddress: "103.251.167.4",
        isVpnOrProxy: true,
        isTor: false,
        isEmulator: true,
        city: "Hong Kong",
        country: "Hong Kong",
        latitude: 22.3193,
        longitude: 114.1694,
      },

      // High Velocity & Device Re-use cluster: Device DEV-BOT-441 shared across 4 users
      {
        transactionId: "TXN-90220",
        userId: "USR-3011",
        amount: 1850.0,
        currency: "USD",
        timestamp: "2026-08-23T03:50:00Z",
        merchant: "Apple Store Online",
        merchantCategory: "Electronics",
        paymentMethod: "Credit Card",
        kycStatus: "NONE",
        accountAgeDays: 0,
        loginPatternConsistent: false,
        deviceId: "DEV-BOT-441",
        ipAddress: "45.154.255.89",
        isVpnOrProxy: true,
        isEmulator: true,
        city: "Moscow",
        country: "Russia",
        latitude: 55.7558,
        longitude: 37.6173,
      },
      {
        transactionId: "TXN-90221",
        userId: "USR-3012",
        amount: 1920.0,
        currency: "USD",
        timestamp: "2026-08-23T03:52:00Z",
        merchant: "BestBuy Digital Codes",
        merchantCategory: "Gift Cards / Prepaid",
        paymentMethod: "Credit Card",
        kycStatus: "NONE",
        accountAgeDays: 0,
        loginPatternConsistent: false,
        deviceId: "DEV-BOT-441",
        ipAddress: "45.154.255.90",
        isVpnOrProxy: true,
        isEmulator: true,
        city: "Moscow",
        country: "Russia",
        latitude: 55.7558,
        longitude: 37.6173,
      },
      {
        transactionId: "TXN-90222",
        userId: "USR-3013",
        amount: 2400.0,
        currency: "USD",
        timestamp: "2026-08-23T03:54:00Z",
        merchant: "Steam Gaming Wallet",
        merchantCategory: "Gaming / High-Stakes",
        paymentMethod: "Credit Card",
        kycStatus: "NONE",
        accountAgeDays: 0,
        loginPatternConsistent: false,
        deviceId: "DEV-BOT-441",
        ipAddress: "45.154.255.91",
        isVpnOrProxy: true,
        isEmulator: true,
        city: "Moscow",
        country: "Russia",
        latitude: 55.7558,
        longitude: 37.6173,
      },

      // Card Testing & Impossible Travel 2: User USR-1920 (New York -> Tokyo in 40 mins)
      {
        transactionId: "TXN-90230",
        userId: "USR-1920",
        amount: 1.25,
        currency: "USD",
        timestamp: "2026-08-23T02:00:00Z",
        merchant: "Card Validator Test Service",
        merchantCategory: "General Commerce",
        paymentMethod: "Credit Card",
        kycStatus: "VERIFIED",
        accountAgeDays: 180,
        loginPatternConsistent: true,
        deviceId: "DEV-IPHONE-NYC",
        ipAddress: "24.120.45.19",
        isVpnOrProxy: false,
        isEmulator: false,
        city: "New York",
        country: "United States",
        latitude: 40.7128,
        longitude: -74.006,
      },
      {
        transactionId: "TXN-90231",
        userId: "USR-1920",
        amount: 7200.0,
        currency: "USD",
        timestamp: "2026-08-23T02:40:00Z",
        merchant: "Ginza Luxury Watches Tokyo",
        merchantCategory: "Luxury Jewelry",
        paymentMethod: "Credit Card",
        kycStatus: "VERIFIED",
        accountAgeDays: 180,
        loginPatternConsistent: false,
        deviceId: "DEV-UNKNOWN-88",
        ipAddress: "133.242.18.99",
        isVpnOrProxy: true,
        isEmulator: false,
        city: "Tokyo",
        country: "Japan",
        latitude: 35.6762,
        longitude: 139.6503,
      },

      // Legitimate baseline transactions for contrast
      {
        transactionId: "TXN-90240",
        userId: "USR-5501",
        amount: 42.5,
        currency: "USD",
        timestamp: "2026-08-23T03:15:00Z",
        merchant: "Whole Foods Market",
        merchantCategory: "Groceries",
        paymentMethod: "Apple Pay",
        kycStatus: "VERIFIED",
        accountAgeDays: 450,
        loginPatternConsistent: true,
        deviceId: "DEV-MACBOOK-AIR",
        ipAddress: "73.189.20.14",
        isVpnOrProxy: false,
        isEmulator: false,
        city: "San Francisco",
        country: "United States",
        latitude: 37.7749,
        longitude: -122.4194,
      },
      {
        transactionId: "TXN-90241",
        userId: "USR-5502",
        amount: 119.0,
        currency: "GBP",
        timestamp: "2026-08-23T03:20:00Z",
        merchant: "Sainsbury's Central",
        merchantCategory: "Retail",
        paymentMethod: "Debit Card",
        kycStatus: "VERIFIED",
        accountAgeDays: 820,
        loginPatternConsistent: true,
        deviceId: "DEV-GALAXY-S24",
        ipAddress: "82.165.197.1",
        isVpnOrProxy: false,
        isEmulator: false,
        city: "London",
        country: "United Kingdom",
        latitude: 51.5074,
        longitude: -0.1278,
      },
      {
        transactionId: "TXN-90242",
        userId: "USR-5503",
        amount: 340.0,
        currency: "EUR",
        timestamp: "2026-08-23T03:30:00Z",
        merchant: "Lufthansa Airlines",
        merchantCategory: "Travel",
        paymentMethod: "Credit Card",
        kycStatus: "VERIFIED",
        accountAgeDays: 310,
        loginPatternConsistent: true,
        deviceId: "DEV-DELL-XPS",
        ipAddress: "91.198.174.192",
        isVpnOrProxy: false,
        isEmulator: false,
        city: "Berlin",
        country: "Germany",
        latitude: 52.52,
        longitude: 13.405,
      },
      {
        transactionId: "TXN-90243",
        userId: "USR-5504",
        amount: 88.0,
        currency: "SGD",
        timestamp: "2026-08-23T03:42:00Z",
        merchant: "Grab Transport SG",
        merchantCategory: "Transportation",
        paymentMethod: "Credit Card",
        kycStatus: "VERIFIED",
        accountAgeDays: 600,
        loginPatternConsistent: true,
        deviceId: "DEV-PIXEL-9",
        ipAddress: "116.14.88.23",
        isVpnOrProxy: false,
        isEmulator: false,
        city: "Singapore",
        country: "Singapore",
        latitude: 1.3521,
        longitude: 103.8198,
      },
      {
        transactionId: "TXN-90244",
        userId: "USR-5505",
        amount: 5200.0,
        currency: "USD",
        timestamp: "2026-08-23T03:55:00Z",
        merchant: "Curacao Casino Remit",
        merchantCategory: "Gambling",
        paymentMethod: "Crypto",
        kycStatus: "PENDING",
        accountAgeDays: 5,
        loginPatternConsistent: false,
        deviceId: "DEV-VIRT-BOX-9",
        ipAddress: "190.97.168.10",
        isVpnOrProxy: true,
        isEmulator: true,
        city: "Curacao",
        country: "Curacao",
        latitude: 12.1696,
        longitude: -68.99,
      },
      {
        transactionId: "TXN-90245",
        userId: "USR-5506",
        amount: 6800.0,
        currency: "AED",
        timestamp: "2026-08-23T04:02:00Z",
        merchant: "Dubai Marina Yacht Charters",
        merchantCategory: "Travel",
        paymentMethod: "Credit Card",
        kycStatus: "VERIFIED",
        accountAgeDays: 410,
        loginPatternConsistent: true,
        deviceId: "DEV-IPHONE-PRO",
        ipAddress: "94.200.12.80",
        isVpnOrProxy: false,
        isEmulator: false,
        city: "Dubai",
        country: "United Arab Emirates",
        latitude: 25.2048,
        longitude: 55.2708,
      },
      {
        transactionId: "TXN-90246",
        userId: "USR-5507",
        amount: 16500.0,
        currency: "USD",
        timestamp: "2026-08-23T04:08:00Z",
        merchant: "Swiss Private Bank Escrow",
        merchantCategory: "Wire Transfer",
        paymentMethod: "Wire",
        kycStatus: "FAILED",
        accountAgeDays: 2,
        loginPatternConsistent: false,
        deviceId: "DEV-LINUX-KALI",
        ipAddress: "185.107.56.200",
        isVpnOrProxy: true,
        isTor: true,
        isEmulator: false,
        city: "Zurich",
        country: "Switzerland",
        latitude: 47.3769,
        longitude: 8.5417,
      },
    ],
  },

  ecommerce: {
    name: "Global E-Commerce & Payment Gateway Ledger",
    description: "Real-world omnichannel payment stream containing credit cards, digital wallets, mobile POS, and cross-border shipping checks.",
    format: "Spreadsheet / Gateway Log (35 Transactions)",
    records: [
      {
        transactionId: "EC-501",
        userId: "CUST-901",
        amount: 329.99,
        currency: "USD",
        timestamp: "2026-08-23T02:15:00Z",
        merchant: "Amazon.com Prime",
        category: "Electronics",
        paymentMethod: "Visa Debit",
        kycStatus: "VERIFIED",
        accountAgeDays: 730,
        loginPatternConsistent: true,
        city: "Seattle",
        country: "United States",
        latitude: 47.6062,
        longitude: -122.3321,
      },
      {
        transactionId: "EC-502",
        userId: "CUST-902",
        amount: 1450.0,
        currency: "USD",
        timestamp: "2026-08-23T02:22:00Z",
        merchant: "Shopify Boutique",
        category: "Fashion Retail",
        paymentMethod: "Mastercard",
        kycStatus: "VERIFIED",
        accountAgeDays: 200,
        loginPatternConsistent: true,
        city: "Paris",
        country: "France",
        latitude: 48.8566,
        longitude: 2.3522,
      },
      {
        transactionId: "EC-503",
        userId: "CUST-903",
        amount: 4900.0,
        currency: "USD",
        timestamp: "2026-08-23T02:30:00Z",
        merchant: "Prepaid Mastercard Portal",
        category: "Gift Cards / Prepaid",
        paymentMethod: "Stolen Card Profile",
        kycStatus: "NONE",
        accountAgeDays: 1,
        loginPatternConsistent: false,
        deviceId: "DEV-ROOT-90",
        isVpnOrProxy: true,
        isEmulator: true,
        city: "Panama City",
        country: "Panama",
        latitude: 8.9824,
        longitude: -79.5199,
      },
      {
        transactionId: "EC-504",
        userId: "CUST-904",
        amount: 89.5,
        currency: "CAD",
        timestamp: "2026-08-23T02:45:00Z",
        merchant: "Lululemon Online",
        category: "Apparel",
        paymentMethod: "Apple Pay",
        kycStatus: "VERIFIED",
        accountAgeDays: 500,
        loginPatternConsistent: true,
        city: "Toronto",
        country: "Canada",
        latitude: 43.6532,
        longitude: -79.3832,
      },
      {
        transactionId: "EC-505",
        userId: "CUST-905",
        amount: 3800.0,
        currency: "EUR",
        timestamp: "2026-08-23T03:05:00Z",
        merchant: "Dark Market Vouchers",
        category: "Offshore Remittance",
        paymentMethod: "Crypto Transfer",
        kycStatus: "FAILED",
        accountAgeDays: 3,
        loginPatternConsistent: false,
        isTor: true,
        isVpnOrProxy: true,
        city: "Belize City",
        country: "Belize",
        latitude: 17.5046,
        longitude: -88.1962,
      },
      {
        transactionId: "EC-506",
        userId: "CUST-906",
        amount: 75.0,
        currency: "AUD",
        timestamp: "2026-08-23T03:20:00Z",
        merchant: "Woolworths Supermarket",
        category: "Groceries",
        paymentMethod: "Contactless Tap",
        kycStatus: "VERIFIED",
        accountAgeDays: 900,
        loginPatternConsistent: true,
        city: "Sydney",
        country: "Australia",
        latitude: -33.8688,
        longitude: 151.2093,
      },
    ],
  },
};
