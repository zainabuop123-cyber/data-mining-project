import { FileImportSummary, RawTransaction, ColumnMappingConfig } from "../types";
import { formatFileSize } from "./fileParsers";
import {
  runFraudDetectionPipeline,
  runFraudDetectionPipelineAsync,
  generateSyntheticDataset,
} from "./fraudEngine";
import { autoDetectColumnMapping, mapRawRecordWithConfig } from "./columnDetector";
import type {
  WorkerOutgoingMessage,
  WorkerParseRequest,
  IngestionStage,
} from "../workers/ingestionWorker";
import Papa from "papaparse";
import * as XLSX from "xlsx";

export interface IngestionProgress {
  stage: IngestionStage;
  current: number;
  total: number;
  percent: number;
  message: string;
  rowsPerSec?: number;
  elapsedMs?: number;
}

export interface IngestionEngineOptions {
  batchSize?: number;
  previewCap?: number;
  columnMapping?: ColumnMappingConfig;
  onProgress?: (progress: IngestionProgress) => void;
  onSuccess?: (summary: FileImportSummary) => void;
  onError?: (err: Error) => void;
}

export interface ColumnInspectionResult {
  headers: string[];
  sampleRows: Record<string, any>[];
  detectedMapping: ColumnMappingConfig;
  totalRowsEstimate?: number;
  fileName: string;
  fileSizeStr: string;
}

/**
 * Fast Preliminary Inspector: reads first small chunk of the file to extract column headers,
 * sample rows, and infer initial canonical field mappings so the user can review before ingestion.
 */
export async function inspectFileColumns(file: File): Promise<ColumnInspectionResult> {
  const fileName = file.name;
  const fileSizeStr = formatFileSize(file.size);
  const ext = fileName.split(".").pop()?.toLowerCase() || "";

  if (["csv", "tsv", "txt", "log"].includes(ext) || ext === "") {
    return new Promise((resolve, reject) => {
      // Read first 128KB
      const slice = file.slice(0, 1024 * 128);
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        Papa.parse<any>(text, {
          header: true,
          preview: 15,
          dynamicTyping: true,
          skipEmptyLines: "greedy",
          complete: (results) => {
            const headers = (results.meta?.fields || []).filter((h) => h && h.trim().length > 0);
            const sampleRows = (results.data || []).slice(0, 5);
            const detectedMapping = autoDetectColumnMapping(headers);
            
            // Estimate total row count based on file size and first chunk average row bytes
            const avgRowBytes = text.length > 0 && results.data.length > 0 ? text.length / results.data.length : 120;
            const totalRowsEstimate = Math.max(results.data.length, Math.round(file.size / Math.max(avgRowBytes, 40)));

            resolve({
              headers,
              sampleRows,
              detectedMapping,
              totalRowsEstimate,
              fileName,
              fileSizeStr,
            });
          },
          error: (err) => reject(err),
        });
      };
      reader.onerror = (err) => reject(err);
      reader.readAsText(slice);
    });
  } else if (["xlsx", "xls", "ods"].includes(ext)) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const buffer = e.target?.result as ArrayBuffer;
          const workbook = XLSX.read(buffer, { type: "array" });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const rows: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
          const headers = rows.length > 0 ? Object.keys(rows[0]) : [];
          const sampleRows = rows.slice(0, 5);
          const detectedMapping = autoDetectColumnMapping(headers);

          resolve({
            headers,
            sampleRows,
            detectedMapping,
            totalRowsEstimate: rows.length,
            fileName,
            fileSizeStr,
          });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = (err) => reject(err);
      reader.readAsArrayBuffer(file);
    });
  } else if (["json", "jsonl", "geojson"].includes(ext)) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          let parsed: any;
          try {
            parsed = JSON.parse(text);
          } catch {
            const firstLine = text.split("\n")[0];
            parsed = [JSON.parse(firstLine)];
          }

          let arrayData: any[] = [];
          if (Array.isArray(parsed)) arrayData = parsed;
          else if (parsed && typeof parsed === "object") {
            arrayData = parsed.features || parsed.transactions || parsed.records || [parsed];
          }

          const sampleRows = arrayData.slice(0, 5);
          const headers = sampleRows.length > 0 ? Object.keys(sampleRows[0]) : [];
          const detectedMapping = autoDetectColumnMapping(headers);

          resolve({
            headers,
            sampleRows,
            detectedMapping,
            totalRowsEstimate: arrayData.length,
            fileName,
            fileSizeStr,
          });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = (err) => reject(err);
      reader.readAsText(file.slice(0, 1024 * 64));
    });
  }

  // Generic fallback
  return {
    headers: ["transaction_id", "user_id", "amount", "timestamp", "city", "country"],
    sampleRows: [],
    detectedMapping: {},
    totalRowsEstimate: 100,
    fileName,
    fileSizeStr,
  };
}

/**
 * Creates and runs file ingestion via Web Worker with automatic fallback to asynchronous chunked processing
 */
export function runIngestionEngine(
  file: File,
  options: IngestionEngineOptions
): { cancel: () => void } {
  let worker: Worker | null = null;
  let isCancelled = false;
  const startTime = Date.now();
  const batchSize = options.batchSize || 100;
  const previewCap = options.previewCap || 100;
  const columnMapping = options.columnMapping;

  const cancel = () => {
    isCancelled = true;
    if (worker) {
      worker.terminate();
      worker = null;
    }
  };

  const handleAsyncFallback = async () => {
    try {
      options.onProgress?.({
        stage: "READING",
        current: 0,
        total: 100,
        percent: 5,
        message: "Reading file payload into streaming buffer...",
        elapsedMs: Date.now() - startTime,
      });

      // Quick Papa parse fallback
      const text = await file.text();
      if (isCancelled) return;

      const pResult = Papa.parse<any>(text, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: "greedy",
      });

      const rows = pResult.data || [];
      const totalRaw = rows.length;

      options.onProgress?.({
        stage: "RUNNING_FRAUD_DETECTION",
        current: 0,
        total: totalRaw,
        percent: 25,
        message: `Analyzing all ${totalRaw.toLocaleString()} rows with 5-stage FraudGuard AI...`,
        elapsedMs: Date.now() - startTime,
      });

      const normalizedRaw: RawTransaction[] = rows.map((r, idx) =>
        mapRawRecordWithConfig(r, idx, columnMapping)
      );

      const pipelineResult = await runFraudDetectionPipelineAsync(
        normalizedRaw,
        file.name,
        (curr, tot, msg) => {
          if (!isCancelled) {
            options.onProgress?.({
              stage: "RUNNING_FRAUD_DETECTION",
              current: curr,
              total: tot,
              percent: Math.round((curr / tot) * 100),
              message: msg,
              elapsedMs: Date.now() - startTime,
            });
          }
        },
        batchSize,
        previewCap
      );

      if (isCancelled) return;

      const durationMs = Date.now() - startTime;
      const throughputRowsPerSec = Math.round(totalRaw / Math.max(durationMs / 1000, 0.05));

      const finalizedSummary: FileImportSummary = {
        id: `INGEST-${Date.now()}`,
        fileName: file.name,
        fileType: file.type || "CSV",
        fileSize: formatFileSize(file.size),
        recordsCount: pipelineResult.analyzed.length,
        totalRawRecordsCount: totalRaw,
        previewCapped: totalRaw > previewCap,
        processingDurationMs: durationMs,
        throughputRowsPerSec,
        globalMetrics: pipelineResult.metrics,
        columnMapping,
        detectedFields: pResult.meta?.fields || [],
        validationStatus: "VALID",
        processingStatus: "PARSED",
        rawPreview: rows.slice(0, 10),
        parsedTransactions: pipelineResult.analyzed,
      };

      options.onProgress?.({
        stage: "COMPLETED",
        current: totalRaw,
        total: totalRaw,
        percent: 100,
        message: `Completed processing ${totalRaw.toLocaleString()} rows.`,
        rowsPerSec: throughputRowsPerSec,
        elapsedMs: durationMs,
      });
      options.onSuccess?.(finalizedSummary);
    } catch (err: any) {
      if (!isCancelled) {
        options.onError?.(err instanceof Error ? err : new Error(String(err)));
      }
    }
  };

  // Check if Web Worker is supported
  if (typeof Worker !== "undefined") {
    try {
      worker = new Worker(new URL("../workers/ingestionWorker.ts", import.meta.url), {
        type: "module",
      });

      let lastProgressUpdate = 0;

      worker.onmessage = (e: MessageEvent<WorkerOutgoingMessage>) => {
        if (isCancelled) return;
        const msg = e.data;

        if (msg.type === "PROGRESS") {
          const now = Date.now();
          if (now - lastProgressUpdate > 30 || msg.percent === 100 || msg.current === msg.total) {
            lastProgressUpdate = now;
            options.onProgress?.({
              stage: msg.stage,
              current: msg.current,
              total: msg.total,
              percent: msg.percent,
              message: msg.message,
              rowsPerSec: msg.rowsPerSec,
              elapsedMs: now - startTime,
            });
          }
        } else if (msg.type === "SUCCESS") {
          worker?.terminate();
          worker = null;
          options.onProgress?.({
            stage: "COMPLETED",
            current: msg.totalRecords,
            total: msg.totalRecords,
            percent: 100,
            message: `Completed: ${msg.totalRecords.toLocaleString()} rows analyzed (${msg.throughputRowsPerSec.toLocaleString()} rows/s).`,
            rowsPerSec: msg.throughputRowsPerSec,
            elapsedMs: msg.durationMs,
          });
          options.onSuccess?.(msg.summary);
        } else if (msg.type === "ERROR") {
          worker?.terminate();
          worker = null;
          console.warn("Web Worker reported error, falling back to async processor:", msg.error);
          handleAsyncFallback();
        }
      };

      worker.onerror = (err) => {
        console.warn("Web Worker error caught, falling back to async processor:", err);
        worker?.terminate();
        worker = null;
        if (!isCancelled) handleAsyncFallback();
      };

      const isDelimited = ["csv", "tsv", "txt", "log"].some((ext) =>
        file.name.toLowerCase().endsWith(`.${ext}`)
      );

      const reader = new FileReader();
      reader.onload = (e) => {
        if (isCancelled || !worker) return;
        const buffer = e.target?.result as ArrayBuffer;
        const payload: WorkerParseRequest = {
          type: "PARSE_FILE",
          fileName: file.name,
          fileType: file.type || "DATA FILE",
          fileSizeStr: formatFileSize(file.size),
          fileData: buffer,
          isText: isDelimited,
          columnMapping,
          batchSize,
          previewCap,
        };
        worker.postMessage(payload, [buffer]);
      };
      reader.onerror = () => handleAsyncFallback();
      reader.readAsArrayBuffer(file);
    } catch (err) {
      console.warn("Failed to instantiate Web Worker, using async fallback:", err);
      handleAsyncFallback();
    }
  } else {
    handleAsyncFallback();
  }

  return { cancel };
}

/**
 * Runs synthetic big-data stress benchmark via Web Worker
 */
export function runSyntheticBenchmark(
  count: number,
  options: IngestionEngineOptions
): { cancel: () => void } {
  let worker: Worker | null = null;
  let isCancelled = false;
  const startTime = Date.now();
  const batchSize = options.batchSize || 100;
  const previewCap = options.previewCap || 100;

  const cancel = () => {
    isCancelled = true;
    if (worker) {
      worker.terminate();
      worker = null;
    }
  };

  const handleAsyncFallback = async () => {
    try {
      options.onProgress?.({
        stage: "READING",
        current: 0,
        total: count,
        percent: 5,
        message: `Allocating memory buffers for ${count.toLocaleString()} synthetic benchmark records...`,
        elapsedMs: Date.now() - startTime,
      });

      const dataset = generateSyntheticDataset(count);
      if (isCancelled) return;

      const pipelineResult = await runFraudDetectionPipelineAsync(
        dataset.records,
        dataset.name,
        (current, total, msg) => {
          if (!isCancelled) {
            options.onProgress?.({
              stage: "RUNNING_FRAUD_DETECTION",
              current,
              total,
              percent: Math.round((current / total) * 100),
              message: msg,
              elapsedMs: Date.now() - startTime,
            });
          }
        },
        batchSize,
        previewCap
      );

      if (isCancelled) return;

      const allKeys = new Set<string>();
      dataset.records.slice(0, 30).forEach((r) => {
        Object.keys(r).forEach((k) => allKeys.add(k));
      });

      const isCapped = count > previewCap;
      const previewTransactions = pipelineResult.analyzed.slice(0, previewCap);
      const durationMs = Date.now() - startTime;
      const throughputRowsPerSec = Math.round(count / Math.max(durationMs / 1000, 0.05));

      const summary: FileImportSummary = {
        id: `BENCHMARK-${Date.now()}`,
        fileName: dataset.name,
        fileType: dataset.format,
        fileSize: `${((count * 180) / 1024).toFixed(1)} KB`,
        recordsCount: previewTransactions.length,
        totalRawRecordsCount: count,
        previewCapped: isCapped,
        processingDurationMs: durationMs,
        throughputRowsPerSec,
        globalMetrics: pipelineResult.metrics,
        detectedFields: Array.from(allKeys),
        validationStatus: "VALID",
        processingStatus: "PARSED",
        rawPreview: dataset.records.slice(0, 10),
        parsedTransactions: previewTransactions,
      };

      options.onProgress?.({
        stage: "COMPLETED",
        current: count,
        total: count,
        percent: 100,
        message: `Completed processing ${count.toLocaleString()} rows.`,
        rowsPerSec: throughputRowsPerSec,
        elapsedMs: durationMs,
      });

      options.onSuccess?.(summary);
    } catch (err: any) {
      if (!isCancelled) {
        options.onError?.(err instanceof Error ? err : new Error(String(err)));
      }
    }
  };

  if (typeof Worker !== "undefined") {
    try {
      worker = new Worker(new URL("../workers/ingestionWorker.ts", import.meta.url), {
        type: "module",
      });

      let lastProgressUpdate = 0;

      worker.onmessage = (e: MessageEvent<WorkerOutgoingMessage>) => {
        if (isCancelled) return;
        const msg = e.data;

        if (msg.type === "PROGRESS") {
          const now = Date.now();
          if (now - lastProgressUpdate > 30 || msg.percent === 100 || msg.current === msg.total) {
            lastProgressUpdate = now;
            options.onProgress?.({
              stage: msg.stage,
              current: msg.current,
              total: msg.total,
              percent: msg.percent,
              message: msg.message,
              rowsPerSec: msg.rowsPerSec,
              elapsedMs: now - startTime,
            });
          }
        } else if (msg.type === "SUCCESS") {
          worker?.terminate();
          worker = null;
          options.onProgress?.({
            stage: "COMPLETED",
            current: msg.totalRecords,
            total: msg.totalRecords,
            percent: 100,
            message: `Completed: ${msg.totalRecords.toLocaleString()} rows analyzed (${msg.throughputRowsPerSec.toLocaleString()} rows/s).`,
            rowsPerSec: msg.throughputRowsPerSec,
            elapsedMs: msg.durationMs,
          });
          options.onSuccess?.(msg.summary);
        } else if (msg.type === "ERROR") {
          worker?.terminate();
          worker = null;
          console.warn("Worker error, running async benchmark fallback:", msg.error);
          handleAsyncFallback();
        }
      };

      worker.onerror = () => {
        worker?.terminate();
        worker = null;
        if (!isCancelled) handleAsyncFallback();
      };

      worker.postMessage({
        type: "PARSE_SYNTHETIC",
        syntheticCount: count,
        batchSize,
        previewCap,
      } as WorkerParseRequest);
    } catch {
      handleAsyncFallback();
    }
  } else {
    handleAsyncFallback();
  }

  return { cancel };
}
