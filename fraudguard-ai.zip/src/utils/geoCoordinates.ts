// Built-in verified city and country geographic coordinates for location intelligence
export const KNOWN_GEO_COORDINATES: Record<string, { lat: number; lng: number; country: string }> = {
  // North America
  "new york": { lat: 40.7128, lng: -74.006, country: "United States" },
  "nyc": { lat: 40.7128, lng: -74.006, country: "United States" },
  "san francisco": { lat: 37.7749, lng: -122.4194, country: "United States" },
  "los angeles": { lat: 34.0522, lng: -118.2437, country: "United States" },
  "chicago": { lat: 41.8781, lng: -87.6298, country: "United States" },
  "miami": { lat: 25.7617, lng: -80.1918, country: "United States" },
  "toronto": { lat: 43.6532, lng: -79.3832, country: "Canada" },
  "vancouver": { lat: 49.2827, lng: -123.1207, country: "Canada" },
  "mexico city": { lat: 19.4326, lng: -99.1332, country: "Mexico" },
  "austin": { lat: 30.2672, lng: -97.7431, country: "United States" },
  "seattle": { lat: 47.6062, lng: -122.3321, country: "United States" },
  "boston": { lat: 42.3601, lng: -71.0589, country: "United States" },
  "atlanta": { lat: 33.749, lng: -84.388, country: "United States" },

  // Europe
  "london": { lat: 51.5074, lng: -0.1278, country: "United Kingdom" },
  "paris": { lat: 48.8566, lng: 2.3522, country: "France" },
  "berlin": { lat: 52.52, lng: 13.405, country: "Germany" },
  "frankfurt": { lat: 50.1109, lng: 8.6821, country: "Germany" },
  "amsterdam": { lat: 52.3676, lng: 4.9041, country: "Netherlands" },
  "madrid": { lat: 40.4168, lng: -3.7038, country: "Spain" },
  "barcelona": { lat: 41.3851, lng: 2.1734, country: "Spain" },
  "rome": { lat: 41.9028, lng: 12.4964, country: "Italy" },
  "milan": { lat: 45.4642, lng: 9.19, country: "Italy" },
  "zurich": { lat: 47.3769, lng: 8.5417, country: "Switzerland" },
  "geneva": { lat: 46.2044, lng: 6.1432, country: "Switzerland" },
  "vienna": { lat: 48.2082, lng: 16.3738, country: "Austria" },
  "dublin": { lat: 53.3498, lng: -6.2603, country: "Ireland" },
  "stockholm": { lat: 59.3293, lng: 18.0686, country: "Sweden" },
  "warsaw": { lat: 52.2297, lng: 21.0122, country: "Poland" },
  "bucharest": { lat: 44.4268, lng: 26.1025, country: "Romania" },
  "kyiv": { lat: 50.4501, lng: 30.5234, country: "Ukraine" },
  "moscow": { lat: 55.7558, lng: 37.6173, country: "Russia" },
  "saint petersburg": { lat: 59.9343, lng: 30.3351, country: "Russia" },
  "istanbul": { lat: 41.0082, lng: 28.9784, country: "Turkey" },
  "cyprus": { lat: 35.1856, lng: 33.3823, country: "Cyprus" },
  "limassol": { lat: 34.6786, lng: 33.0413, country: "Cyprus" },

  // Asia / Pacific
  "singapore": { lat: 1.3521, lng: 103.8198, country: "Singapore" },
  "tokyo": { lat: 35.6762, lng: 139.6503, country: "Japan" },
  "hong kong": { lat: 22.3193, lng: 114.1694, country: "Hong Kong" },
  "seoul": { lat: 37.5665, lng: 126.978, country: "South Korea" },
  "shanghai": { lat: 31.2304, lng: 121.4737, country: "China" },
  "beijing": { lat: 39.9042, lng: 116.4074, country: "China" },
  "shenzhen": { lat: 22.5431, lng: 114.0579, country: "China" },
  "bangkok": { lat: 13.7563, lng: 100.5018, country: "Thailand" },
  "kuala lumpur": { lat: 3.139, lng: 101.6869, country: "Malaysia" },
  "jakarta": { lat: -6.2088, lng: 106.8456, country: "Indonesia" },
  "manila": { lat: 14.5995, lng: 120.9842, country: "Philippines" },
  "mumbai": { lat: 19.076, lng: 72.8777, country: "India" },
  "delhi": { lat: 28.6139, lng: 77.209, country: "India" },
  "bangalore": { lat: 12.9716, lng: 77.5946, country: "India" },
  "sydney": { lat: -33.8688, lng: 151.2093, country: "Australia" },
  "melbourne": { lat: -37.8136, lng: 144.9631, country: "Australia" },
  "auckland": { lat: -36.8485, lng: 174.7633, country: "New Zealand" },
  "taipei": { lat: 25.033, lng: 121.5654, country: "Taiwan" },
  "ho chi minh city": { lat: 10.8231, lng: 106.6297, country: "Vietnam" },
  "hanoi": { lat: 21.0285, lng: 105.8542, country: "Vietnam" },
  "phnom penh": { lat: 11.5564, lng: 104.9282, country: "Cambodia" },
  "yangon": { lat: 16.8661, lng: 96.1951, country: "Myanmar" },

  // Middle East
  "dubai": { lat: 25.2048, lng: 55.2708, country: "United Arab Emirates" },
  "abu dhabi": { lat: 24.4539, lng: 54.3773, country: "United Arab Emirates" },
  "riyadh": { lat: 24.7136, lng: 46.6753, country: "Saudi Arabia" },
  "doha": { lat: 25.2854, lng: 51.531, country: "Qatar" },
  "tel aviv": { lat: 32.0853, lng: 34.7818, country: "Israel" },
  "beirut": { lat: 33.8938, lng: 35.5018, country: "Lebanon" },
  "tehran": { lat: 35.6892, lng: 51.389, country: "Iran" },

  // Africa
  "lagos": { lat: 6.5244, lng: 3.3792, country: "Nigeria" },
  "abuja": { lat: 9.0765, lng: 7.3986, country: "Nigeria" },
  "nairobi": { lat: -1.2921, lng: 36.8219, country: "Kenya" },
  "cairo": { lat: 30.0444, lng: 31.2357, country: "Egypt" },
  "johannesburg": { lat: -26.2041, lng: 28.0473, country: "South Africa" },
  "cape town": { lat: -33.9249, lng: 18.4241, country: "South Africa" },
  "accra": { lat: 5.6037, lng: -0.187, country: "Ghana" },
  "casablanca": { lat: 33.5731, lng: -7.5898, country: "Morocco" },

  // Latin & South America
  "sao paulo": { lat: -23.5505, lng: -46.6333, country: "Brazil" },
  "rio de janeiro": { lat: -22.9068, lng: -43.1729, country: "Brazil" },
  "buenos aires": { lat: -34.6037, lng: -58.3816, country: "Argentina" },
  "bogota": { lat: 4.711, lng: -74.0721, country: "Colombia" },
  "medellin": { lat: 6.2442, lng: -75.5812, country: "Colombia" },
  "lima": { lat: -12.0464, lng: -77.0428, country: "Peru" },
  "santiago": { lat: -33.4489, lng: -70.6693, country: "Chile" },
  "caracas": { lat: 10.4806, lng: -66.9036, country: "Venezuela" },
  "panama city": { lat: 8.9824, lng: -79.5199, country: "Panama" },
  "san jose": { lat: 9.9281, lng: -84.0907, country: "Costa Rica" },
  "curacao": { lat: 12.1696, lng: -68.99, country: "Curacao" },
  "willemstad": { lat: 12.1224, lng: -68.9335, country: "Curacao" },
  "belize city": { lat: 17.5046, lng: -88.1962, country: "Belize" },
  "georgetown": { lat: 19.2869, lng: -81.3674, country: "Cayman Islands" },
  "nassau": { lat: 25.048, lng: -77.3554, country: "Bahamas" },
  "gibraltar": { lat: 36.1408, lng: -5.3536, country: "Gibraltar" },
  "valletta": { lat: 35.8989, lng: 14.5146, country: "Malta" },
  "malta": { lat: 35.9375, lng: 14.3754, country: "Malta" },

  // South Asia (previously missing — caused blank Fraud Map for this region)
  "karachi": { lat: 24.8607, lng: 67.0011, country: "Pakistan" },
  "lahore": { lat: 31.5497, lng: 74.3436, country: "Pakistan" },
  "islamabad": { lat: 33.6844, lng: 73.0479, country: "Pakistan" },
  "peshawar": { lat: 34.0151, lng: 71.5249, country: "Pakistan" },
  "rawalpindi": { lat: 33.5651, lng: 73.0169, country: "Pakistan" },
  "faisalabad": { lat: 31.4504, lng: 73.135, country: "Pakistan" },
  "multan": { lat: 30.1575, lng: 71.5249, country: "Pakistan" },
  "quetta": { lat: 30.1798, lng: 66.975, country: "Pakistan" },
  "sialkot": { lat: 32.4945, lng: 74.5229, country: "Pakistan" },
  "hyderabad": { lat: 25.396, lng: 68.3578, country: "Pakistan" },
  "gujranwala": { lat: 32.1877, lng: 74.1945, country: "Pakistan" },
  "chennai": { lat: 13.0827, lng: 80.2707, country: "India" },
  "kolkata": { lat: 22.5726, lng: 88.3639, country: "India" },
  "hyderabad india": { lat: 17.385, lng: 78.4867, country: "India" },
  "pune": { lat: 18.5204, lng: 73.8567, country: "India" },
  "ahmedabad": { lat: 23.0225, lng: 72.5714, country: "India" },
  "dhaka": { lat: 23.8103, lng: 90.4125, country: "Bangladesh" },
  "chittagong": { lat: 22.3569, lng: 91.7832, country: "Bangladesh" },
  "colombo": { lat: 6.9271, lng: 79.8612, country: "Sri Lanka" },
  "kathmandu": { lat: 27.7172, lng: 85.324, country: "Nepal" },
  "kabul": { lat: 34.5553, lng: 69.2075, country: "Afghanistan" },
};

// Country-level centroid fallback: used when the transaction's city isn't in the
// city-level table above (or no city was supplied at all), so the Fraud Map and
// geographic clustering still have somewhere to plot the transaction based on
// country alone rather than being dropped as "no location data".
export const COUNTRY_CENTROIDS: Record<string, { lat: number; lng: number }> = {
  "united states": { lat: 39.8283, lng: -98.5795 },
  "usa": { lat: 39.8283, lng: -98.5795 },
  "u.s.a.": { lat: 39.8283, lng: -98.5795 },
  "us": { lat: 39.8283, lng: -98.5795 },
  "canada": { lat: 56.1304, lng: -106.3468 },
  "mexico": { lat: 23.6345, lng: -102.5528 },
  "united kingdom": { lat: 55.3781, lng: -3.436 },
  "uk": { lat: 55.3781, lng: -3.436 },
  "france": { lat: 46.2276, lng: 2.2137 },
  "germany": { lat: 51.1657, lng: 10.4515 },
  "spain": { lat: 40.4637, lng: -3.7492 },
  "italy": { lat: 41.8719, lng: 12.5674 },
  "netherlands": { lat: 52.1326, lng: 5.2913 },
  "switzerland": { lat: 46.8182, lng: 8.2275 },
  "sweden": { lat: 60.1282, lng: 18.6435 },
  "poland": { lat: 51.9194, lng: 19.1451 },
  "ukraine": { lat: 48.3794, lng: 31.1656 },
  "russia": { lat: 61.524, lng: 105.3188 },
  "turkey": { lat: 38.9637, lng: 35.2433 },
  "china": { lat: 35.8617, lng: 104.1954 },
  "japan": { lat: 36.2048, lng: 138.2529 },
  "south korea": { lat: 35.9078, lng: 127.7669 },
  "singapore": { lat: 1.3521, lng: 103.8198 },
  "thailand": { lat: 15.870, lng: 100.9925 },
  "malaysia": { lat: 4.2105, lng: 101.9758 },
  "indonesia": { lat: -0.7893, lng: 113.9213 },
  "philippines": { lat: 12.8797, lng: 121.774 },
  "vietnam": { lat: 14.0583, lng: 108.2772 },
  "india": { lat: 20.5937, lng: 78.9629 },
  "pakistan": { lat: 30.3753, lng: 69.3451 },
  "bangladesh": { lat: 23.685, lng: 90.3563 },
  "sri lanka": { lat: 7.8731, lng: 80.7718 },
  "nepal": { lat: 28.3949, lng: 84.124 },
  "afghanistan": { lat: 33.9391, lng: 67.71 },
  "australia": { lat: -25.2744, lng: 133.7751 },
  "new zealand": { lat: -40.9006, lng: 174.886 },
  "united arab emirates": { lat: 23.4241, lng: 53.8478 },
  "uae": { lat: 23.4241, lng: 53.8478 },
  "saudi arabia": { lat: 23.8859, lng: 45.0792 },
  "qatar": { lat: 25.3548, lng: 51.1839 },
  "israel": { lat: 31.0461, lng: 34.8516 },
  "lebanon": { lat: 33.8547, lng: 35.8623 },
  "iran": { lat: 32.4279, lng: 53.688 },
  "iraq": { lat: 33.2232, lng: 43.6793 },
  "nigeria": { lat: 9.082, lng: 8.6753 },
  "kenya": { lat: -0.0236, lng: 37.9062 },
  "egypt": { lat: 26.8206, lng: 30.8025 },
  "south africa": { lat: -30.5595, lng: 22.9375 },
  "ghana": { lat: 7.9465, lng: -1.0232 },
  "morocco": { lat: 31.7917, lng: -7.0926 },
  "brazil": { lat: -14.235, lng: -51.9253 },
  "argentina": { lat: -38.4161, lng: -63.6167 },
  "colombia": { lat: 4.5709, lng: -74.2973 },
  "peru": { lat: -9.19, lng: -75.0152 },
  "chile": { lat: -35.6751, lng: -71.543 },
  "venezuela": { lat: 6.4238, lng: -66.5897 },
  "panama": { lat: 8.538, lng: -80.7821 },
  "costa rica": { lat: 9.7489, lng: -83.7534 },
  "curacao": { lat: 12.1696, lng: -68.99 },
  "belize": { lat: 17.1899, lng: -88.4976 },
  "cayman islands": { lat: 19.3133, lng: -81.2546 },
  "bahamas": { lat: 25.0343, lng: -77.3963 },
  "gibraltar": { lat: 36.1408, lng: -5.3536 },
  "malta": { lat: 35.9375, lng: 14.3754 },
  "cyprus": { lat: 35.1264, lng: 33.4299 },
  "north korea": { lat: 40.3399, lng: 127.5101 },
  "syria": { lat: 34.8021, lng: 38.9968 },
  "yemen": { lat: 15.5527, lng: 48.5164 },
  "somalia": { lat: 5.1521, lng: 46.1996 },
  "cuba": { lat: 21.5218, lng: -77.7812 },
  "belarus": { lat: 53.7098, lng: 27.9534 },
  "vanuatu": { lat: -15.3767, lng: 166.9592 },
};

// High-Risk Geographic jurisdictions (FATF blacklist/grey list, sanctioned, or elevated cyber fraud zones)
export const HIGH_RISK_GEOS = new Set([
  "russia",
  "iran",
  "north korea",
  "syria",
  "myanmar",
  "venezuela",
  "yemen",
  "somalia",
  "cuba",
  "belarus",
  "curacao",
  "cayman islands",
  "belize",
  "panama",
  "cyprus",
  "vanuatu",
]);

/**
 * Calculates great-circle distance between two points in Kilometers using Haversine formula
 */
export function calculateHaversineDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Lookup coordinates from city/country string
 */
export function resolveCoordinates(
  providedLat?: number | string | null,
  providedLng?: number | string | null,
  city?: string | null,
  country?: string | null
): { lat: number | null; lng: number | null; resolvedCity: string | null; resolvedCountry: string | null } {
  // 1. Direct coordinates
  if (
    providedLat !== undefined &&
    providedLat !== null &&
    providedLng !== undefined &&
    providedLng !== null
  ) {
    const latNum = parseFloat(String(providedLat));
    const lngNum = parseFloat(String(providedLng));
    if (!isNaN(latNum) && !isNaN(lngNum) && latNum >= -90 && latNum <= 90 && lngNum >= -180 && lngNum <= 180) {
      return {
        lat: latNum,
        lng: lngNum,
        resolvedCity: city || null,
        resolvedCountry: country || null,
      };
    }
  }

  // 2. City lookup (exact match first, then fuzzy substring match to tolerate
  //    minor spelling/formatting differences between a user's own CSV and our table)
  if (city) {
    const cleanCity = city.trim().toLowerCase();
    let entry = KNOWN_GEO_COORDINATES[cleanCity];
    if (!entry) {
      for (const key of Object.keys(KNOWN_GEO_COORDINATES)) {
        if (key.length >= 4 && (cleanCity.includes(key) || key.includes(cleanCity))) {
          entry = KNOWN_GEO_COORDINATES[key];
          break;
        }
      }
    }
    if (entry) {
      return {
        lat: entry.lat,
        lng: entry.lng,
        resolvedCity: city,
        resolvedCountry: country || entry.country,
      };
    }
  }

  // 3. Country lookup (city-level table's country entries, then the broader
  //    country-centroid table so any recognizable country still plots on the map)
  if (country) {
    const cleanCountry = country.trim().toLowerCase();
    const cityTableEntry = KNOWN_GEO_COORDINATES[cleanCountry];
    if (cityTableEntry) {
      return {
        lat: cityTableEntry.lat,
        lng: cityTableEntry.lng,
        resolvedCity: city || null,
        resolvedCountry: country,
      };
    }
    const centroid = COUNTRY_CENTROIDS[cleanCountry];
    if (centroid) {
      return {
        lat: centroid.lat,
        lng: centroid.lng,
        resolvedCity: city || null,
        resolvedCountry: country,
      };
    }
  }

  // If no geographic information is available, return nulls (NEVER fake locations!)
  return {
    lat: null,
    lng: null,
    resolvedCity: city || null,
    resolvedCountry: country || null,
  };
}
