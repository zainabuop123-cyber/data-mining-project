import {
  RawTransaction,
  AnalyzedTransaction,
  StageCheckResult,
  RiskDecision,
  DashboardMetrics,
  GeoPointSummary,
  TravelVectorSummary,
  TimeSeriesBucket,
  CategorySummary,
} from "../types";
import {
  resolveCoordinates,
  calculateHaversineDistanceKm,
  HIGH_RISK_GEOS,
} from "./geoCoordinates";

// High-Risk Merchant categories
export const HIGH_RISK_CATEGORIES = new Set([
  "cryptocurrency",
  "crypto exchange",
  "wire transfer",
  "gambling",
  "gaming / high-stakes",
  "luxury jewelry",
  "gift cards / prepaid",
  "pawn shop",
  "offshore remittance",
  "darknet",
  "arms / munitions",
]);

export interface UserTxHistoryEntry {
  time: number;
  amt: number;
  lat: number | null;
  lng: number | null;
  city: string | null;
}

/**
 * High-performance progressive streaming metric accumulator
 * Guarantees bounded memory complexity during multi-million row processing
 */
export class StreamingMetricsAccumulator {
  totalTransactions = 0;
  totalMonitoredAmount = 0;
  suspiciousAmount = 0;
  totalRiskScoreSum = 0;
  approvedCount = 0;
  reviewCount = 0;
  blockedCount = 0;
  highVelocityCount = 0;
  impossibleTravelCount = 0;
  vpnTorCount = 0;
  kycFailedCount = 0;
  missingLocationCount = 0;

  // Bounded aggregations for full dataset analysis
  private geoMap: Map<string, GeoPointSummary> = new Map();
  private travelVectorMap: Map<string, TravelVectorSummary> = new Map();
  private timeBucketMap: Map<string, TimeSeriesBucket> = new Map();
  private categoryMap: Map<string, CategorySummary> = new Map();
  private topAlertsList: AnalyzedTransaction[] = [];
  private readonly MAX_TOP_ALERTS = 50;
  private readonly MAX_GEO_CLUSTERS = 400;

  add(tx: AnalyzedTransaction): void {
    this.totalTransactions++;
    this.totalMonitoredAmount += tx.amount;
    this.totalRiskScoreSum += tx.riskScore;

    const isBlocked = tx.decision === "BLOCKED";
    const isReview = tx.decision === "REVIEW";

    if (isBlocked) {
      this.blockedCount++;
      this.suspiciousAmount += tx.amount;
    } else if (isReview) {
      this.reviewCount++;
      this.suspiciousAmount += tx.amount;
    } else {
      this.approvedCount++;
    }

    if (tx.allReasons.some((r) => r.toLowerCase().includes("velocity"))) {
      this.highVelocityCount++;
    }
    if (
      tx.allReasons.some(
        (r) =>
          r.toLowerCase().includes("impossible travel") ||
          r.toLowerCase().includes("rapid travel")
      )
    ) {
      this.impossibleTravelCount++;
    }
    if (tx.isVpnOrProxy || tx.stage3NetworkDevice.status !== "PASSED") {
      this.vpnTorCount++;
    }
    if (tx.kycStatus === "FAILED" || tx.kycStatus === "NONE") {
      this.kycFailedCount++;
    }

    // Top alerts collection (keep top 50 highest risk transactions)
    if (tx.decision !== "APPROVED" || tx.riskScore >= 60) {
      if (this.topAlertsList.length < this.MAX_TOP_ALERTS) {
        this.topAlertsList.push(tx);
        this.topAlertsList.sort((a, b) => b.riskScore - a.riskScore);
      } else if (tx.riskScore > this.topAlertsList[this.topAlertsList.length - 1].riskScore) {
        this.topAlertsList[this.topAlertsList.length - 1] = tx;
        this.topAlertsList.sort((a, b) => b.riskScore - a.riskScore);
      }
    }

    // Geographic Aggregations (bounded cluster map)
    if (tx.hasLocationData && tx.latitude !== null && tx.longitude !== null) {
      const geoKey = `${tx.latitude.toFixed(2)},${tx.longitude.toFixed(2)}`;
      let cluster = this.geoMap.get(geoKey);
      if (!cluster) {
        if (this.geoMap.size < this.MAX_GEO_CLUSTERS) {
          cluster = {
            lat: tx.latitude,
            lng: tx.longitude,
            city: tx.city || "Unknown City",
            country: tx.country || "Unknown Country",
            totalCount: 0,
            fraudCount: 0,
            blockedCount: 0,
            reviewCount: 0,
            approvedCount: 0,
            suspiciousAmount: 0,
            totalAmount: 0,
            avgRiskScore: 0,
            topRiskScore: 0,
          };
          this.geoMap.set(geoKey, cluster);
        }
      }

      if (cluster) {
        cluster.totalCount++;
        cluster.totalAmount += tx.amount;
        cluster.topRiskScore = Math.max(cluster.topRiskScore, tx.riskScore);
        if (isBlocked) {
          cluster.blockedCount++;
          cluster.fraudCount++;
          cluster.suspiciousAmount += tx.amount;
        } else if (isReview) {
          cluster.reviewCount++;
          cluster.fraudCount++;
          cluster.suspiciousAmount += tx.amount;
        } else {
          cluster.approvedCount++;
        }
        cluster.avgRiskScore = Math.round(
          ((cluster.avgRiskScore * (cluster.totalCount - 1)) + tx.riskScore) / cluster.totalCount
        );
        if (tx.decision !== "APPROVED" && (!cluster.sampleAlertReason || tx.riskScore >= cluster.topRiskScore)) {
          cluster.sampleAlertReason = tx.primaryReason;
          cluster.sampleTxId = tx.transactionId;
        }
      }
    } else {
      this.missingLocationCount++;
    }

    // Travel vectors collection
    if (
      tx.travelSpeedKmH &&
      tx.travelSpeedKmH > 400 &&
      tx.travelFromCity &&
      tx.city &&
      tx.latitude !== null &&
      tx.longitude !== null
    ) {
      const vectorKey = `${tx.travelFromCity}->${tx.city}`;
      let vector = this.travelVectorMap.get(vectorKey);
      if (!vector && this.travelVectorMap.size < 50) {
        vector = {
          fromCity: tx.travelFromCity,
          fromLat: (tx.stage4Geographic?.details?.lastLat as number) || (tx.latitude - 1),
          fromLng: (tx.stage4Geographic?.details?.lastLng as number) || (tx.longitude - 1),
          toCity: tx.city,
          toLat: tx.latitude,
          toLng: tx.longitude,
          speedKmH: tx.travelSpeedKmH,
          distanceKm: tx.travelDistanceKm || 0,
          count: 0,
          reason: tx.primaryReason,
        };
        this.travelVectorMap.set(vectorKey, vector);
      }
      if (vector) {
        vector.count++;
      }
    }

    // Time Series Bucket Aggregation
    const timeKey = tx.formattedDate ? tx.formattedDate.split(",")[0] : "Recent";
    let tBucket = this.timeBucketMap.get(timeKey);
    if (!tBucket) {
      if (this.timeBucketMap.size < 30) {
        tBucket = {
          time: timeKey,
          total: 0,
          blocked: 0,
          review: 0,
          approved: 0,
          suspiciousAmount: 0,
        };
        this.timeBucketMap.set(timeKey, tBucket);
      }
    }
    if (tBucket) {
      tBucket.total++;
      if (isBlocked) {
        tBucket.blocked++;
        tBucket.suspiciousAmount += tx.amount;
      } else if (isReview) {
        tBucket.review++;
        tBucket.suspiciousAmount += tx.amount;
      } else {
        tBucket.approved++;
      }
    }

    // Category Breakdown Aggregation
    const catKey = tx.merchantCategory || "General Commerce";
    let catBucket = this.categoryMap.get(catKey);
    if (!catBucket) {
      if (this.categoryMap.size < 30) {
        catBucket = {
          category: catKey,
          count: 0,
          fraudCount: 0,
          amount: 0,
          suspiciousAmount: 0,
        };
        this.categoryMap.set(catKey, catBucket);
      }
    }
    if (catBucket) {
      catBucket.count++;
      catBucket.amount += tx.amount;
      if (isBlocked || isReview) {
        catBucket.fraudCount++;
        catBucket.suspiciousAmount += tx.amount;
      }
    }
  }

  getMetrics(): DashboardMetrics {
    const fraudCount = this.blockedCount + this.reviewCount;
    const fraudRate =
      this.totalTransactions > 0
        ? Number(((fraudCount / this.totalTransactions) * 100).toFixed(1))
        : 0;
    const averageRiskScore =
      this.totalTransactions > 0
        ? Math.round(this.totalRiskScoreSum / this.totalTransactions)
        : 0;

    return {
      totalTransactions: this.totalTransactions,
      fraudCount,
      fraudRate,
      averageRiskScore,
      activeAlertsCount: fraudCount,
      suspiciousAmount: Math.round(this.suspiciousAmount),
      totalMonitoredAmount: Math.round(this.totalMonitoredAmount),
      approvedCount: this.approvedCount,
      reviewCount: this.reviewCount,
      blockedCount: this.blockedCount,
      highVelocityCount: this.highVelocityCount,
      impossibleTravelCount: this.impossibleTravelCount,
      vpnTorCount: this.vpnTorCount,
      kycFailedCount: this.kycFailedCount,
      missingLocationCount: this.missingLocationCount,
      geoClusters: Array.from(this.geoMap.values()),
      travelVectors: Array.from(this.travelVectorMap.values()),
      topAlerts: this.topAlertsList,
      timeSeriesData: Array.from(this.timeBucketMap.values()),
      categoryBreakdown: Array.from(this.categoryMap.values()),
    };
  }
}

/**
 * Pure evaluation function for a single transaction across all 5 FraudGuard stages
 */
export function evaluateSingleTransaction(
  raw: RawTransaction,
  index: number,
  userTxHistory: Record<string, UserTxHistoryEntry[]> = {},
  deviceUserMap: Record<string, Set<string>> = {},
  avgAmount = 250,
  stdDevAmount = 150,
  sourceFileName?: string
): AnalyzedTransaction {
  const rawId = raw.transactionId || raw.id || raw.txId || `TXN-${100000 + index}`;
  const rawUserId = raw.userId || raw.customerId || `USR-${Math.floor(index / 3) + 1000}`;

  // Parse timestamp
  let timestampMs = Date.now() - Math.max(0, 1000 - index) * 60000;
  if (raw.timestamp) {
    const parsed = new Date(raw.timestamp).getTime();
    if (!isNaN(parsed)) timestampMs = parsed;
  } else if (raw.date) {
    const combined = raw.time ? `${raw.date} ${raw.time}` : raw.date;
    const parsed = new Date(combined).getTime();
    if (!isNaN(parsed)) timestampMs = parsed;
  }

  // Parse amount
  let amount = 0;
  if (typeof raw.amount === "number") amount = raw.amount;
  else if (typeof raw.amount === "string") {
    const cleanAmt = parseFloat(String(raw.amount).replace(/[^0-9.-]+/g, ""));
    if (!isNaN(cleanAmt)) amount = cleanAmt;
  }
  amount = Math.abs(amount);

  const dateObj = new Date(timestampMs);
  const isoDate = isNaN(dateObj.getTime()) ? new Date().toISOString() : dateObj.toISOString();
  const formattedDate = isNaN(dateObj.getTime())
    ? "Recent"
    : dateObj.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });

  const merchant = raw.merchant || "Direct Transfer / Online Terminal";
  const merchantCategory = raw.merchantCategory || raw.category || "General Commerce";
  const paymentMethod = raw.paymentMethod || raw.channel || "Credit Card";
  const currency = raw.currency || "USD";

  // Resolve Location
  const geo = resolveCoordinates(
    raw.latitude || raw.lat,
    raw.longitude || raw.lng,
    raw.city,
    raw.country
  );
  const hasLocation = geo.lat !== null && geo.lng !== null;
  const prevTxs = userTxHistory[rawUserId] || [];

  // ==========================================
  // STAGE 1: Identity & Account Integrity
  // ==========================================
  const s1Flags: string[] = [];
  let s1Score = 0;
  let s1DataAvailable = false;

  let normalizedKyc: "VERIFIED" | "PENDING" | "FAILED" | "NONE" | "UNAVAILABLE" = "UNAVAILABLE";
  if (raw.kycStatus !== undefined && raw.kycStatus !== null && raw.kycStatus !== "") {
    s1DataAvailable = true;
    const kStr = String(raw.kycStatus).toUpperCase();
    if (kStr.includes("VERIF") || kStr === "PASSED") {
      normalizedKyc = "VERIFIED";
    } else if (kStr.includes("PEND") || kStr.includes("IN_PROGRESS")) {
      normalizedKyc = "PENDING";
      s1Score += 8;
      s1Flags.push("KYC Status Pending Verification");
    } else if (kStr.includes("FAIL") || kStr.includes("REJECT")) {
      normalizedKyc = "FAILED";
      s1Score += 24;
      s1Flags.push("Critical: KYC Verification Failed / Identity Mismatch");
    } else {
      normalizedKyc = "NONE";
      s1Score += 16;
      s1Flags.push("Unverified Customer Account (No KYC on file)");
    }
  }

  let accountAge: number | null = null;
  if (raw.accountAgeDays !== undefined && raw.accountAgeDays !== null && raw.accountAgeDays !== "") {
    s1DataAvailable = true;
    accountAge = Number(raw.accountAgeDays);
    if (!isNaN(accountAge)) {
      if (accountAge < 2) {
        s1Score += 20;
        s1Flags.push(`Brand New Account (${accountAge}d old) high risk transaction`);
      } else if (accountAge < 14) {
        s1Score += 10;
        s1Flags.push(`New Account (${accountAge}d old) elevated scrutiny`);
      }
    }
  }

  let loginPatternOk: boolean | null = null;
  if (raw.loginPatternConsistent !== undefined && raw.loginPatternConsistent !== null) {
    s1DataAvailable = true;
    const val = String(raw.loginPatternConsistent).toLowerCase();
    loginPatternOk = val === "true" || val === "1" || val === "yes";
    if (!loginPatternOk) {
      s1Score += 15;
      s1Flags.push("Anomalous Login Pattern / Unrecognized Auth Fingerprint");
    }
  }
  if (raw.credentialChangesRecently === true || String(raw.credentialChangesRecently).toLowerCase() === "true") {
    s1DataAvailable = true;
    s1Score += 12;
    s1Flags.push("Password/2FA Changed within 24h prior to transaction");
  }

  const stage1: StageCheckResult = {
    stageName: "Identity & Account Integrity",
    stageNumber: 1,
    dataAvailable: s1DataAvailable,
    scoreContribution: Math.min(s1Score, 25),
    status: !s1DataAvailable
      ? "UNAVAILABLE"
      : s1Score >= 20
      ? "CRITICAL"
      : s1Score > 0
      ? "FLAGGED"
      : "PASSED",
    flags: s1Flags,
    details: {
      kycStatus: normalizedKyc,
      accountAgeDays: accountAge,
      loginPatternConsistent: loginPatternOk,
    },
    summary: !s1DataAvailable
      ? "Data unavailable"
      : s1Flags.length > 0
      ? s1Flags.join("; ")
      : "Identity & KYC verified, account integrity normal.",
  };

  // ==========================================
  // STAGE 2: Behavioral & Transaction Analysis
  // ==========================================
  const s2Flags: string[] = [];
  let s2Score = 0;
  const s2DataAvailable = amount > 0 || prevTxs.length > 0;

  const recentVelocity = prevTxs.filter(
    (p) => timestampMs - p.time >= 0 && timestampMs - p.time <= 10 * 60 * 1000
  );
  if (recentVelocity.length >= 4) {
    s2Score += 24;
    s2Flags.push(`Critical Velocity Spike: ${recentVelocity.length + 1} transactions in <10 mins`);
  } else if (recentVelocity.length >= 2) {
    s2Score += 14;
    s2Flags.push(`Elevated Velocity: ${recentVelocity.length + 1} transactions in short window`);
  }

  if (amount > 0) {
    const zScore = stdDevAmount > 0 ? (amount - avgAmount) / stdDevAmount : 0;
    if (amount >= 10000) {
      s2Score += 20;
      s2Flags.push(`High Value Transfer: $${amount.toLocaleString()} exceeds tier threshold`);
    } else if (zScore > 3.0) {
      s2Score += 16;
      s2Flags.push(`Amount Anomaly: $${amount.toLocaleString()} is 3σ+ above normal baseline`);
    } else if (zScore > 2.0 && amount > 2000) {
      s2Score += 10;
      s2Flags.push(`Unusual Amount: $${amount.toLocaleString()} deviates from user baseline`);
    }
  }

  const hour = dateObj.getHours();
  if (hour >= 2 && hour <= 4 && amount > 1500) {
    s2Score += 10;
    s2Flags.push(`Off-Hours Anomaly: High-value transaction at ${hour}:00 nocturnal window`);
  }

  const cleanCategory = merchantCategory.trim().toLowerCase();
  if (
    HIGH_RISK_CATEGORIES.has(cleanCategory) ||
    cleanCategory.includes("crypto") ||
    cleanCategory.includes("wire") ||
    cleanCategory.includes("gambling")
  ) {
    s2Score += 12;
    s2Flags.push(`High-Risk Merchant Category: ${merchantCategory}`);
  }

  const stage2: StageCheckResult = {
    stageName: "Behavioral & Transaction Analysis",
    stageNumber: 2,
    dataAvailable: s2DataAvailable,
    scoreContribution: Math.min(s2Score, 25),
    status: !s2DataAvailable
      ? "UNAVAILABLE"
      : s2Score >= 20
      ? "CRITICAL"
      : s2Score > 0
      ? "FLAGGED"
      : "PASSED",
    flags: s2Flags,
    details: {
      recentVelocity: recentVelocity.length + 1,
      amount,
      merchantCategory,
    },
    summary: !s2DataAvailable
      ? "Data unavailable"
      : s2Flags.length > 0
      ? s2Flags.join("; ")
      : "Behavioral patterns & velocity within normal bounds.",
  };

  // ==========================================
  // STAGE 3: Network & Device Risk
  // ==========================================
  const s3Flags: string[] = [];
  let s3Score = 0;
  let s3DataAvailable = false;

  const devId = raw.deviceId || raw.deviceFingerprint || null;
  const ipAddr = raw.ipAddress || null;
  const isVpn =
    raw.isVpnOrProxy === true ||
    String(raw.isVpnOrProxy).toLowerCase() === "true" ||
    String(raw.isVpnOrProxy) === "1";
  const isTor =
    raw.isTor === true ||
    String(raw.isTor).toLowerCase() === "true" ||
    String(raw.isTor) === "1";
  const isEmulator =
    raw.isEmulator === true ||
    String(raw.isEmulator).toLowerCase() === "true" ||
    String(raw.isEmulator) === "1";

  if (devId || ipAddr || raw.isVpnOrProxy !== undefined || raw.isEmulator !== undefined) {
    s3DataAvailable = true;
  }

  if (isTor) {
    s3Score += 25;
    s3Flags.push("Critical: Tor Exit Node anonymizer detected");
  } else if (isVpn) {
    s3Score += 16;
    s3Flags.push("Commercial VPN / Proxy Datacenter IP detected");
  }

  if (isEmulator) {
    s3Score += 22;
    s3Flags.push("Virtual Emulator / Rooted / Headless Device detected");
  }

  if (devId && deviceUserMap[devId] && deviceUserMap[devId].size > 1) {
    const distinctUsers = deviceUserMap[devId].size;
    s3Score += Math.min(distinctUsers * 8, 24);
    s3Flags.push(`Device Fingerprint Reused across ${distinctUsers} distinct customer accounts`);
  }

  const stage3: StageCheckResult = {
    stageName: "Network & Device Risk",
    stageNumber: 3,
    dataAvailable: s3DataAvailable,
    scoreContribution: Math.min(s3Score, 25),
    status: !s3DataAvailable
      ? "UNAVAILABLE"
      : s3Score >= 20
      ? "CRITICAL"
      : s3Score > 0
      ? "FLAGGED"
      : "PASSED",
    flags: s3Flags,
    details: {
      isVpn,
      isTor,
      isEmulator,
      deviceId: devId,
      ipAddress: ipAddr,
    },
    summary: !s3DataAvailable
      ? "Data unavailable"
      : s3Flags.length > 0
      ? s3Flags.join("; ")
      : "Direct residential IP, genuine non-emulator device.",
  };

  // ==========================================
  // STAGE 4: Geographic & Location Intelligence
  // ==========================================
  const s4Flags: string[] = [];
  let s4Score = 0;
  const s4DataAvailable = hasLocation || !!raw.city || !!raw.country;

  let travelSpeedKmH: number | undefined;
  let travelDistanceKm: number | undefined;
  let travelFromCity: string | undefined;

  if (hasLocation && geo.lat !== null && geo.lng !== null) {
    // 1. Impossible Travel Calculation
    const lastLocTx = [...prevTxs].reverse().find((p) => p.lat !== null && p.lng !== null);
    if (lastLocTx && lastLocTx.lat !== null && lastLocTx.lng !== null) {
      const distKm = calculateHaversineDistanceKm(
        lastLocTx.lat,
        lastLocTx.lng,
        geo.lat,
        geo.lng
      );
      const timeDiffHours = (timestampMs - lastLocTx.time) / (1000 * 60 * 60);

      if (timeDiffHours > 0 && distKm > 50) {
        const speed = Math.round(distKm / timeDiffHours);
        travelSpeedKmH = speed;
        travelDistanceKm = distKm;
        travelFromCity = lastLocTx.city || "Previous Geo";

        if (speed > 950) {
          s4Score += 25;
          s4Flags.push(
            `Critical: Impossible Travel Anomaly (${distKm}km from ${travelFromCity} in ${(
              timeDiffHours * 60
            ).toFixed(0)} mins → ${speed} km/h)`
          );
        } else if (speed > 450) {
          s4Score += 14;
          s4Flags.push(`Rapid Travel Anomaly: ${distKm}km from ${travelFromCity} at ${speed} km/h`);
        }
      }
    }

    // 2. High-Risk Jurisdiction Check
    const targetCountry = (geo.resolvedCountry || raw.country || "").trim().toLowerCase();
    if (HIGH_RISK_GEOS.has(targetCountry)) {
      s4Score += 22;
      s4Flags.push(`High-Risk Sanctions Jurisdiction: ${geo.resolvedCountry}`);
    }

    // 3. Location Mismatch
    if (raw.cardCountry && geo.resolvedCountry) {
      const c1 = raw.cardCountry.trim().toLowerCase();
      const c2 = geo.resolvedCountry.trim().toLowerCase();
      if (c1 !== c2 && !c1.includes(c2) && !c2.includes(c1)) {
        s4Score += 12;
        s4Flags.push(`Cross-Border Mismatch: Card (${raw.cardCountry}) vs Geo (${geo.resolvedCountry})`);
      }
    }
  }

  const stage4: StageCheckResult = {
    stageName: "Geographic & Location Intelligence",
    stageNumber: 4,
    dataAvailable: s4DataAvailable,
    scoreContribution: Math.min(s4Score, 25),
    status: !s4DataAvailable
      ? "UNAVAILABLE"
      : s4Score >= 20
      ? "CRITICAL"
      : s4Score > 0
      ? "FLAGGED"
      : "PASSED",
    flags: s4Flags,
    details: {
      city: geo.resolvedCity,
      country: geo.resolvedCountry,
      latitude: geo.lat,
      longitude: geo.lng,
      travelSpeedKmH,
      travelDistanceKm,
    },
    summary: !s4DataAvailable
      ? "Data unavailable"
      : s4Flags.length > 0
      ? s4Flags.join("; ")
      : "Geographic location consistent, no travel anomalies.",
  };

  // ==========================================
  // STAGE 5: Final Risk Scoring & Decision
  // ==========================================
  const stages = [stage1, stage2, stage3, stage4];
  const availableStages = stages.filter((s) => s.dataAvailable);

  let rawCompositeScore = 0;
  if (availableStages.length > 0) {
    const sumPoints = stages.reduce((acc, s) => acc + s.scoreContribution, 0);
    const maxPossible = availableStages.length * 25;
    rawCompositeScore = Math.min(100, Math.round((sumPoints / maxPossible) * 100));
  } else {
    rawCompositeScore = amount > 5000 ? 55 : 15;
  }

  let decision: RiskDecision = "APPROVED";
  if (
    rawCompositeScore >= 75 ||
    s1Flags.some((f) => f.includes("Critical")) ||
    s4Flags.some((f) => f.includes("Impossible Travel")) ||
    isTor
  ) {
    decision = "BLOCKED";
    if (rawCompositeScore < 75) rawCompositeScore = Math.max(rawCompositeScore, 80);
  } else if (rawCompositeScore >= 40) {
    decision = "REVIEW";
  } else {
    decision = "APPROVED";
  }

  const allReasons: string[] = [
    ...s1Flags,
    ...s2Flags,
    ...s3Flags,
    ...s4Flags,
  ];

  const triggeredChecks: string[] = [];
  if (stage1.status !== "PASSED" && stage1.status !== "UNAVAILABLE") triggeredChecks.push("Identity Integrity");
  if (stage2.status !== "PASSED" && stage2.status !== "UNAVAILABLE") triggeredChecks.push("Behavioral Velocity");
  if (stage3.status !== "PASSED" && stage3.status !== "UNAVAILABLE") triggeredChecks.push("Network/Device Risk");
  if (stage4.status !== "PASSED" && stage4.status !== "UNAVAILABLE") triggeredChecks.push("Geographic Location");

  const primaryReason =
    allReasons.length > 0
      ? allReasons[0]
      : "All 5 security stages passed validation parameters. Zero anomaly vectors.";

  const stage5: StageCheckResult = {
    stageName: "Final Risk Scoring & Decision",
    stageNumber: 5,
    dataAvailable: true,
    scoreContribution: rawCompositeScore,
    status: decision === "BLOCKED" ? "CRITICAL" : decision === "REVIEW" ? "FLAGGED" : "PASSED",
    flags: [decision, `Score: ${rawCompositeScore}/100`],
    details: {
      score: rawCompositeScore,
      decision,
      activeStagesCount: availableStages.length,
    },
    summary: `Final Score: ${rawCompositeScore}/100 → Decision: ${decision}.`,
  };

  // Register in user history (capped at 5 recent txs per user to preserve memory)
  if (!userTxHistory[rawUserId]) userTxHistory[rawUserId] = [];
  userTxHistory[rawUserId].push({
    time: timestampMs,
    amt: amount,
    lat: geo.lat,
    lng: geo.lng,
    city: geo.resolvedCity,
  });
  if (userTxHistory[rawUserId].length > 5) {
    userTxHistory[rawUserId].shift();
  }

  return {
    id: String(rawId),
    transactionId: String(rawId),
    userId: String(rawUserId),
    amount,
    currency,
    timestamp: isoDate,
    formattedDate,
    merchant,
    merchantCategory,
    paymentMethod,
    kycStatus: normalizedKyc,
    accountAgeDays: accountAge,
    loginPatternConsistent: loginPatternOk,
    deviceId: devId,
    ipAddress: ipAddr,
    isVpnOrProxy: isVpn,
    isEmulator,
    city: geo.resolvedCity,
    country: geo.resolvedCountry,
    latitude: geo.lat,
    longitude: geo.lng,
    hasLocationData: hasLocation,
    stage1Identity: stage1,
    stage2Behavioral: stage2,
    stage3NetworkDevice: stage3,
    stage4Geographic: stage4,
    stage5FinalScoring: stage5,
    riskScore: rawCompositeScore,
    decision,
    triggeredChecks,
    primaryReason,
    allReasons,
    travelSpeedKmH,
    travelDistanceKm,
    travelFromCity,
    sourceFile: sourceFileName || "User Upload",
    ingestedAt: new Date().toISOString(),
  };
}

/**
 * Main Fraud Detection Pipeline (keeps only top previewCap rows for preview, accumulates all global metrics)
 */
export function runFraudDetectionPipeline(
  rawTransactions: RawTransaction[],
  sourceFileName?: string,
  previewCap = 100
): {
  analyzed: AnalyzedTransaction[];
  metrics: DashboardMetrics;
} {
  const accumulator = new StreamingMetricsAccumulator();
  const previewList: AnalyzedTransaction[] = [];
  const userTxHistory: Record<string, UserTxHistoryEntry[]> = {};
  const deviceUserMap: Record<string, Set<string>> = {};

  // First pass for device reuse map (on sample for performance)
  const sampleSize = Math.min(rawTransactions.length, 5000);
  for (let i = 0; i < sampleSize; i++) {
    const raw = rawTransactions[i];
    const devId = raw.deviceId || raw.deviceFingerprint;
    const uid = raw.userId || raw.customerId;
    if (devId && uid) {
      if (!deviceUserMap[devId]) deviceUserMap[devId] = new Set();
      deviceUserMap[devId].add(String(uid));
    }
  }

  // Calculate baseline amounts from first 1000 items
  let sumAmt = 0;
  let validCount = 0;
  const baselineCount = Math.min(rawTransactions.length, 1000);
  for (let i = 0; i < baselineCount; i++) {
    const rawAmt = rawTransactions[i].amount;
    const amt = typeof rawAmt === "number" ? rawAmt : parseFloat(String(rawAmt || "0"));
    if (!isNaN(amt) && amt > 0) {
      sumAmt += amt;
      validCount++;
    }
  }
  const avgAmt = validCount > 0 ? sumAmt / validCount : 250;

  for (let i = 0; i < rawTransactions.length; i++) {
    const analyzed = evaluateSingleTransaction(
      rawTransactions[i],
      i,
      userTxHistory,
      deviceUserMap,
      avgAmt,
      avgAmt * 0.5,
      sourceFileName
    );

    accumulator.add(analyzed);

    if (previewList.length < previewCap) {
      previewList.push(analyzed);
    }
  }

  return {
    analyzed: previewList,
    metrics: accumulator.getMetrics(),
  };
}

/**
 * Asynchronous Batch Execution of Fraud Engine with progressive accumulation
 */
export async function runFraudDetectionPipelineAsync(
  rawTransactions: RawTransaction[],
  sourceFileName?: string,
  onProgress?: (current: number, total: number, message: string) => void,
  batchSize = 100,
  previewCap = 100
): Promise<{
  analyzed: AnalyzedTransaction[];
  metrics: DashboardMetrics;
}> {
  const total = rawTransactions.length;
  const accumulator = new StreamingMetricsAccumulator();

  if (total === 0) {
    return {
      analyzed: [],
      metrics: accumulator.getMetrics(),
    };
  }

  const previewList: AnalyzedTransaction[] = [];
  const userTxHistory: Record<string, UserTxHistoryEntry[]> = {};
  const deviceUserMap: Record<string, Set<string>> = {};

  for (let i = 0; i < total; i += batchSize) {
    const batchEnd = Math.min(i + batchSize, total);

    for (let j = i; j < batchEnd; j++) {
      const analyzed = evaluateSingleTransaction(
        rawTransactions[j],
        j,
        userTxHistory,
        deviceUserMap,
        250,
        150,
        sourceFileName
      );

      accumulator.add(analyzed);

      if (previewList.length < previewCap) {
        previewList.push(analyzed);
      }
    }

    if (onProgress && (batchEnd % 500 === 0 || batchEnd === total)) {
      onProgress(
        batchEnd,
        total,
        `Evaluating multi-stage security pipeline: ${batchEnd.toLocaleString()} of ${total.toLocaleString()} records (${Math.round(
          (batchEnd / total) * 100
        )}%)...`
      );
    }

    await new Promise((resolve) => setTimeout(resolve, 0));
  }

  return {
    analyzed: previewList,
    metrics: accumulator.getMetrics(),
  };
}

/**
 * Synthetic Dataset Generator for benchmarks
 */
export function generateSyntheticDataset(count: number): {
  name: string;
  description: string;
  format: string;
  records: RawTransaction[];
} {
  const cities = [
    { city: "New York", country: "United States", lat: 40.7128, lng: -74.006 },
    { city: "London", country: "United Kingdom", lat: 51.5074, lng: -0.1278 },
    { city: "Tokyo", country: "Japan", lat: 35.6762, lng: 139.6503 },
    { city: "Singapore", country: "Singapore", lat: 1.3521, lng: 103.8198 },
    { city: "Frankfurt", country: "Germany", lat: 50.1109, lng: 8.6821 },
    { city: "Dubai", country: "United Arab Emirates", lat: 25.2048, lng: 55.2708 },
    { city: "Paris", country: "France", lat: 48.8566, lng: 2.3522 },
    { city: "Lagos", country: "Nigeria", lat: 6.5244, lng: 3.3792 },
    { city: "Sydney", country: "Australia", lat: -33.8688, lng: 151.2093 },
    { city: "Curacao", country: "Curacao", lat: 12.1696, lng: -68.99 },
    { city: "Moscow", country: "Russia", lat: 55.7558, lng: 37.6173 },
    { city: "Hong Kong", country: "Hong Kong", lat: 22.3193, lng: 114.1694 },
  ];

  const merchants = [
    { name: "Amazon Prime Pay", cat: "Retail" },
    { name: "Binance Crypto Liquidity", cat: "Cryptocurrency" },
    { name: "Apple Store Terminal", cat: "Electronics" },
    { name: "Geneva Bullion Escrow", cat: "Wire Transfer" },
    { name: "Curacao Darknet Casino", cat: "Gambling" },
    { name: "Uber Technologies SG", cat: "Transportation" },
    { name: "BestBuy Digital Codes", cat: "Gift Cards / Prepaid" },
    { name: "Ginza Luxury Timepieces", cat: "Luxury Jewelry" },
  ];

  // For very large counts, generate up to 500 sample records for immediate preview compatibility
  const generateLimit = Math.min(count, 500);
  const records: RawTransaction[] = [];
  const baseTime = Date.now() - count * 15000;

  for (let i = 0; i < generateLimit; i++) {
    const isSus = Math.random() < 0.18;
    const cityObj = cities[Math.floor(Math.random() * cities.length)];
    const m = merchants[Math.floor(Math.random() * merchants.length)];
    const userId = `USR-${Math.floor(i / 4) + 1000}`;
    const amount = isSus
      ? Math.floor(Math.random() * 12000 + 1200)
      : Math.floor(Math.random() * 380 + 15);

    records.push({
      transactionId: `TXN-SYNTH-${100000 + i}`,
      userId,
      amount,
      currency: "USD",
      timestamp: new Date(baseTime + i * 15000).toISOString(),
      merchant: m.name,
      merchantCategory: m.cat,
      paymentMethod: isSus ? "Wire Transfer" : "Credit Card",
      kycStatus: isSus ? (Math.random() > 0.4 ? "FAILED" : "PENDING") : "VERIFIED",
      accountAgeDays: isSus ? Math.floor(Math.random() * 4) : Math.floor(Math.random() * 800 + 30),
      loginPatternConsistent: !isSus,
      deviceId: isSus ? `DEV-BOT-${Math.floor(i / 10)}` : `DEV-USER-${i}`,
      ipAddress: isSus
        ? `185.220.${Math.floor(Math.random() * 250)}.${Math.floor(Math.random() * 250)}`
        : `73.189.${Math.floor(Math.random() * 250)}.${Math.floor(Math.random() * 250)}`,
      isVpnOrProxy: isSus,
      isTor: isSus && Math.random() > 0.6,
      isEmulator: isSus && Math.random() > 0.5,
      city: cityObj.city,
      country: cityObj.country,
      latitude: cityObj.lat,
      longitude: cityObj.lng,
    });
  }

  return {
    name: `High-Volume Stress Benchmark (${count.toLocaleString()} Records)`,
    description: `Synthetic high-throughput dataset designed to benchmark asynchronous Web Worker parsing, 100-record preview capping, and global aggregate metrics.`,
    format: `Stream (${count.toLocaleString()} Records)`,
    records,
  };
}
