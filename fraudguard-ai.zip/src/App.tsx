import React, { useState, useEffect } from "react";
import {
  ShieldAlert,
  ShieldCheck,
  Radio,
  UploadCloud,
  FileText,
  FileSpreadsheet,
  Activity,
  Layers,
  Sparkles,
  Database,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RefreshCw,
  Plus,
  Play,
  Pause,
  Maximize2,
  Info,
  MapPin,
  Flame,
  Zap,
} from "lucide-react";
import {
  AnalyzedTransaction,
  DashboardMetrics,
  FileImportSummary,
} from "./types";
import { SAMPLE_DATASETS } from "./utils/fileParsers";
import { runFraudDetectionPipeline } from "./utils/fraudEngine";
import { FraudMap } from "./components/FraudMap";
import { FileImporter } from "./components/FileImporter";
import { AnalyticsCharts } from "./components/AnalyticsCharts";
import { LiveAlertsPanel } from "./components/LiveAlertsPanel";
import { ModuleStatusWidget } from "./components/ModuleStatusWidget";
import { InvestigationModal } from "./components/InvestigationModal";
import { ReportExportModal } from "./components/ReportExportModal";

export default function App() {
  const [activeTab, setActiveTab] = useState<"DASHBOARD" | "LEDGER" | "IMPORTER">("DASHBOARD");
  const [transactions, setTransactions] = useState<AnalyzedTransaction[]>([]);
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalTransactions: 0,
    fraudCount: 0,
    fraudRate: 0,
    averageRiskScore: 0,
    activeAlertsCount: 0,
    suspiciousAmount: 0,
    totalMonitoredAmount: 0,
    approvedCount: 0,
    reviewCount: 0,
    blockedCount: 0,
    highVelocityCount: 0,
    impossibleTravelCount: 0,
    vpnTorCount: 0,
    kycFailedCount: 0,
  });

  const [selectedTransaction, setSelectedTransaction] = useState<AnalyzedTransaction | null>(null);
  const [investigatingTransaction, setInvestigatingTransaction] = useState<AnalyzedTransaction | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showImporterModal, setShowImporterModal] = useState(false);
  const [liveStreamActive, setLiveStreamActive] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Table search & filters
  const [ledgerSearch, setLedgerSearch] = useState("");
  const [ledgerDecisionFilter, setLedgerDecisionFilter] = useState<string>("ALL");
  const [ledgerPage, setLedgerPage] = useState(1);
  const LEDGER_PAGE_SIZE = 10;

  // Initial Load: Initialize with realistic baseline dataset
  useEffect(() => {
    const initial = SAMPLE_DATASETS.syndicate;
    const res = runFraudDetectionPipeline(initial.records, initial.name);
    setTransactions(res.analyzed);
    setMetrics(res.metrics);
  }, []);

  // Live Stream Simulation: optional real-time streaming feed
  useEffect(() => {
    if (!liveStreamActive) return;

    const cities = ["New York", "London", "Tokyo", "Berlin", "Lagos", "Frankfurt", "Dubai", "Singapore", "Paris", "Curacao", "Moscow"];
    const merchants = ["CryptoSwap Remit", "Luxury Timepieces", "Amazon Prime", "Wire Escrow", "Apple Pay Terminal", "Dark Casino"];
    const categories = ["Cryptocurrency", "Luxury Jewelry", "Electronics", "Wire Transfer", "Retail", "Gambling"];

    const interval = setInterval(() => {
      const isSus = Math.random() > 0.6;
      const city = cities[Math.floor(Math.random() * cities.length)];
      const merchantIdx = Math.floor(Math.random() * merchants.length);
      const amount = isSus ? Math.floor(Math.random() * 9000 + 1500) : Math.floor(Math.random() * 400 + 20);

      const rawNew = {
        transactionId: `LIVE-${Math.floor(100000 + Math.random() * 900000)}`,
        userId: `USR-${Math.floor(1000 + Math.random() * 9000)}`,
        amount,
        currency: "USD",
        timestamp: new Date().toISOString(),
        merchant: merchants[merchantIdx],
        merchantCategory: categories[merchantIdx],
        paymentMethod: isSus ? "Wire Transfer" : "Credit Card",
        kycStatus: isSus ? (Math.random() > 0.5 ? "FAILED" : "NONE") : "VERIFIED",
        accountAgeDays: isSus ? Math.floor(Math.random() * 3) : 240,
        loginPatternConsistent: !isSus,
        isVpnOrProxy: isSus,
        isTor: isSus && Math.random() > 0.6,
        isEmulator: isSus && Math.random() > 0.5,
        city,
      };

      setTransactions((prev) => {
        const updatedRaw = [rawNew, ...prev.map((p) => ({ ...p }))];
        const res = runFraudDetectionPipeline(updatedRaw, "Live Telemetry Feed");
        setMetrics(res.metrics);
        return res.analyzed;
      });
    }, 4500);

    return () => clearInterval(interval);
  }, [liveStreamActive]);

  const handleIngestCompleted = (summary: FileImportSummary) => {
    setTransactions(summary.parsedTransactions);
    const newMetrics =
      summary.globalMetrics ||
      runFraudDetectionPipeline(summary.parsedTransactions, summary.fileName).metrics;
    setMetrics(newMetrics);
    setShowImporterModal(false);
    setActiveTab("DASHBOARD");
    setLedgerPage(1);

    const totalCount = summary.totalRawRecordsCount || summary.recordsCount;
    setNotification(
      `Successfully ingested ${totalCount.toLocaleString()} records from "${summary.fileName}". All 5 fraud detection stages updated.`
    );
    setTimeout(() => setNotification(null), 5000);
  };

  const handleUpdateDecision = (txId: string, newDecision: "APPROVED" | "REVIEW" | "BLOCKED") => {
    setTransactions((prev) => {
      const updated = prev.map((t) => {
        if (t.id === txId) {
          const newScore = newDecision === "BLOCKED" ? Math.max(t.riskScore, 85) : newDecision === "REVIEW" ? 55 : 15;
          return {
            ...t,
            decision: newDecision,
            riskScore: newScore,
          };
        }
        return t;
      });

      // Recalculate metrics
      const blocked = updated.filter((a) => a.decision === "BLOCKED");
      const review = updated.filter((a) => a.decision === "REVIEW");
      const approved = updated.filter((a) => a.decision === "APPROVED");
      const fraudCount = blocked.length + review.length;
      const fraudRate = updated.length > 0 ? Number(((fraudCount / updated.length) * 100).toFixed(1)) : 0;
      const avgRisk = Math.round(updated.reduce((sum, a) => sum + a.riskScore, 0) / updated.length);
      const suspiciousAmount = Math.round([...blocked, ...review].reduce((sum, a) => sum + a.amount, 0));

      setMetrics((m) => ({
        ...m,
        fraudCount,
        fraudRate,
        averageRiskScore: avgRisk,
        activeAlertsCount: fraudCount,
        suspiciousAmount,
        approvedCount: approved.length,
        reviewCount: review.length,
        blockedCount: blocked.length,
      }));

      return updated;
    });
  };

  // Filtered transactions for Ledger tab
  const filteredLedger = transactions.filter((t) => {
    if (ledgerDecisionFilter !== "ALL" && t.decision !== ledgerDecisionFilter) return false;
    if (ledgerSearch.trim()) {
      const q = ledgerSearch.toLowerCase();
      return (
        t.transactionId.toLowerCase().includes(q) ||
        t.userId.toLowerCase().includes(q) ||
        t.merchant.toLowerCase().includes(q) ||
        (t.city && t.city.toLowerCase().includes(q)) ||
        (t.country && t.country.toLowerCase().includes(q)) ||
        t.primaryReason.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalLedgerPages = Math.max(1, Math.ceil(filteredLedger.length / LEDGER_PAGE_SIZE));
  const currentLedgerPage = Math.min(ledgerPage, totalLedgerPages);
  const paginatedLedger = filteredLedger.slice(
    (currentLedgerPage - 1) * LEDGER_PAGE_SIZE,
    currentLedgerPage * LEDGER_PAGE_SIZE
  );

  return (
    <div className="min-h-screen bg-[#0a0f1e] text-slate-200 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* System Status Confirmation Bar */}
      <div className="bg-[#070b16] border-b border-slate-800/80 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
          </span>
          <span className="font-mono text-cyan-300 tracking-wide font-medium">
            “FraudGuard AI is online. Multi-stage fraud detection pipeline active. Ready to analyze.”
          </span>
        </div>

        <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
          <span>Engine v4.8</span>
          <span>•</span>
          <span className="text-emerald-400">Zero Mock Rule Mandate Active</span>
          <span>•</span>
          <span>OpenStreetMap &amp; Leaflet Ready</span>
        </div>
      </div>

      {/* Main App Navigation Bar */}
      <header className="sticky top-0 z-[500] bg-[#0a0f1e]/85 backdrop-blur-xl border-b border-slate-800/80 px-4 lg:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          {/* Logo & Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 p-0.5 shadow-lg shadow-cyan-500/20">
              <div className="w-full h-full bg-[#0a0f1e] rounded-[14px] flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                  FraudGuard <span className="text-cyan-400">AI</span>
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-bold">
                  AUTONOMOUS SECOPS
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Universal Ingestion &amp; Real-Time Multi-Stage Risk Intelligence
              </p>
            </div>
          </div>

          {/* Navigation Views */}
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#0f172a]/90 border border-slate-800/90 text-xs shadow-inner">
            <button
              onClick={() => setActiveTab("DASHBOARD")}
              className={`px-3.5 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === "DASHBOARD"
                  ? "bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20 font-bold"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              Live Dashboard &amp; Map
            </button>
            <button
              onClick={() => setActiveTab("LEDGER")}
              className={`px-3.5 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === "LEDGER"
                  ? "bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20 font-bold"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              Transaction Ledger ({transactions.length})
            </button>
            <button
              onClick={() => setActiveTab("IMPORTER")}
              className={`px-3.5 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === "IMPORTER"
                  ? "bg-gradient-to-r from-cyan-500 to-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20 font-bold"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              <UploadCloud className="w-3.5 h-3.5" />
              Universal Importer
            </button>
          </div>

          {/* Actions & Live Simulator */}
          <div className="flex items-center gap-2 text-xs">
            {/* Live Feed Toggle */}
            <button
              onClick={() => setLiveStreamActive(!liveStreamActive)}
              className={`px-3 py-1.5 rounded-xl border font-semibold flex items-center gap-1.5 transition-all ${
                liveStreamActive
                  ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-300 animate-pulse shadow-sm shadow-emerald-500/20"
                  : "bg-slate-900/80 border-slate-700/70 text-slate-300 hover:bg-slate-800 hover:text-white"
              }`}
            >
              {liveStreamActive ? (
                <>
                  <Pause className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Live Stream ON</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Simulate Stream</span>
                </>
              )}
            </button>

            {/* Ingest Any File Button */}
            <button
              onClick={() => setActiveTab("IMPORTER")}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 font-bold flex items-center gap-1.5 shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
            >
              <UploadCloud className="w-4 h-4 text-slate-950" />
              Import Any File
            </button>

            {/* Generate Report Button */}
            <button
              onClick={() => setShowReportModal(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-700/70 font-semibold flex items-center gap-1.5 transition-all hover:border-slate-600"
            >
              <FileText className="w-4 h-4 text-cyan-400" />
              Audit Report
            </button>
          </div>
        </div>
      </header>

      {/* Notification Toast */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-[800] p-4 rounded-2xl bg-[#0f172a]/95 backdrop-blur-xl border border-cyan-500/40 text-slate-100 shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom-5">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-xs font-medium">{notification}</p>
        </div>
      )}

      {/* Main Workspace Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 space-y-6">
        {/* ========================================================
            TAB 1: LIVE MAP & ANALYTICS DASHBOARD
           ======================================================== */}
        {activeTab === "DASHBOARD" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Top KPI Cards */}
            <AnalyticsCharts metrics={metrics} transactions={transactions} />

            {/* Main Center Area: Map + Live Alerts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left & Center: The Real Interactive Leaflet Geographic Map (Primary Visualization) */}
              <div className="lg:col-span-2 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-cyan-400" />
                    <h2 className="text-sm font-bold uppercase tracking-wider text-slate-200">
                      Live Geographic Fraud Detection Map
                    </h2>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    OpenStreetMap &bull; Leaflet &bull; Real Lat/Lng Feeds
                  </span>
                </div>

                <FraudMap
                  transactions={transactions}
                  geoClusters={metrics.geoClusters}
                  travelVectors={metrics.travelVectors}
                  totalAnalyzedCount={metrics.totalTransactions}
                  selectedTransaction={selectedTransaction}
                  onSelectTransaction={(tx) => setSelectedTransaction(tx)}
                  onInvestigateTransaction={(tx) => setInvestigatingTransaction(tx)}
                />
              </div>

              {/* Right Panel: Live Fraud Alerts Stream */}
              <div className="h-[520px]">
                <LiveAlertsPanel
                  transactions={transactions}
                  selectedTransaction={selectedTransaction}
                  onSelectTransaction={(tx) => setSelectedTransaction(tx)}
                  onInvestigateTransaction={(tx) => setInvestigatingTransaction(tx)}
                />
              </div>
            </div>

            {/* Module Status Widget (All 5 Stages & System Health) */}
            <ModuleStatusWidget transactions={transactions} />
          </div>
        )}

        {/* ========================================================
            TAB 2: TRANSACTION LEDGER & MULTI-STAGE DIAGNOSTICS
           ======================================================== */}
        {activeTab === "LEDGER" && (
          <div className="rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 p-5 space-y-4 shadow-2xl animate-in fade-in duration-200">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                  <Database className="w-4 h-4 text-cyan-400" />
                  Full Ingested Transaction Ledger &amp; Stage Inspector
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Detailed inspection of individual records, score contributions, and decision reasons.
                </p>
              </div>

              {/* Search & Filter */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by ID, User, City, Merchant..."
                    value={ledgerSearch}
                    onChange={(e) => setLedgerSearch(e.target.value)}
                    className="pl-8 pr-3 py-1.5 rounded-xl bg-[#070b16] border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 w-64 transition-all"
                  />
                </div>

                <div className="flex items-center gap-1 text-xs">
                  <button
                    onClick={() => setLedgerDecisionFilter("ALL")}
                    className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                      ledgerDecisionFilter === "ALL"
                        ? "bg-slate-700 text-white shadow-sm"
                        : "bg-[#070b16] text-slate-400 hover:text-white border border-slate-800/80"
                    }`}
                  >
                    All ({transactions.length})
                  </button>
                  <button
                    onClick={() => setLedgerDecisionFilter("BLOCKED")}
                    className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                      ledgerDecisionFilter === "BLOCKED"
                        ? "bg-rose-500 text-white shadow-sm shadow-rose-500/20"
                        : "bg-[#070b16] text-rose-400 hover:text-rose-300 border border-slate-800/80"
                    }`}
                  >
                    Blocked ({transactions.filter((t) => t.decision === "BLOCKED").length})
                  </button>
                  <button
                    onClick={() => setLedgerDecisionFilter("REVIEW")}
                    className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                      ledgerDecisionFilter === "REVIEW"
                        ? "bg-amber-500 text-slate-950 font-bold shadow-sm shadow-amber-500/20"
                        : "bg-[#070b16] text-amber-400 hover:text-amber-300 border border-slate-800/80"
                    }`}
                  >
                    Review ({transactions.filter((t) => t.decision === "REVIEW").length})
                  </button>
                  <button
                    onClick={() => setLedgerDecisionFilter("APPROVED")}
                    className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                      ledgerDecisionFilter === "APPROVED"
                        ? "bg-emerald-500 text-slate-950 font-bold shadow-sm shadow-emerald-500/20"
                        : "bg-[#070b16] text-emerald-400 hover:text-emerald-300 border border-slate-800/80"
                    }`}
                  >
                    Approved ({transactions.filter((t) => t.decision === "APPROVED").length})
                  </button>
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-800/80 bg-[#070b16]">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#0f172a] text-slate-400 font-mono text-[11px] border-b border-slate-800">
                  <tr>
                    <th className="p-3">Transaction ID</th>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Location</th>
                    <th className="p-3">KYC &amp; Device</th>
                    <th className="p-3">Stage 1-4 Status</th>
                    <th className="p-3">Composite Score</th>
                    <th className="p-3">Decision</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                  {paginatedLedger.map((tx) => (
                    <tr key={tx.id} className="hover:bg-[#0f172a]/60 transition-colors">
                      <td className="p-3 text-cyan-400 font-bold">{tx.transactionId}</td>
                      <td className="p-3 text-slate-300">{tx.userId}</td>
                      <td className="p-3 font-bold text-white">
                        {tx.currency} {tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3 text-slate-300">
                        {tx.city ? `${tx.city}, ${tx.country || ""}` : <span className="text-slate-500 italic">No GPS</span>}
                      </td>
                      <td className="p-3">
                        <div className="flex flex-col gap-0.5 text-[10px]">
                          <span
                            className={
                              tx.kycStatus === "VERIFIED"
                                ? "text-emerald-400"
                                : tx.kycStatus === "FAILED"
                                ? "text-rose-400 font-bold"
                                : "text-slate-400"
                            }
                          >
                            KYC: {tx.kycStatus}
                          </span>
                          <span className="text-slate-500 truncate max-w-[120px]">
                            Dev: {tx.deviceId || "None"}
                          </span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1 font-sans text-[10px]">
                          <span
                            className={`px-1.5 py-0.5 rounded font-mono font-medium ${
                              tx.stage1Identity.status === "PASSED"
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                : tx.stage1Identity.status === "UNAVAILABLE"
                                ? "bg-slate-800/60 text-slate-400 border border-slate-700/40"
                                : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                            }`}
                            title={`Identity: ${tx.stage1Identity.summary}`}
                          >
                            ID
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded font-mono font-medium ${
                              tx.stage2Behavioral.status === "PASSED"
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                : tx.stage2Behavioral.status === "UNAVAILABLE"
                                ? "bg-slate-800/60 text-slate-400 border border-slate-700/40"
                                : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                            }`}
                            title={`Behavioral: ${tx.stage2Behavioral.summary}`}
                          >
                            BEH
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded font-mono font-medium ${
                              tx.stage3NetworkDevice.status === "PASSED"
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                : tx.stage3NetworkDevice.status === "UNAVAILABLE"
                                ? "bg-slate-800/60 text-slate-400 border border-slate-700/40"
                                : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                            }`}
                            title={`Network/Device: ${tx.stage3NetworkDevice.summary}`}
                          >
                            DEV
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded font-mono font-medium ${
                              tx.stage4Geographic.status === "PASSED"
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                : tx.stage4Geographic.status === "UNAVAILABLE"
                                ? "bg-slate-800/60 text-slate-400 border border-slate-700/40"
                                : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                            }`}
                            title={`Geographic: ${tx.stage4Geographic.summary}`}
                          >
                            GEO
                          </span>
                        </div>
                      </td>
                      <td className="p-3 font-bold">
                        <span
                          className={
                            tx.riskScore >= 75
                              ? "text-rose-400"
                              : tx.riskScore >= 40
                              ? "text-amber-400"
                              : "text-emerald-400"
                          }
                        >
                          {tx.riskScore}/100
                        </span>
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            tx.decision === "BLOCKED"
                              ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                              : tx.decision === "REVIEW"
                              ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                              : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          }`}
                        >
                          {tx.decision}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => {
                            setSelectedTransaction(tx);
                            setInvestigatingTransaction(tx);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-sans font-semibold text-[11px] transition-colors inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3 text-cyan-400" />
                          Forensics
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination & Ledger Stats Footer */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span>
                  Showing{" "}
                  <strong className="text-white">
                    {filteredLedger.length === 0 ? 0 : (currentLedgerPage - 1) * LEDGER_PAGE_SIZE + 1}
                  </strong>{" "}
                  to{" "}
                  <strong className="text-white">
                    {Math.min(currentLedgerPage * LEDGER_PAGE_SIZE, filteredLedger.length)}
                  </strong>{" "}
                  of <strong className="text-white">{filteredLedger.length}</strong> preview records
                  {metrics.totalTransactions > filteredLedger.length ? (
                    <span className="text-cyan-400 ml-1.5 font-mono">
                      (Total dataset: {metrics.totalTransactions.toLocaleString()} rows)
                    </span>
                  ) : null}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  disabled={currentLedgerPage <= 1}
                  onClick={() => setLedgerPage((p) => Math.max(1, p - 1))}
                  className="px-3 py-1.5 rounded-lg bg-[#070b16] border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                >
                  Previous
                </button>
                <span className="px-2 font-mono text-cyan-300">
                  Page {currentLedgerPage} of {totalLedgerPages}
                </span>
                <button
                  disabled={currentLedgerPage >= totalLedgerPages}
                  onClick={() => setLedgerPage((p) => Math.min(totalLedgerPages, p + 1))}
                  className="px-3 py-1.5 rounded-lg bg-[#070b16] border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
                >
                  Next
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 3: UNIVERSAL FILE INGESTION HUB
           ======================================================== */}
        {activeTab === "IMPORTER" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0f172a] via-[#0f172a] to-cyan-950/40 border border-slate-800 shadow-2xl flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <UploadCloud className="w-5 h-5 text-cyan-400" />
                  Universal Multi-Format Ingestion Engine
                </h2>
                <p className="text-xs text-slate-400 mt-1 max-w-2xl">
                  Upload transaction logs, ledgers, spreadsheets, invoices, receipts, and archives.
                  FraudGuard AI converts any input format into a normalized security stream and executes the mandatory 5-stage fraud detection pipeline.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab("DASHBOARD")}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Back to Dashboard
                </button>
              </div>
            </div>

            <FileImporter onIngestCompleted={handleIngestCompleted} />
          </div>
        )}
      </main>

      {/* Investigation Modal */}
      {investigatingTransaction && (
        <InvestigationModal
          transaction={investigatingTransaction}
          onClose={() => setInvestigatingTransaction(null)}
          onUpdateStatus={handleUpdateDecision}
        />
      )}

      {/* Audit Report Modal */}
      {showReportModal && (
        <ReportExportModal
          metrics={metrics}
          transactions={transactions}
          onClose={() => setShowReportModal(false)}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-[#070b16] px-6 py-4 mt-auto text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="font-mono text-slate-400">
              FraudGuard AI &bull; Certified Real-Time Multi-Stage Security Pipeline
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Supported: CSV, XLSX, XLS, JSON, PDF, ZIP, TXT, DOCX, XML, PNG, JPG</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
