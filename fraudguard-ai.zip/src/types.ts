export type RiskDecision = "APPROVED" | "REVIEW" | "BLOCKED";

export type ModuleHealthStatus = "ACTIVE" | "WARNING" | "CRITICAL" | "DATA_UNAVAILABLE";

export interface StageCheckResult {
  stageName: string;
  stageNumber: number;
  dataAvailable: boolean;
  scoreContribution: number; // 0 - 25 or weighted
  status: "PASSED" | "FLAGGED" | "CRITICAL" | "UNAVAILABLE";
  flags: string[];
  details: Record<string, any>;
  summary: string;
}

export interface RawTransaction {
  id?: string;
  transactionId?: string;
  txId?: string;
  userId?: string;
  customerId?: string;
  amount?: number | string;
  currency?: string;
  timestamp?: string | number;
  date?: string;
  time?: string;
  merchant?: string;
  merchantCategory?: string;
  category?: string;
  paymentMethod?: string;
  channel?: string;
  
  // Identity & Account fields
  kycStatus?: "VERIFIED" | "PENDING" | "FAILED" | "NONE" | string;
  accountAgeDays?: number | string;
  loginPatternConsistent?: boolean | string;
  credentialChangesRecently?: boolean | string;

  // Device & Network fields
  deviceId?: string;
  deviceFingerprint?: string;
  ipAddress?: string;
  isVpnOrProxy?: boolean | string;
  isTor?: boolean | string;
  isEmulator?: boolean | string;
  userAgent?: string;

  // Geographic fields
  city?: string;
  country?: string;
  state?: string;
  address?: string;
  latitude?: number | string;
  longitude?: number | string;
  lat?: number | string;
  lng?: number | string;
  shippingCountry?: string;
  cardCountry?: string;

  // Additional raw fields
  [key: string]: any;
}

export interface AnalyzedTransaction {
  id: string;
  transactionId: string;
  userId: string;
  amount: number;
  currency: string;
  timestamp: string; // ISO String
  formattedDate: string;
  merchant: string;
  merchantCategory: string;
  paymentMethod: string;

  // Normalized Security Fields
  kycStatus: "VERIFIED" | "PENDING" | "FAILED" | "NONE" | "UNAVAILABLE";
  accountAgeDays: number | null;
  loginPatternConsistent: boolean | null;
  deviceId: string | null;
  ipAddress: string | null;
  isVpnOrProxy: boolean | null;
  isEmulator: boolean | null;

  // Geographic intelligence
  city: string | null;
  country: string | null;
  latitude: number | null;
  longitude: number | null;
  hasLocationData: boolean;

  // 5-Stage Checks
  stage1Identity: StageCheckResult;
  stage2Behavioral: StageCheckResult;
  stage3NetworkDevice: StageCheckResult;
  stage4Geographic: StageCheckResult;
  stage5FinalScoring: StageCheckResult;

  // Final Assessment
  riskScore: number; // 0 to 100
  decision: RiskDecision;
  triggeredChecks: string[];
  primaryReason: string;
  allReasons: string[];
  
  // Travel calculation if available
  travelSpeedKmH?: number;
  travelDistanceKm?: number;
  travelFromCity?: string;

  // Source info
  sourceFile?: string;
  ingestedAt: string;
}

export interface GeoPointSummary {
  lat: number;
  lng: number;
  city: string;
  country: string;
  totalCount: number;
  fraudCount: number;
  blockedCount: number;
  reviewCount: number;
  approvedCount: number;
  suspiciousAmount: number;
  totalAmount: number;
  avgRiskScore: number;
  topRiskScore: number;
  sampleAlertReason?: string;
  sampleTxId?: string;
}

export interface TravelVectorSummary {
  fromCity: string;
  fromLat: number;
  fromLng: number;
  toCity: string;
  toLat: number;
  toLng: number;
  speedKmH: number;
  distanceKm: number;
  count: number;
  reason?: string;
}

export interface TimeSeriesBucket {
  time: string;
  total: number;
  blocked: number;
  review: number;
  approved: number;
  suspiciousAmount: number;
}

export interface CategorySummary {
  category: string;
  count: number;
  fraudCount: number;
  amount: number;
  suspiciousAmount: number;
}

export interface ColumnMappingConfig {
  transactionId?: string;
  userId?: string;
  amount?: string;
  currency?: string;
  timestamp?: string;
  date?: string;
  time?: string;
  merchant?: string;
  merchantCategory?: string;
  paymentMethod?: string;
  kycStatus?: string;
  accountAgeDays?: string;
  loginPatternConsistent?: string;
  credentialChangesRecently?: string;
  deviceId?: string;
  ipAddress?: string;
  isVpnOrProxy?: string;
  isTor?: string;
  isEmulator?: string;
  city?: string;
  country?: string;
  latitude?: string;
  longitude?: string;
}

export interface FileImportSummary {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: string;
  recordsCount: number;
  totalRawRecordsCount?: number;
  previewCapped?: boolean;
  processingDurationMs?: number;
  throughputRowsPerSec?: number;
  globalMetrics?: DashboardMetrics;
  columnMapping?: ColumnMappingConfig;
  detectedFields: string[];
  validationStatus: "VALID" | "WARNING" | "INVALID";
  processingStatus: "PARSED" | "INGESTED" | "FAILED" | "PROCESSING";
  errorMessage?: string;
  rawPreview: Record<string, any>[];
  parsedTransactions: AnalyzedTransaction[];
}

export interface DashboardMetrics {
  totalTransactions: number;
  fraudCount: number; // Blocked + Review
  fraudRate: number; // percentage e.g. 12.5
  averageRiskScore: number;
  activeAlertsCount: number;
  suspiciousAmount: number;
  totalMonitoredAmount: number;
  approvedCount: number; // Low risk (<40)
  reviewCount: number;   // Medium risk (40-74)
  blockedCount: number;  // High risk (>=75)
  highVelocityCount: number;
  impossibleTravelCount: number;
  vpnTorCount: number;
  kycFailedCount: number;
  // Deep Aggregations across full 1,000,000+ dataset
  geoClusters?: GeoPointSummary[];
  travelVectors?: TravelVectorSummary[];
  topAlerts?: AnalyzedTransaction[];
  timeSeriesData?: TimeSeriesBucket[];
  categoryBreakdown?: CategorySummary[];
  missingLocationCount?: number;
}

export interface SystemHealthData {
  status: "OPTIMAL" | "DEGRADED" | "MAINTENANCE";
  healthScore: number; // 0 - 100
  latencyMs: number;
  engineThroughputPerSec: number;
  activeRulesCount: number;
  lastHeartbeat: string;
}
