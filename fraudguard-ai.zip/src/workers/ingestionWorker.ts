import Papa from "papaparse";
import * as XLSX from "xlsx";
import JSZip from "jszip";
import {
  RawTransaction,
  FileImportSummary,
  AnalyzedTransaction,
  ColumnMappingConfig,
} from "../types";
import {
  evaluateSingleTransaction,
  StreamingMetricsAccumulator,
  UserTxHistoryEntry,
} from "../utils/fraudEngine";
import { mapRawRecordWithConfig } from "../utils/columnDetector";

const DEFAULT_PREVIEW_CAP = 100;

export interface WorkerParseRequest {
  type: "PARSE_FILE" | "PARSE_SYNTHETIC";
  fileName?: string;
  fileType?: string;
  fileSizeStr?: string;
  fileData?: ArrayBuffer | string;
  isText?: boolean;
  columnMapping?: ColumnMappingConfig;
  syntheticCount?: number;
  batchSize?: number;
  previewCap?: number;
}

export type IngestionStage =
  | "UPLOADING"
  | "READING"
  | "DETECTING_COLUMNS"
  | "PROCESSING_ROWS"
  | "RUNNING_FRAUD_DETECTION"
  | "CALCULATING_METRICS"
  | "UPDATING_MAP"
  | "COMPLETED";

export interface WorkerProgressMessage {
  type: "PROGRESS";
  stage: IngestionStage;
  current: number;
  total: number;
  percent: number;
  message: string;
  rowsPerSec?: number;
}

export interface WorkerSuccessMessage {
  type: "SUCCESS";
  summary: FileImportSummary;
  totalRecords: number;
  previewCapped: boolean;
  durationMs: number;
  throughputRowsPerSec: number;
}

export interface WorkerErrorMessage {
  type: "ERROR";
  error: string;
}

export type WorkerOutgoingMessage =
  | WorkerProgressMessage
  | WorkerSuccessMessage
  | WorkerErrorMessage;

function postProgress(
  stage: IngestionStage,
  current: number,
  total: number,
  message: string,
  startTime: number
) {
  const percent = total > 0 ? Math.min(100, Math.round((current / total) * 100)) : 0;
  const elapsedSec = Math.max((Date.now() - startTime) / 1000, 0.05);
  const rowsPerSec = Math.round(current / elapsedSec);

  const payload: WorkerProgressMessage = {
    type: "PROGRESS",
    stage,
    current,
    total,
    percent,
    message,
    rowsPerSec,
  };
  self.postMessage(payload);
}

const CITIES = [
  { city: "New York", country: "United States", lat: 40.7128, lng: -74.006 },
  { city: "London", country: "United Kingdom", lat: 51.5074, lng: -0.1278 },
  { city: "Tokyo", country: "Japan", lat: 35.6762, lng: 139.6503 },
  { city: "Singapore", country: "Singapore", lat: 1.3521, lng: 103.8198 },
  { city: "Frankfurt", country: "Germany", lat: 50.1109, lng: 8.6821 },
  { city: "Dubai", country: "United Arab Emirates", lat: 25.2048, lng: 55.2708 },
  { city: "Paris", country: "France", lat: 48.8566, lng: 2.3522 },
  { city: "Lagos", country: "Nigeria", lat: 6.5244, lng: 3.3792 },
  { city: "Sydney", country: "Australia", lat: -33.8688, lng: 151.2093 },
  { city: "Curacao", country: "Curacao", lat: 12.1696, lng: -68.99 },
  { city: "Moscow", country: "Russia", lat: 55.7558, lng: 37.6173 },
  { city: "Hong Kong", country: "Hong Kong", lat: 22.3193, lng: 114.1694 },
];

const MERCHANTS = [
  { name: "Amazon Prime Pay", cat: "Retail" },
  { name: "Binance Crypto Liquidity", cat: "Cryptocurrency" },
  { name: "Apple Store Terminal", cat: "Electronics" },
  { name: "Geneva Bullion Escrow", cat: "Wire Transfer" },
  { name: "Curacao Darknet Casino", cat: "Gambling" },
  { name: "Uber Technologies SG", cat: "Transportation" },
  { name: "BestBuy Digital Codes", cat: "Gift Cards / Prepaid" },
  { name: "Ginza Luxury Timepieces", cat: "Luxury Jewelry" },
];

// Main worker message listener
self.onmessage = async (e: MessageEvent<WorkerParseRequest>) => {
  const data = e.data;
  const startTime = Date.now();
  const previewCap = data.previewCap || DEFAULT_PREVIEW_CAP; // strictly max 100 rows
  const columnMapping = data.columnMapping;

  const accumulator = new StreamingMetricsAccumulator();
  const previewRows: AnalyzedTransaction[] = [];
  const rawPreviewSamples: Record<string, any>[] = [];
  const allDetectedKeys = new Set<string>();
  const userTxHistory: Record<string, UserTxHistoryEntry[]> = {};
  const deviceUserMap: Record<string, Set<string>> = {};

  let fileName = data.fileName || "Uploaded-File";
  let fileType = data.fileType || "UNKNOWN";
  let fileSizeStr = data.fileSizeStr || "0 KB";
  let processedRowCount = 0;

  try {
    // -------------------------------------------------------------
    // Scenario 1: Big-Data Synthetic Benchmark (up to millions of rows)
    // -------------------------------------------------------------
    if (data.type === "PARSE_SYNTHETIC") {
      const targetCount = data.syntheticCount || 1270076;
      fileName = `Big-Data Stress Benchmark (${targetCount.toLocaleString()} Rows)`;
      fileType = "SYNTHETIC STREAM";
      fileSizeStr = `${((targetCount * 140) / (1024 * 1024)).toFixed(1)} MB`;

      postProgress(
        "READING",
        0,
        targetCount,
        `Allocating streaming memory buffers for ${targetCount.toLocaleString()} rows...`,
        startTime
      );

      postProgress(
        "DETECTING_COLUMNS",
        0,
        targetCount,
        `Mapping synthetic telemetry schema across 5 fraud vectors...`,
        startTime
      );

      const chunkSize = 10000;
      const baseTime = Date.now() - targetCount * 5000;

      for (let i = 0; i < targetCount; i += chunkSize) {
        const currentChunkEnd = Math.min(i + chunkSize, targetCount);

        for (let j = i; j < currentChunkEnd; j++) {
          const isSus = (j % 7 === 0) || (j % 19 === 0);
          const cityObj = CITIES[j % CITIES.length];
          const m = MERCHANTS[j % MERCHANTS.length];
          const userId = `USR-${(j % 500) + 1000}`;
          const amount = isSus
            ? Math.floor(((j * 37) % 12000) + 1200)
            : Math.floor(((j * 13) % 400) + 15);

          const raw: RawTransaction = {
            transactionId: `TXN-SYNTH-${100000 + j}`,
            userId,
            amount,
            currency: "USD",
            timestamp: new Date(baseTime + j * 5000).toISOString(),
            merchant: m.name,
            merchantCategory: m.cat,
            paymentMethod: isSus ? "Wire Transfer" : "Credit Card",
            kycStatus: isSus ? (j % 3 === 0 ? "FAILED" : "PENDING") : "VERIFIED",
            accountAgeDays: isSus ? (j % 5) : 365 + (j % 400),
            loginPatternConsistent: !isSus,
            deviceId: isSus ? `DEV-BOT-${j % 20}` : `DEV-USER-${j % 500}`,
            ipAddress: isSus
              ? `185.220.${(j * 3) % 250}.${(j * 7) % 250}`
              : `73.189.${(j * 5) % 250}.${(j * 11) % 250}`,
            isVpnOrProxy: isSus,
            isTor: isSus && j % 3 === 0,
            isEmulator: isSus && j % 2 === 0,
            city: cityObj.city,
            country: cityObj.country,
            latitude: cityObj.lat,
            longitude: cityObj.lng,
          };

          if (j < 10) {
            rawPreviewSamples.push(raw);
          }
          if (j < 50) {
            Object.keys(raw).forEach((k) => allDetectedKeys.add(k));
          }

          const evaluated = evaluateSingleTransaction(
            raw,
            j,
            userTxHistory,
            deviceUserMap,
            250,
            150,
            fileName
          );

          if (previewRows.length < previewCap) {
            previewRows.push(evaluated);
          }

          accumulator.add(evaluated);
          processedRowCount++;
        }

        if (processedRowCount % 25000 === 0 || processedRowCount === targetCount) {
          postProgress(
            "RUNNING_FRAUD_DETECTION",
            processedRowCount,
            targetCount,
            `Processing: ${processedRowCount.toLocaleString()} / ${targetCount.toLocaleString()} rows (${Math.round(
              (processedRowCount / targetCount) * 100
            )}%)...`,
            startTime
          );
          // Yield to event loop
          await new Promise((resolve) => setTimeout(resolve, 0));
        }
      }
    } else {
      // -------------------------------------------------------------
      // Scenario 2: Real Uploaded File (CSV, TSV, XLSX, JSON, ZIP, TXT)
      // -------------------------------------------------------------
      const ext = fileName.split(".").pop()?.toLowerCase() || "";
      postProgress("READING", 0, 100, `Reading payload and initializing streaming parser...`, startTime);

      if (["csv", "tsv", "txt", "log"].includes(ext) || data.isText) {
        const textContent =
          typeof data.fileData === "string"
            ? data.fileData
            : new TextDecoder().decode(data.fileData);

        postProgress("DETECTING_COLUMNS", 0, 100, `Applying verified column mappings...`, startTime);

        // Approximate total line count for progress
        const estimatedTotalLines = Math.max(100, Math.round(textContent.length / 120));

        await new Promise<void>((resolve, reject) => {
          Papa.parse<any>(textContent, {
            header: true,
            dynamicTyping: true,
            skipEmptyLines: "greedy",
            chunkSize: 1024 * 64, // 64KB chunks
            chunk: (results) => {
              const rows = results.data || [];
              for (let i = 0; i < rows.length; i++) {
                const idx = processedRowCount;
                const raw = mapRawRecordWithConfig(rows[i], idx, columnMapping);

                if (idx < 10) rawPreviewSamples.push(rows[i]);
                if (idx < 50) Object.keys(rows[i]).forEach((k) => allDetectedKeys.add(k));

                const evaluated = evaluateSingleTransaction(
                  raw,
                  idx,
                  userTxHistory,
                  deviceUserMap,
                  250,
                  150,
                  fileName
                );

                if (previewRows.length < previewCap) {
                  previewRows.push(evaluated);
                }

                accumulator.add(evaluated);
                processedRowCount++;
              }

              postProgress(
                "RUNNING_FRAUD_DETECTION",
                processedRowCount,
                Math.max(processedRowCount, estimatedTotalLines),
                `Processing: ${processedRowCount.toLocaleString()} rows analyzed...`,
                startTime
              );
            },
            complete: () => {
              resolve();
            },
            error: (err) => {
              reject(err);
            },
          });
        });
      } else if (["xlsx", "xls", "ods"].includes(ext)) {
        postProgress("READING", 0, 100, `Decoding spreadsheet binary...`, startTime);
        const workbook = XLSX.read(data.fileData, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rows: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
        const totalRows = rows.length;

        postProgress("DETECTING_COLUMNS", 0, totalRows, `Applying verified column mappings...`, startTime);

        for (let i = 0; i < totalRows; i++) {
          const raw = mapRawRecordWithConfig(rows[i], i, columnMapping);
          if (i < 10) rawPreviewSamples.push(rows[i]);
          if (i < 50) Object.keys(rows[i]).forEach((k) => allDetectedKeys.add(k));

          const evaluated = evaluateSingleTransaction(
            raw,
            i,
            userTxHistory,
            deviceUserMap,
            250,
            150,
            fileName
          );

          if (previewRows.length < previewCap) {
            previewRows.push(evaluated);
          }

          accumulator.add(evaluated);
          processedRowCount++;

          if (i % 250 === 0 || i === totalRows - 1) {
            postProgress(
              "RUNNING_FRAUD_DETECTION",
              i + 1,
              totalRows,
              `Processing: ${(i + 1).toLocaleString()} / ${totalRows.toLocaleString()} rows...`,
              startTime
            );
          }
        }
      } else if (["json", "jsonl", "geojson"].includes(ext)) {
        postProgress("READING", 0, 100, `Streaming structured JSON records...`, startTime);
        const textContent =
          typeof data.fileData === "string"
            ? data.fileData
            : new TextDecoder().decode(data.fileData);

        let jsonParsed: any;
        try {
          jsonParsed = JSON.parse(textContent);
        } catch {
          const lines = textContent.split("\n").filter((l) => l.trim().length > 0);
          jsonParsed = lines
            .map((l) => {
              try {
                return JSON.parse(l);
              } catch {
                return null;
              }
            })
            .filter(Boolean);
        }

        let arrayData: any[] = [];
        if (Array.isArray(jsonParsed)) {
          arrayData = jsonParsed;
        } else if (jsonParsed && typeof jsonParsed === "object") {
          if (Array.isArray(jsonParsed.features)) {
            arrayData = jsonParsed.features.map((f: any) => ({
              ...f.properties,
              longitude: f.geometry?.coordinates?.[0],
              latitude: f.geometry?.coordinates?.[1],
            }));
          } else if (
            Array.isArray(
              jsonParsed.transactions ||
                jsonParsed.records ||
                jsonParsed.data ||
                jsonParsed.rows
            )
          ) {
            arrayData =
              jsonParsed.transactions ||
              jsonParsed.records ||
              jsonParsed.data ||
              jsonParsed.rows;
          } else {
            arrayData = [jsonParsed];
          }
        }

        const totalRows = arrayData.length;
        postProgress("DETECTING_COLUMNS", 0, totalRows, `Applying column mappings...`, startTime);

        for (let i = 0; i < totalRows; i++) {
          const raw = mapRawRecordWithConfig(arrayData[i], i, columnMapping);
          if (i < 10) rawPreviewSamples.push(arrayData[i]);
          if (i < 50) Object.keys(arrayData[i]).forEach((k) => allDetectedKeys.add(k));

          const evaluated = evaluateSingleTransaction(
            raw,
            i,
            userTxHistory,
            deviceUserMap,
            250,
            150,
            fileName
          );

          if (previewRows.length < previewCap) {
            previewRows.push(evaluated);
          }

          accumulator.add(evaluated);
          processedRowCount++;

          if (i % 250 === 0 || i === totalRows - 1) {
            postProgress(
              "RUNNING_FRAUD_DETECTION",
              i + 1,
              totalRows,
              `Processing: ${(i + 1).toLocaleString()} / ${totalRows.toLocaleString()} rows...`,
              startTime
            );
          }
        }
      } else if (ext === "zip") {
        postProgress("READING", 0, 100, `Extracting compressed archive...`, startTime);
        const zip = await JSZip.loadAsync(data.fileData as ArrayBuffer);
        const fileNames = Object.keys(zip.files).filter(
          (n) => !n.startsWith("__MACOSX") && !zip.files[n].dir
        );

        for (const fName of fileNames) {
          const content = await zip.files[fName].async("text");
          const p = Papa.parse<any>(content, {
            header: true,
            dynamicTyping: true,
            skipEmptyLines: "greedy",
          });
          if (p.data && p.data.length > 0) {
            for (let i = 0; i < p.data.length; i++) {
              const idx = processedRowCount;
              const raw = mapRawRecordWithConfig(p.data[i], idx, columnMapping);
              if (idx < 10) rawPreviewSamples.push(p.data[i]);
              if (idx < 50) Object.keys(p.data[i]).forEach((k) => allDetectedKeys.add(k));

              const evaluated = evaluateSingleTransaction(
                raw,
                idx,
                userTxHistory,
                deviceUserMap,
                250,
                150,
                fName
              );

              if (previewRows.length < previewCap) {
                previewRows.push(evaluated);
              }

              accumulator.add(evaluated);
              processedRowCount++;
            }
          }
        }
      } else {
        // Generic fallback parser
        const textContent =
          typeof data.fileData === "string"
            ? data.fileData
            : new TextDecoder().decode(data.fileData);
        const lines = textContent.split(/\r?\n/).filter((l) => l.trim().length > 0);
        for (let idx = 0; idx < lines.length; idx++) {
          const line = lines[idx];
          const amtMatch = line.match(/\$?(\d+(?:\.\d{2})?)/);
          const ipMatch = line.match(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/);
          const raw: RawTransaction = {
            transactionId: `TXN-${100000 + idx}`,
            userId: `USR-${1000 + (idx % 20)}`,
            amount: amtMatch ? parseFloat(amtMatch[1]) : 150 + (idx % 500),
            ipAddress: ipMatch ? ipMatch[0] : undefined,
            rawText: line.substring(0, 120),
          };

          if (idx < 10) rawPreviewSamples.push(raw);
          if (idx < 50) Object.keys(raw).forEach((k) => allDetectedKeys.add(k));

          const evaluated = evaluateSingleTransaction(
            raw,
            idx,
            userTxHistory,
            deviceUserMap,
            250,
            150,
            fileName
          );

          if (previewRows.length < previewCap) {
            previewRows.push(evaluated);
          }

          accumulator.add(evaluated);
          processedRowCount++;
        }
      }
    }

    // Step: Calculating metrics
    postProgress(
      "CALCULATING_METRICS",
      processedRowCount,
      processedRowCount,
      `Calculating global fraud & risk metrics across ${processedRowCount.toLocaleString()} rows...`,
      startTime
    );

    // Step: Updating map aggregations
    postProgress(
      "UPDATING_MAP",
      processedRowCount,
      processedRowCount,
      `Aggregating geographic clusters & flight vectors...`,
      startTime
    );

    const durationMs = Date.now() - startTime;
    const throughputRowsPerSec = Math.round(
      processedRowCount / Math.max(durationMs / 1000, 0.05)
    );
    const globalMetrics = accumulator.getMetrics();
    const isCapped = processedRowCount > previewCap;

    postProgress(
      "COMPLETED",
      processedRowCount,
      processedRowCount,
      `Processing completed: ${processedRowCount.toLocaleString()} rows analyzed.`,
      startTime
    );

    const summary: FileImportSummary = {
      id: `INGEST-${Date.now()}`,
      fileName,
      fileType,
      fileSize: fileSizeStr,
      recordsCount: previewRows.length, // Strictly <= 100
      totalRawRecordsCount: processedRowCount, // e.g. 1,270,076
      previewCapped: isCapped,
      processingDurationMs: durationMs,
      throughputRowsPerSec,
      globalMetrics,
      columnMapping,
      detectedFields: Array.from(allDetectedKeys),
      validationStatus: "VALID",
      processingStatus: "PARSED",
      rawPreview: rawPreviewSamples,
      parsedTransactions: previewRows, // ONLY top 100 rows in memory!
    };

    const successMsg: WorkerSuccessMessage = {
      type: "SUCCESS",
      summary,
      totalRecords: processedRowCount,
      previewCapped: isCapped,
      durationMs,
      throughputRowsPerSec,
    };

    self.postMessage(successMsg);
  } catch (err: any) {
    const errorMsg: WorkerErrorMessage = {
      type: "ERROR",
      error: err?.message || String(err),
    };
    self.postMessage(errorMsg);
  }
};
