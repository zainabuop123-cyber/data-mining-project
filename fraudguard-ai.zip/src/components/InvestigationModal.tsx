import React, { useState, useEffect } from "react";
import {
  X,
  ShieldAlert,
  AlertTriangle,
  CheckCircle,
  Sparkles,
  MapPin,
  Clock,
  User,
  CreditCard,
  Cpu,
  Globe2,
  RefreshCw,
  FileText,
  Lock,
  ArrowRight,
  PlaneTakeoff,
  Smartphone,
  Check,
} from "lucide-react";
import { AnalyzedTransaction } from "../types";

interface InvestigationModalProps {
  transaction: AnalyzedTransaction | null;
  onClose: () => void;
  onUpdateStatus?: (txId: string, newDecision: "APPROVED" | "REVIEW" | "BLOCKED") => void;
}

export const InvestigationModal: React.FC<InvestigationModalProps> = ({
  transaction,
  onClose,
  onUpdateStatus,
}) => {
  const [aiReport, setAiReport] = useState<any>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!transaction) return;
    setAiReport(null);
    setActionSuccess(null);

    // Call server Gemini API for forensic investigation
    const fetchAiAnalysis = async () => {
      setLoadingAi(true);
      try {
        const response = await fetch("/api/gemini/investigate-transaction", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            transaction,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          setAiReport(data);
        } else {
          // Fallback heuristic summary
          setAiReport({
            riskRating: transaction.decision,
            summary: `Transaction ${transaction.transactionId} evaluated with a composite risk score of ${transaction.riskScore}/100. Triggered stages include: ${transaction.triggeredChecks.join(", ") || "Standard metrics"}.`,
            vectorBreakdown: {
              identity: transaction.stage1Identity.summary,
              behavioral: transaction.stage2Behavioral.summary,
              networkDevice: transaction.stage3NetworkDevice.summary,
              geographic: transaction.stage4Geographic.summary,
            },
            travelVelocityNote: transaction.travelSpeedKmH
              ? `Estimated travel speed of ${transaction.travelSpeedKmH} km/h exceeds normal passenger threshold.`
              : "Standard geographic consistency.",
            recommendedActions: [
              "Initiate Step-up 3DS / Biometric Authenticator verification.",
              "Enforce temporary 24-hour withdrawal velocity cap on destination account.",
              "Flag device fingerprint in SecOps fraud ring registry.",
            ],
            ruleTuningTip:
              "Adjust Stage 4 impossible travel threshold to flag cross-border anomalies exceeding 600 km/h.",
          });
        }
      } catch {
        setAiReport({
          riskRating: transaction.decision,
          summary: transaction.primaryReason,
          recommendedActions: [
            "Verify customer phone / SMS OTP challenge.",
            "Review connected device accounts for synthetic identity ring.",
          ],
        });
      } finally {
        setLoadingAi(false);
      }
    };

    fetchAiAnalysis();
  }, [transaction]);

  if (!transaction) return null;

  const isBlocked = transaction.decision === "BLOCKED";
  const isReview = transaction.decision === "REVIEW";

  const handleAction = (newDecision: "APPROVED" | "REVIEW" | "BLOCKED", label: string) => {
    if (onUpdateStatus) {
      onUpdateStatus(transaction.id, newDecision);
    }
    setActionSuccess(`Transaction decision updated to ${label}. Rule weights recalculated.`);
    setTimeout(() => setActionSuccess(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-[1000] bg-[#0a0f1e]/85 backdrop-blur-md flex items-center justify-center p-3 md:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#0f172a] border border-slate-800/80 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between bg-[#0f172a]/95">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold ${
                isBlocked
                  ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                  : isReview
                  ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                  : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
              }`}
            >
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-slate-100 font-mono">
                  {transaction.transactionId}
                </h3>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                    isBlocked
                      ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                      : isReview
                      ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                      : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                  }`}
                >
                  {transaction.decision} ({transaction.riskScore}/100)
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Customer: <strong className="text-slate-200 font-mono">{transaction.userId}</strong> • {transaction.formattedDate}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#070b16] hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Action Success Banner */}
          {actionSuccess && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>{actionSuccess}</span>
            </div>
          )}

          {/* Quick Details Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-0.5">Transaction Amount</span>
              <span className="text-sm font-bold text-white font-mono">
                {transaction.currency} {transaction.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-0.5">Merchant / Category</span>
              <span className="text-xs font-semibold text-slate-200 block truncate">
                {transaction.merchant}
              </span>
              <span className="text-[10px] text-cyan-400">{transaction.merchantCategory}</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-0.5">Location Telemetry</span>
              <span className="text-xs font-semibold text-slate-200 block truncate">
                {transaction.city ? `${transaction.city}, ${transaction.country || ""}` : "Unavailable"}
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {transaction.latitude && transaction.longitude
                  ? `${transaction.latitude.toFixed(3)}, ${transaction.longitude.toFixed(3)}`
                  : "No GPS"}
              </span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block mb-0.5">Device &amp; Network</span>
              <span className="text-xs font-semibold text-slate-200 block truncate">
                {transaction.deviceId || "Unrecognized Device"}
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                IP: {transaction.ipAddress || "Data unavailable"}
              </span>
            </div>
          </div>

          {/* AI Forensic Intelligence Card */}
          <div className="p-4.5 rounded-2xl bg-gradient-to-br from-cyan-950/40 via-[#0f172a] to-[#070b16] border border-cyan-500/30 space-y-3 shadow-xl relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: "6s" }} />
                <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                  FraudGuard AI Forensic Copilot Assessment
                </h4>
              </div>
              {loadingAi && (
                <span className="text-[11px] text-cyan-400 flex items-center gap-1.5 font-mono">
                  <RefreshCw className="w-3 h-3 animate-spin" /> Deep Reasoning...
                </span>
              )}
            </div>

            {aiReport ? (
              <div className="space-y-3 text-xs text-slate-300">
                <p className="leading-relaxed bg-[#070b16]/90 p-3.5 rounded-xl border border-slate-800/80 text-slate-200">
                  {aiReport.summary}
                </p>

                {aiReport.recommendedActions && (
                  <div>
                    <span className="text-[11px] uppercase font-bold text-cyan-400 block mb-1.5">
                      Recommended SecOps Mitigations:
                    </span>
                    <ul className="space-y-1.5">
                      {aiReport.recommendedActions.map((act: string, i: number) => (
                        <li key={i} className="flex items-start gap-2 bg-[#070b16]/90 p-2.5 rounded-lg border border-slate-800/60">
                          <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                          <span>{act}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-4 text-center text-xs text-slate-500">
                Analyzing transaction signals across neural fraud graphs...
              </div>
            )}
          </div>

          {/* 5-Stage Verification Pipeline Breakdown */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Multi-Stage Pipeline Diagnostic Breakdown
            </h4>

            <div className="space-y-2">
              {/* Stage 1 */}
              <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">1. Identity &amp; Account Integrity</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      transaction.stage1Identity.status === "PASSED"
                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                        : transaction.stage1Identity.status === "UNAVAILABLE"
                        ? "bg-slate-800 text-slate-400"
                        : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                    }`}
                  >
                    {transaction.stage1Identity.status} (+{transaction.stage1Identity.scoreContribution} pts)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{transaction.stage1Identity.summary}</p>
              </div>

              {/* Stage 2 */}
              <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">2. Behavioral &amp; Transaction Analysis</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      transaction.stage2Behavioral.status === "PASSED"
                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                        : transaction.stage2Behavioral.status === "UNAVAILABLE"
                        ? "bg-slate-800 text-slate-400"
                        : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                    }`}
                  >
                    {transaction.stage2Behavioral.status} (+{transaction.stage2Behavioral.scoreContribution} pts)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{transaction.stage2Behavioral.summary}</p>
              </div>

              {/* Stage 3 */}
              <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">3. Network &amp; Device Risk</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      transaction.stage3NetworkDevice.status === "PASSED"
                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                        : transaction.stage3NetworkDevice.status === "UNAVAILABLE"
                        ? "bg-slate-800 text-slate-400"
                        : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                    }`}
                  >
                    {transaction.stage3NetworkDevice.status} (+{transaction.stage3NetworkDevice.scoreContribution} pts)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{transaction.stage3NetworkDevice.summary}</p>
              </div>

              {/* Stage 4 */}
              <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">4. Geographic Intelligence</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      transaction.stage4Geographic.status === "PASSED"
                        ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                        : transaction.stage4Geographic.status === "UNAVAILABLE"
                        ? "bg-slate-800 text-slate-400"
                        : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                    }`}
                  >
                    {transaction.stage4Geographic.status} (+{transaction.stage4Geographic.scoreContribution} pts)
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{transaction.stage4Geographic.summary}</p>
              </div>

              {/* Stage 5 */}
              <div className="p-3.5 rounded-xl bg-[#070b16] border border-slate-800/80 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-200">5. Final Scoring Decision Matrix</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                    Calculated Composite: {transaction.riskScore}/100
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{transaction.stage5FinalScoring.summary}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800/80 bg-[#070b16] flex flex-wrap items-center justify-between gap-3">
          <div className="text-[11px] text-slate-500">
            Source: <strong className="text-slate-400">{transaction.sourceFile}</strong>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleAction("APPROVED", "APPROVED")}
              className="px-3.5 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold text-xs transition-colors cursor-pointer"
            >
              Approve (False Positive)
            </button>
            <button
              onClick={() => handleAction("REVIEW", "MANUAL REVIEW")}
              className="px-3.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-semibold text-xs transition-colors cursor-pointer"
            >
              Mark Under Review
            </button>
            <button
              onClick={() => handleAction("BLOCKED", "CONFIRMED FRAUD BLOCK")}
              className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs shadow-lg shadow-rose-500/20 transition-colors cursor-pointer"
            >
              Confirm Block &amp; Blacklist
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
