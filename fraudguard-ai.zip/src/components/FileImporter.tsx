import React, { useState, useRef } from "react";
import {
  UploadCloud,
  FileSpreadsheet,
  FileText,
  FileCode,
  FileArchive,
  CheckCircle,
  AlertCircle,
  Play,
  Sparkles,
  ArrowRight,
  Database,
  RefreshCw,
  FolderOpen,
  FileCheck2,
  Cpu,
  Zap,
  XCircle,
  ShieldCheck,
  Activity,
  Layers,
  ChevronLeft,
  ChevronRight,
  Flame,
  Sliders,
  MapPin,
} from "lucide-react";
import { FileImportSummary, ColumnMappingConfig } from "../types";
import { SAMPLE_DATASETS } from "../utils/fileParsers";
import { runFraudDetectionPipeline } from "../utils/fraudEngine";
import {
  runIngestionEngine,
  runSyntheticBenchmark,
  inspectFileColumns,
  ColumnInspectionResult,
  IngestionProgress,
} from "../utils/ingestionManager";
import { ColumnMappingModal } from "./ColumnMappingModal";

interface FileImporterProps {
  onIngestCompleted: (summary: FileImportSummary) => void;
  isProcessing?: boolean;
}

export const FileImporter: React.FC<FileImporterProps> = ({
  onIngestCompleted,
  isProcessing = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [currentImport, setCurrentImport] = useState<FileImportSummary | null>(null);
  const [previewPage, setPreviewPage] = useState(1);
  const PREVIEW_PAGE_SIZE = 10;

  // Column inspection modal state
  const [inspectionState, setInspectionState] = useState<{
    file: File;
    inspection: ColumnInspectionResult;
  } | null>(null);

  // Non-blocking loader & Worker state
  const [isWorkerActive, setIsWorkerActive] = useState(false);
  const [progressState, setProgressState] = useState<IngestionProgress | null>(null);
  const cancelRef = useRef<(() => void) | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const cancelCurrentOperation = () => {
    if (cancelRef.current) {
      cancelRef.current();
      cancelRef.current = null;
    }
    setIsWorkerActive(false);
    setProgressState(null);
  };

  // Step 1: Initial file selection -> Inspect headers and open Column Mapping modal
  const handleSelectFile = async (file: File) => {
    setErrorMessage(null);
    try {
      const inspection = await inspectFileColumns(file);
      setInspectionState({
        file,
        inspection,
      });
    } catch (err: any) {
      console.warn("Fast inspection fallback, proceeding to stream directly:", err);
      // If inspection fails, start direct ingestion
      startFullIngestion(file);
    }
  };

  // Step 2: User confirms Column Mapping -> Launch full background worker streaming
  const startFullIngestion = (file: File, columnMapping?: ColumnMappingConfig) => {
    setInspectionState(null);
    setErrorMessage(null);
    setIsWorkerActive(true);
    setPreviewPage(1);
    setProgressState({
      stage: "READING",
      current: 0,
      total: 100,
      percent: 5,
      message: `Reading payload and preparing streaming pipeline for ${file.name}...`,
    });

    const { cancel } = runIngestionEngine(file, {
      batchSize: 100,
      previewCap: 100,
      columnMapping,
      onProgress: (progress) => {
        setProgressState(progress);
      },
      onSuccess: (summary) => {
        setCurrentImport(summary);
        setPreviewPage(1);
        setIsWorkerActive(false);
        cancelRef.current = null;
        // Auto-ingest into the dashboard as soon as parsing succeeds, instead of
        // waiting for a separate manual "Ingest" click — this is what was making
        // uploaded CSVs appear to produce no results on the Dashboard tab.
        onIngestCompleted({ ...summary, processingStatus: "INGESTED" });
      },
      onError: (err) => {
        console.error("Ingestion failed:", err);
        setErrorMessage(err.message || "Failed to process dataset.");
        setIsWorkerActive(false);
        cancelRef.current = null;
      },
    });

    cancelRef.current = cancel;
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleSelectFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleSelectFile(e.target.files[0]);
    }
  };

  const handleLoadSample = (sampleKey: string) => {
    const sample = SAMPLE_DATASETS[sampleKey];
    if (!sample) return;

    setErrorMessage(null);
    setIsWorkerActive(true);
    setPreviewPage(1);
    setProgressState({
      stage: "DETECTING_COLUMNS",
      current: 0,
      total: sample.records.length,
      percent: 15,
      message: `Loading verified dataset: ${sample.name}...`,
    });

    setTimeout(() => {
      const pipelineResult = runFraudDetectionPipeline(sample.records, sample.name, 100);

      const allKeys = new Set<string>();
      sample.records.slice(0, 20).forEach((r) => {
        Object.keys(r).forEach((k) => allKeys.add(k));
      });

      const summary: FileImportSummary = {
        id: `SAMPLE-${Date.now()}`,
        fileName: `${sample.name}.json`,
        fileType: sample.format,
        fileSize: "48.2 KB",
        recordsCount: pipelineResult.analyzed.length,
        totalRawRecordsCount: sample.records.length,
        previewCapped: sample.records.length > 100,
        processingDurationMs: 45,
        throughputRowsPerSec: Math.round(sample.records.length / 0.045),
        detectedFields: Array.from(allKeys),
        validationStatus: "VALID",
        processingStatus: "PARSED",
        rawPreview: sample.records.slice(0, 8),
        parsedTransactions: pipelineResult.analyzed.slice(0, 100),
        globalMetrics: pipelineResult.metrics,
      };

      setCurrentImport(summary);
      setPreviewPage(1);
      setIsWorkerActive(false);
      setProgressState(null);
      onIngestCompleted({ ...summary, processingStatus: "INGESTED" });
    }, 100);
  };

  const handleRunStressBenchmark = (count: number) => {
    setErrorMessage(null);
    setIsWorkerActive(true);
    setPreviewPage(1);
    setProgressState({
      stage: "READING",
      current: 0,
      total: count,
      percent: 1,
      message: `Allocating background Web Worker for ${count.toLocaleString()} stress records...`,
    });

    const { cancel } = runSyntheticBenchmark(count, {
      batchSize: 100,
      previewCap: 100,
      onProgress: (progress) => {
        setProgressState(progress);
      },
      onSuccess: (summary) => {
        setCurrentImport(summary);
        setPreviewPage(1);
        setIsWorkerActive(false);
        cancelRef.current = null;
        onIngestCompleted({ ...summary, processingStatus: "INGESTED" });
      },
      onError: (err) => {
        setErrorMessage(err.message || "Benchmark failed");
        setIsWorkerActive(false);
        cancelRef.current = null;
      },
    });

    cancelRef.current = cancel;
  };

  const handleConfirmIngest = () => {
    if (!currentImport) return;
    const updated = {
      ...currentImport,
      processingStatus: "INGESTED" as const,
    };
    onIngestCompleted(updated);
  };

  const totalPreviewPages = currentImport
    ? Math.max(1, Math.ceil(currentImport.parsedTransactions.length / PREVIEW_PAGE_SIZE))
    : 1;

  const currentPreviewRows = currentImport
    ? currentImport.parsedTransactions.slice(
        (previewPage - 1) * PREVIEW_PAGE_SIZE,
        previewPage * PREVIEW_PAGE_SIZE
      )
    : [];

  return (
    <div className="w-full space-y-4">
      {/* Column Mapping Modal */}
      {inspectionState && (
        <ColumnMappingModal
          fileName={inspectionState.inspection.fileName}
          fileSizeStr={inspectionState.inspection.fileSizeStr}
          totalRowsEstimate={inspectionState.inspection.totalRowsEstimate}
          csvHeaders={inspectionState.inspection.headers}
          sampleRows={inspectionState.inspection.sampleRows}
          initialMapping={inspectionState.inspection.detectedMapping}
          onConfirmMapping={(confirmedMapping) => {
            startFullIngestion(inspectionState.file, confirmedMapping);
          }}
          onCancel={() => setInspectionState(null)}
        />
      )}

      {/* Upload Box */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => !isWorkerActive && fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-6 md:p-8 text-center transition-all duration-200 ${
          isWorkerActive
            ? "border-cyan-500/50 bg-[#0a0f1e]/90 cursor-default"
            : dragActive
            ? "border-cyan-400 bg-cyan-500/10 scale-[1.01] cursor-pointer"
            : "border-slate-800/80 bg-[#0f172a]/60 hover:border-cyan-500/50 hover:bg-[#0f172a]/90 backdrop-blur-sm cursor-pointer"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple={false}
          onChange={handleFileChange}
          accept=".csv,.tsv,.xlsx,.xls,.ods,.json,.jsonl,.geojson,.xml,.zip,.txt,.log,.pdf,.doc,.docx"
          className="hidden"
          disabled={isWorkerActive}
        />

        {/* Normal Idle / Drag State */}
        {!isWorkerActive ? (
          <div className="flex flex-col items-center justify-center max-w-xl mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3.5 shadow-lg shadow-cyan-950/50">
              <UploadCloud className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-bold text-slate-100 mb-1">
              Universal CSV &amp; Multi-Format Ingestion Engine
            </h3>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Drag &amp; drop or browse any CSV or financial data file. Large datasets (including <strong className="text-cyan-400 font-semibold">1,000,000+ rows</strong>) are streamed and analyzed across the 5-stage FraudGuard AI pipeline with memory-safe aggregations.
            </p>

            {/* Supported Format Pills */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 mb-4">
              <span className="px-2.5 py-1 rounded-md text-[11px] font-mono bg-[#070b16] text-cyan-300 border border-slate-800/80 flex items-center gap-1">
                <FileSpreadsheet className="w-3 h-3 text-emerald-400" /> CSV / TSV / Excel (XLSX)
              </span>
              <span className="px-2.5 py-1 rounded-md text-[11px] font-mono bg-[#070b16] text-purple-300 border border-slate-800/80 flex items-center gap-1">
                <FileCode className="w-3 h-3 text-purple-400" /> JSON / JSONL / GeoJSON
              </span>
              <span className="px-2.5 py-1 rounded-md text-[11px] font-mono bg-[#070b16] text-amber-300 border border-slate-800/80 flex items-center gap-1">
                <FileArchive className="w-3 h-3 text-amber-400" /> ZIP Archives
              </span>
              <span className="px-2.5 py-1 rounded-md text-[11px] font-mono bg-[#070b16] text-slate-300 border border-slate-800/80 flex items-center gap-1">
                <FileText className="w-3 h-3 text-cyan-400" /> TXT / Logs
              </span>
            </div>

            <span className="text-[11px] text-slate-500 font-mono flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              Auto Column Detection • Interactive Schema Review • 100-Row Client Preview
            </span>
          </div>
        ) : (
          /* Non-Blocking Loader Progress Screen */
          <div className="py-6 px-4 max-w-lg mx-auto space-y-4">
            <div className="flex items-center justify-center gap-3 text-cyan-400">
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/40 flex items-center justify-center">
                  <Cpu className="w-5 h-5 animate-pulse text-cyan-400" />
                </div>
                <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                </span>
              </div>
              <div className="text-left">
                <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  Streaming Ingestion &amp; 5-Stage Fraud Analysis
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                    {progressState?.stage || "PROCESSING"}
                  </span>
                </h4>
                <p className="text-[11px] text-slate-400 font-mono">
                  Off-thread Web Worker execution • Analyzing entire dataset
                </p>
              </div>
            </div>

            {/* Stage Stepper Indicator */}
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 px-1">
              <span className={progressState?.stage === "READING" ? "text-cyan-400 font-bold" : "text-slate-500"}>
                1. Read
              </span>
              <span className="text-slate-600">→</span>
              <span className={progressState?.stage === "DETECTING_COLUMNS" ? "text-cyan-400 font-bold" : "text-slate-500"}>
                2. Schema
              </span>
              <span className="text-slate-600">→</span>
              <span className={progressState?.stage === "RUNNING_FRAUD_DETECTION" || progressState?.stage === "PROCESSING_ROWS" ? "text-cyan-400 font-bold" : "text-slate-500"}>
                3. 5-Stage AI
              </span>
              <span className="text-slate-600">→</span>
              <span className={progressState?.stage === "CALCULATING_METRICS" || progressState?.stage === "UPDATING_MAP" ? "text-cyan-400 font-bold" : "text-slate-500"}>
                4. Metrics &amp; Map
              </span>
              <span className="text-slate-600">→</span>
              <span className={progressState?.stage === "COMPLETED" ? "text-emerald-400 font-bold" : "text-slate-500"}>
                5. Ready
              </span>
            </div>

            {/* Live Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono text-slate-300">
                <span className="text-cyan-300 truncate max-w-[300px]">
                  {progressState?.message || "Analyzing records across 5 fraud stages..."}
                </span>
                <span className="font-bold text-cyan-400">
                  {progressState?.percent ?? 0}%
                </span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-800/80 overflow-hidden border border-slate-700/50">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 via-emerald-400 to-cyan-400 transition-all duration-150 rounded-full"
                  style={{ width: `${Math.max(progressState?.percent || 0, 4)}%` }}
                ></div>
              </div>
            </div>

            {/* Telemetry Metrics: Progress count & throughput */}
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 bg-[#070b16] px-3.5 py-2 rounded-xl border border-slate-800/80">
              <div className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-cyan-400" />
                <span>
                  Processing: <strong className="text-slate-200">{(progressState?.current || 0).toLocaleString()}</strong>
                  {progressState?.total ? ` / ${progressState.total.toLocaleString()}` : ""} rows
                </span>
              </div>
              {progressState?.rowsPerSec ? (
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <Zap className="w-3.5 h-3.5" />
                  <span>{progressState.rowsPerSec.toLocaleString()} rows/s</span>
                </div>
              ) : null}
            </div>

            {/* Cancel Button */}
            <div className="pt-1 flex justify-center">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  cancelCurrentOperation();
                }}
                className="px-3 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-colors flex items-center gap-1.5 cursor-pointer text-xs"
              >
                <XCircle className="w-3.5 h-3.5" />
                Cancel Parsing
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Error Notice */}
      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-[11px] underline hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Quick Test Presets & Stress Benchmarks */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-2.5 p-3.5 rounded-xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 text-xs">
        <div className="flex items-center gap-2 text-slate-400 font-medium shrink-0">
          <Database className="w-4 h-4 text-cyan-400" />
          <span>Benchmark &amp; Scenario Tests:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            disabled={isWorkerActive}
            onClick={() => handleLoadSample("syndicate")}
            className="px-2.5 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-medium transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
            Syndicate Scenario
          </button>
          <button
            disabled={isWorkerActive}
            onClick={() => handleLoadSample("ecommerce")}
            className="px-2.5 py-1.5 rounded-lg bg-[#070b16] hover:bg-slate-800 text-slate-200 border border-slate-700/80 font-medium transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-cyan-400" />
            E-Commerce Gateway
          </button>

          {/* 50K Big-Data */}
          <button
            disabled={isWorkerActive}
            onClick={() => handleRunStressBenchmark(50000)}
            className="px-2.5 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono text-[11px] font-medium transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            title="Benchmark 50,000 records processed with Non-Blocking Loader"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            50K Stream
          </button>

          {/* 1.27M Big-Data Stress Benchmark (1,270,076 Rows) */}
          <button
            disabled={isWorkerActive}
            onClick={() => handleRunStressBenchmark(1270076)}
            className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-500/20 to-amber-500/20 hover:from-rose-500/30 hover:to-amber-500/30 text-amber-300 border border-amber-500/40 font-mono text-[11px] font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md shadow-amber-950/40"
            title="Benchmark 1,270,076 records streamed in memory-safe chunks to verify complete analysis and low React memory usage"
          >
            <Flame className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            1.27M Big-Data Stress (1,270,076 Rows)
          </button>
        </div>
      </div>

      {/* Data Preview Card */}
      {currentImport && (
        <div className="rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 p-5 space-y-4 shadow-2xl animate-in fade-in duration-300">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                  {currentImport.fileName}
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                    {currentImport.fileType}
                  </span>
                </h4>
                <p className="text-xs text-slate-400">
                  Size: {currentImport.fileSize} • Total Ingested:{" "}
                  <strong className="text-white">
                    {(currentImport.totalRawRecordsCount || currentImport.recordsCount).toLocaleString()}
                  </strong>{" "}
                  rows
                  {currentImport.throughputRowsPerSec ? (
                    <span className="text-emerald-400 ml-2 font-mono">
                      • {currentImport.throughputRowsPerSec.toLocaleString()} rows/s
                    </span>
                  ) : null}
                </p>
              </div>
            </div>

            {/* Ingest Action Button */}
            <button
              onClick={handleConfirmIngest}
              disabled={isProcessing || currentImport.recordsCount === 0}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              Ingest Into FraudGuard AI System
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Safety Payload Cap Banner if records exceed 100 */}
          {currentImport.previewCapped && (
            <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
              <div>
                <div className="font-semibold text-cyan-200">
                  Dataset Analyzed across 5 Stages (First 100 Rows Preview)
                </div>
                <p className="text-slate-300 text-[11px] mt-0.5 leading-relaxed">
                  Displaying first <strong className="text-white">100</strong> of{" "}
                  <strong className="text-white">
                    {(currentImport.totalRawRecordsCount || currentImport.recordsCount).toLocaleString()}
                  </strong>{" "}
                  analyzed records in client preview (10 rows per page). The full dataset of{" "}
                  <strong className="text-cyan-300">
                    {(currentImport.totalRawRecordsCount || currentImport.recordsCount).toLocaleString()}
                  </strong>{" "}
                  rows was evaluated by FraudGuard AI to calculate dashboard KPIs, risk metrics, alert feeds, and geographic intelligence.
                </p>
              </div>
            </div>
          )}

          {/* Metadata & Detected Columns summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-[#070b16] border border-slate-800/80">
              <span className="text-slate-400 block text-[11px] mb-1">Validation &amp; Ingestion Metrics</span>
              <div className="flex items-center gap-1.5 font-bold mb-1">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">
                  All {(currentImport.totalRawRecordsCount || currentImport.recordsCount).toLocaleString()} Rows Analyzed
                </span>
              </div>
              {currentImport.processingDurationMs ? (
                <div className="text-[10px] text-slate-400 font-mono">
                  Duration: {(currentImport.processingDurationMs / 1000).toFixed(2)}s • Throughput: {currentImport.throughputRowsPerSec?.toLocaleString()} rows/s
                </div>
              ) : null}
            </div>

            <div className="p-3 rounded-xl bg-[#070b16] border border-slate-800/80 md:col-span-2">
              <span className="text-slate-400 block text-[11px] mb-1.5">
                Detected Data Attributes &amp; Pipeline Fields:
              </span>
              <div className="flex flex-wrap gap-1">
                {currentImport.detectedFields.map((field) => (
                  <span
                    key={field}
                    className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#0f172a] text-slate-300 border border-slate-800"
                  >
                    {field}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Paginated Preview Table (10 Rows at a time) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">
                Preview Rows (10 Rows / Page):
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                Showing rows {(previewPage - 1) * PREVIEW_PAGE_SIZE + 1}–{Math.min(previewPage * PREVIEW_PAGE_SIZE, currentImport.parsedTransactions.length)} of {currentImport.parsedTransactions.length} preview rows
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-800/80 bg-[#070b16]">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#0f172a] text-[11px] text-slate-400 font-mono border-b border-slate-800/80">
                  <tr>
                    <th className="p-2.5">TX ID</th>
                    <th className="p-2.5">User</th>
                    <th className="p-2.5">Amount</th>
                    <th className="p-2.5">Location</th>
                    <th className="p-2.5">KYC</th>
                    <th className="p-2.5">Risk Score</th>
                    <th className="p-2.5">Decision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {currentPreviewRows.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-800/30">
                      <td className="p-2.5 text-cyan-400 font-bold">{tx.transactionId}</td>
                      <td className="p-2.5 text-slate-300">{tx.userId}</td>
                      <td className="p-2.5 font-bold text-white">
                        {tx.currency} {tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-2.5 text-slate-300">
                        {tx.hasLocationData && tx.city ? `${tx.city}, ${tx.country || ""}` : <span className="text-slate-500 italic">Location data unavailable</span>}
                      </td>
                      <td className="p-2.5">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] ${
                            tx.kycStatus === "VERIFIED"
                              ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                              : tx.kycStatus === "FAILED"
                              ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                              : "bg-slate-800 text-slate-400"
                          }`}
                        >
                          {tx.kycStatus}
                        </span>
                      </td>
                      <td className="p-2.5 font-bold">
                        <span
                          className={
                            tx.riskScore >= 75
                              ? "text-rose-400"
                              : tx.riskScore >= 40
                              ? "text-amber-400"
                              : "text-emerald-400"
                          }
                        >
                          {tx.riskScore}/100
                        </span>
                      </td>
                      <td className="p-2.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            tx.decision === "BLOCKED"
                              ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                              : tx.decision === "REVIEW"
                              ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                              : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          }`}
                        >
                          {tx.decision}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls for Preview Table */}
            <div className="flex items-center justify-between pt-1 text-xs text-slate-400 font-mono">
              <span>
                Page <strong className="text-cyan-300">{previewPage}</strong> of{" "}
                <strong className="text-cyan-300">{totalPreviewPages}</strong>
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={previewPage <= 1}
                  onClick={() => setPreviewPage((p) => Math.max(1, p - 1))}
                  className="px-2.5 py-1 rounded-lg bg-[#070b16] border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  Previous
                </button>

                <button
                  type="button"
                  disabled={previewPage >= totalPreviewPages}
                  onClick={() => setPreviewPage((p) => Math.min(totalPreviewPages, p + 1))}
                  className="px-2.5 py-1 rounded-lg bg-[#070b16] border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1 cursor-pointer"
                >
                  Next
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
