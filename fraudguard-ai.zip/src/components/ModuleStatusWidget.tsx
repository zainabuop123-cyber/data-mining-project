import React from "react";
import {
  UserCheck,
  Activity,
  Cpu,
  Globe2,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  HeartPulse,
} from "lucide-react";
import { AnalyzedTransaction, ModuleHealthStatus } from "../types";

interface ModuleStatusWidgetProps {
  transactions: AnalyzedTransaction[];
}

export const ModuleStatusWidget: React.FC<ModuleStatusWidgetProps> = ({
  transactions,
}) => {
  // Compute real module health based on active transaction dataset
  const total = transactions.length;

  const getModuleStatus = (
    stageKey: "stage1Identity" | "stage2Behavioral" | "stage3NetworkDevice" | "stage4Geographic" | "stage5FinalScoring"
  ): { status: ModuleHealthStatus; label: string; count: number; note: string } => {
    if (total === 0) {
      return { status: "ACTIVE", label: "Active", count: 0, note: "Pipeline standby" };
    }

    const availableCount = transactions.filter((t) => t[stageKey].dataAvailable).length;
    if (availableCount === 0) {
      return { status: "DATA_UNAVAILABLE", label: "Data Unavailable", count: 0, note: "No stage attributes in dataset" };
    }

    const criticalCount = transactions.filter((t) => t[stageKey].status === "CRITICAL").length;
    const flaggedCount = transactions.filter((t) => t[stageKey].status === "FLAGGED").length;

    if (criticalCount > 0) {
      return {
        status: "CRITICAL",
        label: "Critical Alerts",
        count: criticalCount,
        note: `${criticalCount} high-risk breaches detected`,
      };
    }
    if (flaggedCount > 0) {
      return {
        status: "WARNING",
        label: "Warning Alerts",
        count: flaggedCount,
        note: `${flaggedCount} anomaly vectors monitored`,
      };
    }

    return {
      status: "ACTIVE",
      label: "Active & Secure",
      count: availableCount,
      note: `${availableCount} records verified clean`,
    };
  };

  const m1 = getModuleStatus("stage1Identity");
  const m2 = getModuleStatus("stage2Behavioral");
  const m3 = getModuleStatus("stage3NetworkDevice");
  const m4 = getModuleStatus("stage4Geographic");
  const m5 = getModuleStatus("stage5FinalScoring");

  const modules = [
    {
      name: "1. Identity & Account Integrity",
      icon: UserCheck,
      health: m1,
      desc: "KYC verification, account age, auth consistency",
    },
    {
      name: "2. Behavioral & Transaction Analysis",
      icon: Activity,
      health: m2,
      desc: "Velocity anomalies, amount spikes, merchant risks",
    },
    {
      name: "3. Network & Device Risk",
      icon: Cpu,
      health: m3,
      desc: "VPN/Tor exit nodes, emulators, device reuse",
    },
    {
      name: "4. Geographic Intelligence",
      icon: Globe2,
      health: m4,
      desc: "Impossible travel, country mismatch, sanctions",
    },
    {
      name: "5. Final Risk Scoring Engine",
      icon: ShieldCheck,
      health: m5,
      desc: "0-100 weighted decisioning & policy triggers",
    },
  ];

  // Calculate Overall System Health
  const hasCritical = [m1, m2, m3, m4, m5].some((m) => m.status === "CRITICAL");
  const systemHealthScore = hasCritical ? 88 : 99;

  const renderStatusBadge = (health: { status: ModuleHealthStatus; label: string; count: number }) => {
    switch (health.status) {
      case "ACTIVE":
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Active
          </span>
        );
      case "WARNING":
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> Warning ({health.count})
          </span>
        );
      case "CRITICAL":
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30 flex items-center gap-1 animate-pulse">
            <XCircle className="w-3 h-3" /> Critical ({health.count})
          </span>
        );
      case "DATA_UNAVAILABLE":
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800/60 text-slate-400 border border-slate-700/60 flex items-center gap-1">
            <HelpCircle className="w-3 h-3 text-slate-500" /> Data Unavailable
          </span>
        );
    }
  };

  return (
    <div className="rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 p-5 shadow-2xl space-y-4">
      {/* Top Header with Overall System Health */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            Five-Stage Fraud Detection Modules
          </h4>
          <p className="text-[11px] text-slate-400 mt-0.5">Strict pipeline integrity &amp; stage telemetry</p>
        </div>

        {/* Overall System Health Indicator */}
        <div className="flex items-center gap-3 px-3 py-1.5 rounded-xl bg-[#070b16] border border-slate-800/80 shadow-inner">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="text-xs font-semibold text-slate-300">FraudGuard AI System Health:</span>
          </div>
          <span className="text-xs font-mono font-bold text-emerald-400">
            {systemHealthScore}% Operational
          </span>
        </div>
      </div>

      {/* 5 Stages Grid */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {modules.map((m) => {
          const Icon = m.icon;
          return (
            <div
              key={m.name}
              className="p-3.5 rounded-xl bg-[#070b16]/90 border border-slate-800/80 flex flex-col justify-between space-y-2 hover:border-slate-700/80 transition-all hover:bg-[#070b16]"
            >
              <div className="flex items-center justify-between gap-1">
                <div className="w-7 h-7 rounded-lg bg-[#0f172a] flex items-center justify-center text-cyan-400 border border-slate-800 shadow-sm">
                  <Icon className="w-3.5 h-3.5" />
                </div>
                {renderStatusBadge(m.health)}
              </div>

              <div>
                <h5 className="font-semibold text-xs text-slate-200 line-clamp-1">{m.name}</h5>
                <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{m.desc}</p>
              </div>

              <div className="text-[10px] text-slate-500 font-mono border-t border-slate-800/60 pt-1.5 truncate">
                {m.health.note}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
