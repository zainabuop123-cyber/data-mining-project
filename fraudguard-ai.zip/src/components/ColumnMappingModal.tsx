import React, { useState } from "react";
import {
  ColumnMappingConfig,
  RawTransaction,
} from "../types";
import {
  CANONICAL_FIELDS,
  CanonicalFieldDef,
} from "../utils/columnDetector";
import {
  Table,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Sliders,
  HelpCircle,
  MapPin,
  Shield,
  CreditCard,
  Network,
  UserCheck,
  X,
  RefreshCw,
  Info,
} from "lucide-react";

interface ColumnMappingModalProps {
  fileName: string;
  fileSizeStr: string;
  totalRowsEstimate?: number;
  csvHeaders: string[];
  sampleRows: Record<string, any>[];
  initialMapping: ColumnMappingConfig;
  onConfirmMapping: (mapping: ColumnMappingConfig) => void;
  onCancel: () => void;
}

export const ColumnMappingModal: React.FC<ColumnMappingModalProps> = ({
  fileName,
  fileSizeStr,
  totalRowsEstimate = 0,
  csvHeaders,
  sampleRows,
  initialMapping,
  onConfirmMapping,
  onCancel,
}) => {
  const [mapping, setMapping] = useState<ColumnMappingConfig>({ ...initialMapping });
  const [activeCategory, setActiveCategory] = useState<string>("ALL");
  const [showSampleData, setShowSampleData] = useState(true);

  const handleFieldChange = (key: keyof ColumnMappingConfig, value: string) => {
    setMapping((prev) => {
      const updated = { ...prev };
      if (!value || value === "__NONE__") {
        delete updated[key];
      } else {
        updated[key] = value;
      }
      return updated;
    });
  };

  const handleResetAuto = () => {
    setMapping({ ...initialMapping });
  };

  // Check required fields (Transaction ID & Amount are core)
  const isAmountMapped = !!mapping.amount;
  const isTxIdMapped = !!mapping.transactionId;
  const hasLocation = !!(mapping.latitude && mapping.longitude) || !!mapping.city || !!mapping.country;

  const categories = [
    { id: "ALL", label: "All Fields", icon: Sliders },
    { id: "CORE", label: "Core Transaction", icon: CreditCard },
    { id: "LOCATION", label: "Geographic / GPS", icon: MapPin },
    { id: "IDENTITY", label: "Identity & KYC", icon: UserCheck },
    { id: "NETWORK", label: "Network & Device", icon: Network },
    { id: "MERCHANT", label: "Merchant & Category", icon: Shield },
  ];

  const filteredFields = CANONICAL_FIELDS.filter(
    (f) => activeCategory === "ALL" || f.category === activeCategory
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0b1120] border border-slate-700/80 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-[#0f172a]/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-100">Review & Confirm Column Mapping</h2>
                <span className="px-2 py-0.5 text-[10px] font-semibold tracking-wider uppercase rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Schema Auto-Detected
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Verify field mappings for <span className="text-slate-200 font-mono font-medium">{fileName}</span> ({fileSizeStr} • ~{totalRowsEstimate.toLocaleString()} rows)
              </p>
            </div>
          </div>

          <button
            onClick={onCancel}
            className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Location / Validation Notice */}
        {!hasLocation && (
          <div className="mx-6 mt-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center gap-3 text-amber-300 text-xs">
            <Info className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <span className="font-semibold">Location data unmapped:</span> If your CSV does not include GPS coordinates or City/Country columns, FraudGuard AI will continue fraud scoring across Identity, Behavioral, and Network stages while marking location as &quot;Location data unavailable&quot;.
            </div>
          </div>
        )}

        {/* Category Tabs */}
        <div className="px-6 pt-4 flex items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-thin">
            {categories.map((c) => {
              const Icon = c.icon;
              const isActive = activeCategory === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setActiveCategory(c.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    isActive
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {c.label}
                </button>
              );
            })}
          </div>

          <button
            onClick={handleResetAuto}
            className="px-2.5 py-1 text-xs text-slate-400 hover:text-cyan-400 hover:bg-slate-800/60 rounded-lg flex items-center gap-1.5 transition-colors border border-slate-800"
          >
            <RefreshCw className="w-3 h-3" />
            Reset Auto-Detect
          </button>
        </div>

        {/* Field Mappings Body */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredFields.map((field) => {
              const mappedCol = mapping[field.key] || "";
              const isMapped = !!mappedCol;
              const sampleVal = isMapped && sampleRows.length > 0 ? sampleRows[0][mappedCol] : null;

              return (
                <div
                  key={field.key}
                  className={`p-3 rounded-xl border transition-all flex flex-col justify-between ${
                    isMapped
                      ? "bg-slate-900/80 border-slate-700/80 hover:border-cyan-500/40"
                      : field.required
                      ? "bg-amber-950/20 border-amber-800/40"
                      : "bg-slate-900/40 border-slate-800/60 opacity-80"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-semibold text-slate-200">
                          {field.label}
                        </span>
                        {field.required && (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-400/10 px-1.5 py-0.2 rounded border border-amber-400/20">
                            Required
                          </span>
                        )}
                        {isMapped && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                        {field.description}
                      </p>
                    </div>
                  </div>

                  {/* Mapping Dropdown */}
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <select
                        value={mappedCol || "__NONE__"}
                        onChange={(e) => handleFieldChange(field.key, e.target.value)}
                        className={`w-full bg-[#030712] border text-xs rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:ring-1 transition-all ${
                          isMapped
                            ? "border-cyan-500/40 focus:ring-cyan-500"
                            : field.required
                            ? "border-amber-500/50 focus:ring-amber-500"
                            : "border-slate-800 focus:ring-slate-700"
                        }`}
                      >
                        <option value="__NONE__" className="text-slate-500">
                          -- Not in CSV (Auto / Fallback) --
                        </option>
                        {csvHeaders.map((h) => (
                          <option key={h} value={h}>
                            {h}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Sample preview value for this column */}
                    {isMapped && sampleVal !== undefined && sampleVal !== null && (
                      <div className="flex items-center gap-1 text-[11px] text-slate-400 bg-slate-950/60 px-2 py-1 rounded border border-slate-800 font-mono truncate">
                        <span className="text-slate-500 font-sans">Row 1 Sample:</span>
                        <span className="text-cyan-300 font-medium truncate">{String(sampleVal)}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Sample Rows Preview Section */}
          {sampleRows.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-800/80">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Table className="w-3.5 h-3.5 text-cyan-400" />
                  First {sampleRows.length} Raw CSV Rows Sample
                </span>
                <span className="text-[11px] text-slate-500">
                  {csvHeaders.length} total columns detected
                </span>
              </div>
              <div className="overflow-x-auto rounded-xl border border-slate-800 bg-[#030712]/80">
                <table className="w-full text-[11px] text-left">
                  <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="px-3 py-2 font-medium text-slate-500">#</th>
                      {csvHeaders.map((h) => (
                        <th key={h} className="px-3 py-2 font-medium font-mono text-slate-300 whitespace-nowrap">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50 font-mono text-slate-300">
                    {sampleRows.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/30">
                        <td className="px-3 py-1.5 text-slate-500">{idx + 1}</td>
                        {csvHeaders.map((h) => (
                          <td key={h} className="px-3 py-1.5 whitespace-nowrap text-slate-300">
                            {row[h] !== undefined && row[h] !== null ? String(row[h]) : ""}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-[#0f172a]/90 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onCancel}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-slate-100 hover:bg-slate-800 border border-slate-700 transition-colors"
            >
              Cancel Upload
            </button>
          </div>

          <div className="flex items-center gap-3">
            {!isAmountMapped && (
              <span className="text-xs text-amber-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Amount is unmapped (defaults will apply)
              </span>
            )}
            <button
              onClick={() => onConfirmMapping(mapping)}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Sparkles className="w-4 h-4 text-slate-950 fill-slate-950" />
              <span>Start 5-Stage Fraud Analysis</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
