import React, { useEffect, useRef, useState } from "react";
import L from "leaflet";
import {
  AnalyzedTransaction,
  GeoPointSummary,
  TravelVectorSummary,
} from "../types";
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  MapPin,
  Radio,
  Clock,
  Layers,
  Sparkles,
  PlaneTakeoff,
  Eye,
  Info,
  Globe2,
} from "lucide-react";

interface FraudMapProps {
  transactions: AnalyzedTransaction[];
  geoClusters?: GeoPointSummary[];
  travelVectors?: TravelVectorSummary[];
  totalAnalyzedCount?: number;
  selectedTransaction: AnalyzedTransaction | null;
  onSelectTransaction: (tx: AnalyzedTransaction) => void;
  onInvestigateTransaction?: (tx: AnalyzedTransaction) => void;
}

export const FraudMap: React.FC<FraudMapProps> = ({
  transactions,
  geoClusters = [],
  travelVectors = [],
  totalAnalyzedCount = 0,
  selectedTransaction,
  onSelectTransaction,
  onInvestigateTransaction,
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const travelLinesLayerRef = useRef<L.LayerGroup | null>(null);

  const [riskFilter, setRiskFilter] = useState<"ALL" | "BLOCKED" | "REVIEW" | "TRAVEL">("ALL");
  const [showFlightPaths, setShowFlightPaths] = useState(true);
  const [lastUpdatedTime, setLastUpdatedTime] = useState("Just now");

  // Keep a live ticker for "Last Updated"
  useEffect(() => {
    const interval = setInterval(() => {
      const seconds = Math.floor((Date.now() % 60000) / 1000);
      if (seconds < 10) {
        setLastUpdatedTime("Just now");
      } else {
        setLastUpdatedTime(`${seconds}s ago`);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Filter valid clusters with non-null, non-NaN coordinates
  const validClusters = geoClusters.filter(
    (c) =>
      typeof c.lat === "number" &&
      typeof c.lng === "number" &&
      !isNaN(c.lat) &&
      !isNaN(c.lng)
  );
  const hasClusters = validClusters.length > 0;

  // Filter preview transactions that have valid coordinates
  const geoTransactions = transactions.filter(
    (t) =>
      t.hasLocationData &&
      typeof t.latitude === "number" &&
      typeof t.longitude === "number" &&
      !isNaN(t.latitude) &&
      !isNaN(t.longitude)
  );

  const filteredClusters = validClusters.filter((c) => {
    if (riskFilter === "BLOCKED") return c.fraudCount > 0;
    if (riskFilter === "REVIEW") return c.reviewCount > 0;
    return true;
  });

  const filteredGeoTransactions = geoTransactions.filter((t) => {
    if (riskFilter === "BLOCKED") return t.decision === "BLOCKED";
    if (riskFilter === "REVIEW") return t.decision === "REVIEW";
    if (riskFilter === "TRAVEL") return t.travelSpeedKmH && t.travelSpeedKmH > 400;
    return true;
  });

  const totalGeoPoints = hasClusters ? filteredClusters.length : filteredGeoTransactions.length;
  const highRiskCount = hasClusters
    ? validClusters.reduce((acc, c) => acc + (c.fraudCount || 0), 0)
    : geoTransactions.filter((t) => t.decision === "BLOCKED").length;

  const reviewCount = hasClusters
    ? validClusters.reduce((acc, c) => acc + (c.reviewCount || 0), 0)
    : geoTransactions.filter((t) => t.decision === "REVIEW").length;

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [25.0, 10.0],
        zoom: 2,
        minZoom: 2,
        maxZoom: 18,
        zoomControl: false,
        attributionControl: false,
      });

      L.control.zoom({ position: "topright" }).addTo(map);

      // Voyager light tiles with clean high-contrast styling
      L.tileLayer(
        "https://{s}.basemaps.cartocdn.com/rastertiles/voyager_labels_under/{z}/{x}/{y}{r}.png",
        {
          subdomains: "abcd",
          maxZoom: 19,
        }
      ).addTo(map);

      const markersGroup = L.layerGroup().addTo(map);
      const linesGroup = L.layerGroup().addTo(map);

      markersLayerRef.current = markersGroup;
      travelLinesLayerRef.current = linesGroup;
      mapInstanceRef.current = map;
    }
  }, []);

  // Render Markers & Lines
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersGroup = markersLayerRef.current;
    const linesGroup = travelLinesLayerRef.current;

    if (!map || !markersGroup || !linesGroup) return;

    markersGroup.clearLayers();
    linesGroup.clearLayers();

    if (totalGeoPoints === 0 && travelVectors.length === 0) return;

    const bounds = L.latLngBounds([]);

    // 1. Draw Travel Vectors (from global dataset analysis)
    if (showFlightPaths) {
      if (travelVectors.length > 0) {
        travelVectors.forEach((vec) => {
          if (
            typeof vec.fromLat !== "number" ||
            typeof vec.fromLng !== "number" ||
            typeof vec.toLat !== "number" ||
            typeof vec.toLng !== "number" ||
            isNaN(vec.fromLat) ||
            isNaN(vec.fromLng) ||
            isNaN(vec.toLat) ||
            isNaN(vec.toLng)
          ) {
            return;
          }

          const isImpossible = vec.speedKmH > 800;
          const polyline = L.polyline(
            [
              [vec.fromLat, vec.fromLng],
              [vec.toLat, vec.toLng],
            ],
            {
              color: isImpossible ? "#ef4444" : "#f59e0b",
              weight: isImpossible ? 3.5 : 2,
              dashArray: isImpossible ? "6, 6" : "3, 6",
              opacity: 0.85,
            }
          );

          polyline.bindTooltip(
            `<strong>Velocity Vector</strong><br/>Path: ${vec.fromCity} → ${vec.toCity}<br/>Velocity: <strong>${Math.round(vec.speedKmH).toLocaleString()} km/h</strong> (${isImpossible ? "IMPOSSIBLE TRAVEL" : "Rapid Velocity"})<br/>Occurrences: ${vec.count}`,
            { className: "bg-slate-900 text-slate-100 border border-slate-700" }
          );

          linesGroup.addLayer(polyline);
          bounds.extend([vec.fromLat, vec.fromLng]);
          bounds.extend([vec.toLat, vec.toLng]);
        });
      } else {
        // Fallback to preview transactions travel paths
        const userGeoMap: Record<string, AnalyzedTransaction[]> = {};
        filteredGeoTransactions.forEach((t) => {
          if (!userGeoMap[t.userId]) userGeoMap[t.userId] = [];
          userGeoMap[t.userId].push(t);
        });

        Object.entries(userGeoMap).forEach(([_uid, userTxs]) => {
          if (userTxs.length > 1) {
            for (let i = 0; i < userTxs.length - 1; i++) {
              const t1 = userTxs[i];
              const t2 = userTxs[i + 1];
              if (
                typeof t1.latitude === "number" &&
                typeof t1.longitude === "number" &&
                !isNaN(t1.latitude) &&
                !isNaN(t1.longitude) &&
                typeof t2.latitude === "number" &&
                typeof t2.longitude === "number" &&
                !isNaN(t2.latitude) &&
                !isNaN(t2.longitude)
              ) {
                const isImpossible = (t2.travelSpeedKmH && t2.travelSpeedKmH > 800) || false;
                const polyline = L.polyline(
                  [
                    [t1.latitude, t1.longitude],
                    [t2.latitude, t2.longitude],
                  ],
                  {
                    color: isImpossible ? "#ef4444" : "#f59e0b",
                    weight: isImpossible ? 3 : 2,
                    dashArray: isImpossible ? "6, 6" : "3, 6",
                    opacity: 0.85,
                  }
                );

                polyline.bindTooltip(
                  `<strong>Velocity Path (${t1.userId})</strong><br/>${t1.city || "Point A"} → ${t2.city || "Point B"}<br/>Speed: ${t2.travelSpeedKmH ? `${t2.travelSpeedKmH} km/h` : "Calculated"}`,
                  { className: "bg-slate-900 text-slate-100 border border-slate-700" }
                );

                linesGroup.addLayer(polyline);
              }
            }
          }
        });
      }
    }

    // 2. Render Markers (Clusters if available for full dataset, otherwise individual preview transactions)
    if (hasClusters) {
      filteredClusters.forEach((cluster) => {
        if (
          typeof cluster.lat !== "number" ||
          typeof cluster.lng !== "number" ||
          isNaN(cluster.lat) ||
          isNaN(cluster.lng)
        ) {
          return;
        }

        const count = cluster.totalCount || 1;
        const isHighRisk = cluster.fraudCount > 0 || cluster.avgRiskScore >= 60;
        const isReview = cluster.reviewCount > 0 || cluster.avgRiskScore >= 40;

        const colorClass = isHighRisk
          ? "bg-rose-500 text-white shadow-rose-500/50"
          : isReview
          ? "bg-amber-500 text-slate-950 shadow-amber-500/50"
          : "bg-emerald-500 text-slate-950 shadow-emerald-500/50";

        const size = Math.min(Math.max(28 + Math.log10(count + 1) * 6, 28), 48);

        const iconHtml = `
          <div class="relative flex items-center justify-center cursor-pointer transition-transform hover:scale-125">
            <div style="width: ${size}px; height: ${size}px;" class="rounded-full ${colorClass} flex items-center justify-center font-bold text-xs shadow-lg border-2 border-slate-950">
              ${count > 999 ? `${(count / 1000).toFixed(0)}k` : count}
            </div>
            ${
              cluster.fraudCount > 0
                ? `<div class="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-rose-600 text-white text-[9px] font-mono flex items-center justify-center border border-white font-bold">!</div>`
                : ""
            }
          </div>
        `;

        const customIcon = L.divIcon({
          className: "custom-fraud-cluster",
          html: iconHtml,
          iconSize: [size, size],
          iconAnchor: [size / 2, size / 2],
          popupAnchor: [0, -size / 2],
        });

        const marker = L.marker([cluster.lat, cluster.lng], { icon: customIcon });

        const popupHtml = `
          <div class="p-3.5 w-72 text-slate-100 font-sans">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <span class="font-bold text-sm text-cyan-400">${cluster.city || "Location"}, ${cluster.country || ""}</span>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                isHighRisk
                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/40"
                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
              }">
                Avg Score: ${cluster.avgRiskScore}/100
              </span>
            </div>

            <div class="mt-2.5 space-y-1.5 text-xs text-slate-300">
              <div class="flex justify-between">
                <span class="text-slate-400">Total Transactions:</span>
                <span class="font-bold text-white font-mono">${count.toLocaleString()}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Blocked / High-Risk:</span>
                <span class="font-bold text-rose-400 font-mono">${cluster.blockedCount.toLocaleString()}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Under Review:</span>
                <span class="font-bold text-amber-400 font-mono">${cluster.reviewCount.toLocaleString()}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Total Volume:</span>
                <span class="font-mono text-slate-200 font-medium">$${cluster.totalAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              </div>
              ${
                cluster.suspiciousAmount > 0
                  ? `<div class="flex justify-between">
                      <span class="text-rose-400 font-medium">Suspicious Volume:</span>
                      <span class="font-bold text-rose-400 font-mono">$${cluster.suspiciousAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>`
                  : ""
              }
            </div>

            ${
              cluster.sampleAlertReason
                ? `<div class="mt-2.5 p-2 rounded bg-slate-800/80 border border-slate-700/50 text-[11px] text-slate-300 leading-tight">
                    <strong class="text-cyan-300">Key Pattern:</strong> ${cluster.sampleAlertReason}
                  </div>`
                : ""
            }
          </div>
        `;

        marker.bindPopup(popupHtml, { maxWidth: 320 });
        markersGroup.addLayer(marker);
        bounds.extend([cluster.lat, cluster.lng]);
      });
    } else {
      // Individual Transaction Markers
      filteredGeoTransactions.forEach((tx) => {
        if (
          typeof tx.latitude !== "number" ||
          typeof tx.longitude !== "number" ||
          isNaN(tx.latitude) ||
          isNaN(tx.longitude)
        ) {
          return;
        }

        const isBlocked = tx.decision === "BLOCKED";
        const isReview = tx.decision === "REVIEW";
        const isSelected = selectedTransaction?.id === tx.id;

        const colorClass = isBlocked
          ? "bg-rose-500 text-white shadow-rose-500/50"
          : isReview
          ? "bg-amber-500 text-slate-950 shadow-amber-500/50"
          : "bg-emerald-500 text-slate-950 shadow-emerald-500/50";

        const iconHtml = `
          <div class="relative flex items-center justify-center cursor-pointer transition-transform hover:scale-125 ${
            isSelected ? "scale-125 ring-4 ring-cyan-400" : ""
          }">
            <div class="w-8 h-8 rounded-full ${colorClass} flex items-center justify-center font-bold text-xs shadow-lg border-2 border-slate-950">
              ${tx.riskScore}
            </div>
            <div class="absolute -bottom-1 w-2 h-2 rotate-45 ${isBlocked ? 'bg-rose-600' : isReview ? 'bg-amber-600' : 'bg-emerald-600'}"></div>
          </div>
        `;

        const customIcon = L.divIcon({
          className: "custom-fraud-marker",
          html: iconHtml,
          iconSize: [32, 32],
          iconAnchor: [16, 16],
          popupAnchor: [0, -18],
        });

        const marker = L.marker([tx.latitude, tx.longitude], { icon: customIcon });

        const popupHtml = `
          <div class="p-3.5 w-72 text-slate-100 font-sans">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <span class="font-mono text-xs text-cyan-400 font-bold">${tx.transactionId}</span>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                isBlocked
                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/40"
                  : isReview
                  ? "bg-amber-500/20 text-amber-400 border border-amber-500/40"
                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
              }">
                ${tx.decision} (${tx.riskScore}/100)
              </span>
            </div>

            <div class="mt-2.5 space-y-1.5 text-xs text-slate-300">
              <div class="flex justify-between">
                <span class="text-slate-400">Amount:</span>
                <span class="font-bold text-white font-mono">${tx.currency} ${tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Location:</span>
                <span class="font-medium text-slate-200">${tx.city || "Unknown City"}, ${tx.country || ""}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">User ID:</span>
                <span class="font-mono text-slate-300">${tx.userId}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Timestamp:</span>
                <span>${tx.formattedDate}</span>
              </div>
            </div>

            <div class="mt-2.5 p-2 rounded bg-slate-800/80 border border-slate-700/50 text-[11px] text-slate-300 leading-tight">
              <strong class="text-cyan-300">Detection Reason:</strong> ${tx.primaryReason}
            </div>

            <div class="mt-3 flex gap-1.5">
              <button id="btn-select-${tx.id}" class="w-full py-1.5 px-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-semibold flex items-center justify-center gap-1 transition-colors">
                Inspect Forensic Details
              </button>
            </div>
          </div>
        `;

        marker.bindPopup(popupHtml, { maxWidth: 320 });

        marker.on("popupopen", () => {
          const btn = document.getElementById(`btn-select-${tx.id}`);
          if (btn) {
            btn.onclick = () => {
              onSelectTransaction(tx);
              if (onInvestigateTransaction) {
                onInvestigateTransaction(tx);
              }
            };
          }
        });

        marker.on("click", () => {
          onSelectTransaction(tx);
        });

        markersGroup.addLayer(marker);
        bounds.extend([tx.latitude, tx.longitude]);
      });
    }

    if (bounds.isValid() && !selectedTransaction) {
      try {
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 5 });
      } catch (err) {
        console.warn("Could not fit map bounds:", err);
      }
    }
  }, [hasClusters, filteredClusters, filteredGeoTransactions, travelVectors, showFlightPaths, selectedTransaction]);

  // Pan to selected transaction if active
  useEffect(() => {
    if (
      selectedTransaction &&
      typeof selectedTransaction.latitude === "number" &&
      typeof selectedTransaction.longitude === "number" &&
      !isNaN(selectedTransaction.latitude) &&
      !isNaN(selectedTransaction.longitude) &&
      mapInstanceRef.current
    ) {
      try {
        mapInstanceRef.current.flyTo(
          [selectedTransaction.latitude, selectedTransaction.longitude],
          7,
          { duration: 1.2 }
        );
      } catch (err) {
        console.warn("Could not fly to coordinates:", err);
      }
    }
  }, [selectedTransaction]);

  return (
    <div className="relative w-full h-[520px] rounded-2xl overflow-hidden border border-slate-800/80 bg-[#070b16] flex flex-col shadow-2xl">
      {/* Top Map HUD Controls & Telemetry */}
      <div className="absolute top-3 left-3 right-3 z-[400] flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        {/* Live Indicator Badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0f172a]/95 backdrop-blur-md border border-slate-800/80 shadow-lg pointer-events-auto">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
            </span>
            <span className="font-bold text-xs tracking-wider text-cyan-300 uppercase flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              GLOBAL FRAUD MAP
            </span>
          </div>
          <span className="text-slate-600 text-xs">|</span>
          <div className="flex items-center gap-1 text-[11px] text-slate-300">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>Updated: <strong className="text-emerald-400 font-mono">{lastUpdatedTime}</strong></span>
          </div>
        </div>

        {/* Filter Badges & View Options */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#0f172a]/95 backdrop-blur-md border border-slate-800/80 shadow-lg pointer-events-auto text-xs">
          <button
            onClick={() => setRiskFilter("ALL")}
            className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
              riskFilter === "ALL"
                ? "bg-slate-700 text-white shadow-sm font-semibold"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            All Locations ({totalGeoPoints})
          </button>
          <button
            onClick={() => setRiskFilter("BLOCKED")}
            className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              riskFilter === "BLOCKED"
                ? "bg-rose-500 text-white shadow-sm shadow-rose-500/20 font-bold"
                : "text-rose-400 hover:text-rose-300"
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-rose-500"></span>
            High Risk ({highRiskCount.toLocaleString()})
          </button>
          <button
            onClick={() => setRiskFilter("REVIEW")}
            className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              riskFilter === "REVIEW"
                ? "bg-amber-500 text-slate-950 font-bold shadow-sm shadow-amber-500/20"
                : "text-amber-400 hover:text-amber-300"
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            Review ({reviewCount.toLocaleString()})
          </button>
          {travelVectors.length > 0 && (
            <button
              onClick={() => setRiskFilter("TRAVEL")}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
                riskFilter === "TRAVEL"
                  ? "bg-cyan-500 text-slate-950 font-bold shadow-sm shadow-cyan-500/20"
                  : "text-cyan-400 hover:text-cyan-300"
              }`}
            >
              <PlaneTakeoff className="w-3.5 h-3.5" />
              Velocity Paths ({travelVectors.length})
            </button>
          )}
        </div>
      </div>

      {/* Map DOM Element */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Fallback overlay when dataset has no coordinates */}
      {totalGeoPoints === 0 && (
        <div className="absolute inset-0 z-[300] bg-[#070b16]/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#0f172a] border border-slate-800 flex items-center justify-center text-slate-500 mb-3 shadow-inner">
            <MapPin className="w-8 h-8 text-amber-400 animate-bounce" />
          </div>
          <h3 className="text-lg font-bold text-slate-100 mb-1">
            Location data unavailable for this dataset.
          </h3>
          <p className="text-xs text-slate-400 max-w-md mb-4 leading-relaxed">
            {totalAnalyzedCount > 0
              ? `All ${totalAnalyzedCount.toLocaleString()} rows were successfully analyzed across Behavioral, Identity, Device, and Rule stages without GPS coordinates.`
              : "No location columns (city, country, or latitude/longitude) were detected in the uploaded records."}
          </p>
          <div className="px-3 py-1.5 rounded-lg bg-[#0f172a] border border-slate-800 text-xs text-slate-300">
            Mandate Enforced: <span className="text-emerald-400 font-mono">Zero synthetic fake locations generated.</span>
          </div>
        </div>
      )}

      {/* Bottom Map Legend */}
      <div className="absolute bottom-3 left-3 z-[400] flex items-center gap-3 px-3 py-1.5 rounded-xl bg-[#0f172a]/95 backdrop-blur-md border border-slate-800/80 text-[11px] text-slate-300 shadow-lg">
        <span className="font-semibold text-slate-400">Risk Legend:</span>
        <span className="flex items-center gap-1.5 text-rose-400 font-medium">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block shadow-sm shadow-rose-500/50"></span> High Risk (≥75)
        </span>
        <span className="flex items-center gap-1.5 text-amber-400 font-medium">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block shadow-sm shadow-amber-500/50"></span> Review (40-74)
        </span>
        <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block shadow-sm shadow-emerald-500/50"></span> Low Risk (&lt;40)
        </span>
      </div>

      {/* Bottom Right Layer Toggle */}
      <div className="absolute bottom-3 right-3 z-[400] flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0f172a]/95 backdrop-blur-md border border-slate-800/80 text-[11px] text-slate-300 shadow-lg">
        <label className="flex items-center gap-1.5 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={showFlightPaths}
            onChange={(e) => setShowFlightPaths(e.target.checked)}
            className="rounded border-slate-700 bg-[#070b16] text-cyan-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
          />
          <span>Show Velocity Travel Arcs</span>
        </label>
      </div>
    </div>
  );
};
