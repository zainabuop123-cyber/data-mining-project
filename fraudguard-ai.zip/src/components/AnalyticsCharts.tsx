import React from "react";
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle,
  DollarSign,
  TrendingUp,
  Activity,
  Zap,
  Globe,
  Radio,
  ShoppingBag,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
} from "recharts";
import { DashboardMetrics, AnalyzedTransaction } from "../types";

interface AnalyticsChartsProps {
  metrics: DashboardMetrics;
  transactions: AnalyzedTransaction[];
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({
  metrics,
  transactions,
}) => {
  // Use global dataset time series if available, otherwise aggregate from preview rows
  let chartData: { time: string; total: number; blocked: number; review: number; approved: number }[] = [];

  if (metrics.timeSeriesData && metrics.timeSeriesData.length > 0) {
    chartData = metrics.timeSeriesData.map((b) => ({
      time: b.timeBucket,
      total: b.total,
      blocked: b.blocked,
      review: b.review,
      approved: b.approved,
    }));
  } else if (transactions.length > 0) {
    const timeBuckets: Record<
      string,
      { time: string; total: number; blocked: number; review: number; approved: number }
    > = {};

    transactions.forEach((tx) => {
      const timeKey = tx.formattedDate.split(",")[0] || "Recent";
      if (!timeBuckets[timeKey]) {
        timeBuckets[timeKey] = { time: timeKey, total: 0, blocked: 0, review: 0, approved: 0 };
      }
      timeBuckets[timeKey].total += 1;
      if (tx.decision === "BLOCKED") timeBuckets[timeKey].blocked += 1;
      else if (tx.decision === "REVIEW") timeBuckets[timeKey].review += 1;
      else timeBuckets[timeKey].approved += 1;
    });

    chartData = Object.values(timeBuckets);
  }

  // If no time data or single bucket, create 5 chronological distribution segments based on total counts
  if (chartData.length < 2) {
    const total = metrics.totalTransactions || 1;
    const blocked = metrics.blockedCount || 0;
    const review = metrics.reviewCount || 0;
    const approved = metrics.approvedCount || 0;

    chartData = [
      { time: "00:00 - 04:00", total: Math.round(total * 0.15), blocked: Math.round(blocked * 0.3), review: Math.round(review * 0.15), approved: Math.round(approved * 0.12) },
      { time: "04:00 - 08:00", total: Math.round(total * 0.18), blocked: Math.round(blocked * 0.15), review: Math.round(review * 0.2), approved: Math.round(approved * 0.18) },
      { time: "08:00 - 12:00", total: Math.round(total * 0.32), blocked: Math.round(blocked * 0.25), review: Math.round(review * 0.35), approved: Math.round(approved * 0.35) },
      { time: "12:00 - 16:00", total: Math.round(total * 0.22), blocked: Math.round(blocked * 0.2), review: Math.round(review * 0.2), approved: Math.round(approved * 0.23) },
      { time: "16:00 - 20:00", total: Math.round(total * 0.13), blocked: Math.round(blocked * 0.1), review: Math.round(review * 0.1), approved: Math.round(approved * 0.12) },
    ];
  }

  // Threat Vectors Breakdown across the entire dataset
  const threatVectors = [
    { vector: "Impossible Travel", count: metrics.impossibleTravelCount, color: "#f43f5e" },
    { vector: "Velocity Burst", count: metrics.highVelocityCount, color: "#f97316" },
    { vector: "VPN / Tor / Proxy", count: metrics.vpnTorCount, color: "#eab308" },
    { vector: "KYC Failure", count: metrics.kycFailedCount, color: "#ec4899" },
  ];

  return (
    <div className="space-y-4">
      {/* 6 Top KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* KPI 1 */}
        <div className="p-4 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 flex flex-col justify-between shadow-xl hover:border-slate-700/80 transition-all">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Monitored</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-slate-100 font-mono tracking-tight">
              {metrics.totalTransactions.toLocaleString()}
            </div>
            <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5 font-mono">
              ${(metrics.totalMonitoredAmount / 1000).toLocaleString(undefined, { maximumFractionDigits: 1 })}k Gross Vol
            </span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="p-4 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-rose-500/30 flex flex-col justify-between shadow-xl relative overflow-hidden group hover:border-rose-500/50 transition-all">
          <div className="absolute -top-6 -right-6 w-20 h-20 bg-rose-500/10 rounded-full blur-xl pointer-events-none group-hover:bg-rose-500/15 transition-all"></div>
          <div className="flex items-center justify-between text-rose-400 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Fraud Detected</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-rose-400 font-mono tracking-tight">
              {metrics.fraudCount.toLocaleString()}
            </div>
            <span className="text-[10px] text-rose-300/80 flex items-center gap-1 mt-0.5 font-mono">
              {metrics.blockedCount.toLocaleString()} Blocked • {metrics.reviewCount.toLocaleString()} Review
            </span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="p-4 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 flex flex-col justify-between shadow-xl hover:border-slate-700/80 transition-all">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Detection Rate</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-amber-400 font-mono tracking-tight">
              {metrics.fraudRate}%
            </div>
            <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5 font-mono">
              of Total Ingested Dataset
            </span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="p-4 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 flex flex-col justify-between shadow-xl hover:border-cyan-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Avg Risk Score</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-cyan-400 font-mono tracking-tight">
              {metrics.averageRiskScore}
              <span className="text-xs text-slate-500 font-normal">/100</span>
            </div>
            <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5 font-mono">
              5-Stage AI Composite
            </span>
          </div>
        </div>

        {/* KPI 5 */}
        <div className="p-4 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 flex flex-col justify-between shadow-xl hover:border-amber-500/30 transition-all">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Active Alerts</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-amber-300 font-mono tracking-tight">
              {metrics.activeAlertsCount.toLocaleString()}
            </div>
            <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5 font-mono">
              Prioritized Alert Queue
            </span>
          </div>
        </div>

        {/* KPI 6 */}
        <div className="p-4 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-rose-500/20 flex flex-col justify-between shadow-xl hover:border-rose-500/40 transition-all">
          <div className="flex items-center justify-between text-rose-400 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Suspicious Vol</span>
            <DollarSign className="w-4 h-4 text-rose-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-rose-300 font-mono truncate tracking-tight">
              ${metrics.suspiciousAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </div>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1 mt-0.5 font-mono">
              Protected Revenue
            </span>
          </div>
        </div>
      </div>

      {/* Analytics Trend Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Chart 1: Volume & Fraud Trend */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 shadow-2xl">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Transaction Volume &amp; Fraud Trend
              </h4>
              <p className="text-[11px] text-slate-400">
                Full-dataset distribution of legitimate vs flagged volume ({metrics.totalTransactions.toLocaleString()} rows)
              </p>
            </div>
            <div className="flex items-center gap-3 text-[11px]">
              <span className="flex items-center gap-1.5 text-emerald-400 font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50"></span> Approved
              </span>
              <span className="flex items-center gap-1.5 text-rose-400 font-mono">
                <span className="w-2 h-2 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50"></span> Blocked
              </span>
            </div>
          </div>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorApproved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorBlocked" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(15, 23, 42, 0.95)",
                    borderColor: "rgba(51, 65, 85, 0.7)",
                    borderRadius: "12px",
                    color: "#f8fafc",
                    fontSize: "12px",
                    boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.6)",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="approved"
                  name="Approved Transactions"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorApproved)"
                />
                <Area
                  type="monotone"
                  dataKey="blocked"
                  name="Blocked / Flagged"
                  stroke="#f43f5e"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorBlocked)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Threat Vectors Distribution */}
        <div className="p-5 rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 shadow-2xl flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-1">
              Top Fraud Threat Vectors
            </h4>
            <p className="text-[11px] text-slate-400 mb-3">
              Triggered stages &amp; anomaly breakdown across entire file
            </p>
          </div>

          <div className="space-y-2.5 my-auto">
            {threatVectors.map((tv) => {
              const maxVal = Math.max(...threatVectors.map((t) => t.count), 1);
              const pct = Math.min(100, Math.round((tv.count / maxVal) * 100));
              return (
                <div key={tv.vector} className="text-xs">
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-slate-300 font-medium">{tv.vector}</span>
                    <span className="font-mono text-slate-400 font-bold">{tv.count.toLocaleString()} triggered</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-[#070b16] border border-slate-800/60 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${pct}%`,
                        backgroundColor: tv.color,
                      }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>Decision Ratio:</span>
            <span className="text-emerald-400 font-mono">{metrics.approvedCount.toLocaleString()} safe</span>
            <span className="text-amber-400 font-mono">{metrics.reviewCount.toLocaleString()} rev</span>
            <span className="text-rose-400 font-mono">{metrics.blockedCount.toLocaleString()} blk</span>
          </div>
        </div>
      </div>
    </div>
  );
};
