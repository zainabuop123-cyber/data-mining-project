import React, { useState } from "react";
import {
  ShieldAlert,
  AlertTriangle,
  MapPin,
  Sparkles,
  ExternalLink,
  Filter,
  Search,
  CheckCircle,
  Eye,
  PlaneTakeoff,
  Smartphone,
  UserX,
  Zap,
} from "lucide-react";
import { AnalyzedTransaction } from "../types";

interface LiveAlertsPanelProps {
  transactions: AnalyzedTransaction[];
  selectedTransaction: AnalyzedTransaction | null;
  onSelectTransaction: (tx: AnalyzedTransaction) => void;
  onInvestigateTransaction: (tx: AnalyzedTransaction) => void;
}

export const LiveAlertsPanel: React.FC<LiveAlertsPanelProps> = ({
  transactions,
  selectedTransaction,
  onSelectTransaction,
  onInvestigateTransaction,
}) => {
  const [filterType, setFilterType] = useState<"ALL" | "BLOCKED" | "REVIEW" | "TRAVEL">("ALL");
  const [searchQuery, setSearchQuery] = useState("");

  const alerts = transactions.filter((t) => t.decision !== "APPROVED");

  const filteredAlerts = alerts.filter((t) => {
    if (filterType === "BLOCKED" && t.decision !== "BLOCKED") return false;
    if (filterType === "REVIEW" && t.decision !== "REVIEW") return false;
    if (filterType === "TRAVEL" && (!t.travelSpeedKmH || t.travelSpeedKmH <= 400)) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.transactionId.toLowerCase().includes(q) ||
        t.userId.toLowerCase().includes(q) ||
        (t.city && t.city.toLowerCase().includes(q)) ||
        (t.country && t.country.toLowerCase().includes(q)) ||
        t.primaryReason.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="h-full flex flex-col rounded-2xl bg-[#0f172a]/90 backdrop-blur-md border border-slate-800/80 shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-800/80 bg-[#0f172a]/95">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 shadow-sm shadow-rose-500/10">
              <ShieldAlert className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                Live Fraud Alerts
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-rose-500/10 text-rose-400 border border-rose-500/30 font-bold">
                  {alerts.length} Active
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">Real-time risk scoring triage feed</p>
            </div>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="space-y-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search TX ID, user, city, or reason..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-[#070b16] border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all"
            />
          </div>

          <div className="flex items-center gap-1 text-[10px]">
            <button
              onClick={() => setFilterType("ALL")}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                filterType === "ALL"
                  ? "bg-slate-700 text-white shadow-sm"
                  : "text-slate-400 hover:text-slate-200 bg-[#070b16] border border-slate-800/80"
              }`}
            >
              All Alerts ({alerts.length})
            </button>
            <button
              onClick={() => setFilterType("BLOCKED")}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1 ${
                filterType === "BLOCKED"
                  ? "bg-rose-500 text-white shadow-sm shadow-rose-500/20 font-bold"
                  : "text-rose-400 hover:text-rose-300 bg-[#070b16] border border-slate-800/80"
              }`}
            >
              Blocked ({alerts.filter((t) => t.decision === "BLOCKED").length})
            </button>
            <button
              onClick={() => setFilterType("REVIEW")}
              className={`px-2.5 py-1 rounded-lg font-medium transition-all flex items-center gap-1 ${
                filterType === "REVIEW"
                  ? "bg-amber-500 text-slate-950 font-bold shadow-sm shadow-amber-500/20"
                  : "text-amber-400 hover:text-amber-300 bg-[#070b16] border border-slate-800/80"
              }`}
            >
              Review ({alerts.filter((t) => t.decision === "REVIEW").length})
            </button>
          </div>
        </div>
      </div>

      {/* Alerts Stream List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
        {filteredAlerts.length === 0 ? (
          <div className="text-center py-12 px-4">
            <div className="w-12 h-12 rounded-full bg-[#070b16] border border-slate-800 flex items-center justify-center text-slate-500 mx-auto mb-2">
              <CheckCircle className="w-6 h-6 text-emerald-400" />
            </div>
            <p className="text-xs font-semibold text-slate-300">No active alerts matching filter</p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              All monitored transactions within normal parameters.
            </p>
          </div>
        ) : (
          filteredAlerts.map((tx) => {
            const isBlocked = tx.decision === "BLOCKED";
            const isSelected = selectedTransaction?.id === tx.id;

            return (
              <div
                key={tx.id}
                onClick={() => onSelectTransaction(tx)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? "bg-[#0f172a] border-cyan-500 ring-1 ring-cyan-400/50 shadow-lg shadow-cyan-500/10"
                    : isBlocked
                    ? "bg-[#070b16]/90 border-rose-500/30 hover:border-rose-500/60 shadow-sm"
                    : "bg-[#070b16]/90 border-amber-500/30 hover:border-amber-500/60 shadow-sm"
                }`}
              >
                {/* Alert Top Row */}
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isBlocked ? "bg-rose-500 animate-ping" : "bg-amber-500"
                      }`}
                    ></span>
                    <span className="font-mono font-bold text-xs text-cyan-300">
                      {tx.transactionId}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">({tx.userId})</span>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      isBlocked
                        ? "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                        : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                    }`}
                  >
                    {tx.decision} ({tx.riskScore}/100)
                  </span>
                </div>

                {/* Amount & Location */}
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-white font-mono">
                    {tx.currency} {tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-cyan-400" />
                    {tx.city ? `${tx.city}, ${tx.country || ""}` : "No geo telemetry"}
                  </span>
                </div>

                {/* Triggered Stage Pills */}
                {tx.triggeredChecks.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {tx.triggeredChecks.map((check) => (
                      <span
                        key={check}
                        className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-[#0f172a] text-slate-300 border border-slate-700/80"
                      >
                        {check}
                      </span>
                    ))}
                    {tx.travelSpeedKmH && tx.travelSpeedKmH > 400 && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-rose-500/10 text-rose-300 border border-rose-500/30 flex items-center gap-1 font-bold">
                        <PlaneTakeoff className="w-2.5 h-2.5 text-rose-400" />
                        {tx.travelSpeedKmH} km/h
                      </span>
                    )}
                  </div>
                )}

                {/* Detection Reason */}
                <p className="text-[11px] text-slate-300 line-clamp-2 leading-tight bg-[#0f172a]/70 p-2 rounded-lg border border-slate-800/80 mb-2">
                  {tx.primaryReason}
                </p>

                {/* Action Buttons */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[10px]">
                  <span className="text-slate-500 font-mono">{tx.formattedDate}</span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectTransaction(tx);
                      onInvestigateTransaction(tx);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    AI Forensic Drilldown
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
