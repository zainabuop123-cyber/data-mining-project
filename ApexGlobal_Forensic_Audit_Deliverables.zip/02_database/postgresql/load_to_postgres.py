"""
ApexGlobal Logistics — Python Data Pipeline
Loads the 7 raw CSVs into a PostgreSQL database matching schema_postgres.sql.

Usage:
    1. Set your connection details below (or via env vars).
    2. Run: python load_to_postgres.py

Requires: pandas, sqlalchemy, psycopg2-binary
    pip install pandas sqlalchemy psycopg2-binary
"""

import os
import pandas as pd
from sqlalchemy import create_engine, text

# ------------------------------------------------------------
# Connection settings — edit these or set as env vars
# ------------------------------------------------------------
PG_HOST = os.environ.get("PGHOST", "localhost")
PG_PORT = os.environ.get("PGPORT", "5432")
PG_DB   = os.environ.get("PGDATABASE", "apexglobal")
PG_USER = os.environ.get("PGUSER", "postgres")
PG_PASS = os.environ.get("PGPASSWORD", "postgres")

# Folder containing the raw CSVs (ShipmentID-style headers)
CSV_DIR = os.environ.get("CSV_DIR", "./data")

SCHEMA_SQL_PATH = "schema_postgres.sql"

engine = create_engine(
    f"postgresql+psycopg2://{PG_USER}:{PG_PASS}@{PG_HOST}:{PG_PORT}/{PG_DB}"
)


def apply_schema():
    """Run the DDL file to (re)create all tables and indexes."""
    with open(SCHEMA_SQL_PATH) as f:
        ddl = f.read()
    with engine.begin() as conn:
        conn.execute(text(ddl))
    print("Schema applied.")


def load_csv(filename, table, transform=None):
    """Read a raw CSV, lowercase its columns, optionally transform it, then load it."""
    path = os.path.join(CSV_DIR, filename)
    df = pd.read_csv(path)
    df.columns = [c.lower() for c in df.columns]
    if transform is not None:
        df = transform(df)
    df.to_sql(table, engine, if_exists="append", index=False, method="multi", chunksize=5000)
    print(f"Loaded {len(df):,} rows into {table}")


def transform_shipments(df):
    # istransshipment arrives as 'Yes'/'No' text -> cast to boolean
    df["istransshipment"] = df["istransshipment"].map({"Yes": True, "No": False})
    return df


def main():
    apply_schema()

    # Load in FK-safe order: reference tables first, then dependents.
    load_csv("ports.csv", "ports")
    load_csv("carriers.csv", "carriers")
    load_csv("tariffs_customs.csv", "tariffs_customs")
    load_csv("shipments.csv", "shipments", transform=transform_shipments)
    load_csv("shipment_legs.csv", "shipment_legs")
    load_csv("carbon_logs.csv", "carbon_logs")
    load_csv("telemetry.csv", "telemetry")

    # Quick integrity check
    with engine.connect() as conn:
        for tbl in ["ports", "carriers", "tariffs_customs", "shipments",
                    "shipment_legs", "carbon_logs", "telemetry"]:
            n = conn.execute(text(f"SELECT COUNT(*) FROM {tbl}")).scalar()
            print(f"  {tbl}: {n:,} rows")

    print("\nDone. Database is ready — run forensic_views_postgres.sql next.")


if __name__ == "__main__":
    main()
