-- ============================================================
-- ApexGlobal Logistics — Forensic Audit Views
-- PostgreSQL
--
-- Existing analytical views:
--   1. shipment_journey
--   2. telemetry_audit
--   3. tariff_evasion_analysis
--
-- Purpose:
--   These views support the three B1 forensic audit challenges:
--   Challenge 1: Journey Resolution
--   Challenge 2: Telemetry Audit
--   Challenge 3: Tariff Evasion Analysis
--
-- IMPORTANT:
--   The three main views have already been created.
--   This file does NOT recreate or delete them.
-- ============================================================


-- ============================================================
-- VIEW 1 — JOURNEY RESOLUTION
-- ============================================================
--
-- Purpose:
--   Provides the resolved shipment journey by combining
--   shipment, leg, port and carrier information.
--
-- Main forensic questions:
--   • Which ports did the shipment travel through?
--   • How many legs did the shipment have?
--   • Which carrier handled each leg?
--   • Which transport mode was used?
-- ============================================================

SELECT *
FROM shipment_journey
LIMIT 20;


-- ============================================================
-- JOURNEY SUMMARY
-- ============================================================
--
-- Provides a shipment-level summary of journey records.
-- ============================================================

SELECT
    shipmentid,
    COUNT(*) AS total_legs
FROM shipment_journey
GROUP BY shipmentid
ORDER BY total_legs DESC;


-- ============================================================
-- VIEW 2 — TELEMETRY AUDIT
-- ============================================================
--
-- Existing view columns:
--
--   shipmentid
--   total_pings
--   avg_temperature
--   max_temperature
--   failed_pings
--
-- Main forensic questions:
--   • How many telemetry pings were recorded?
--   • What was the average temperature?
--   • What was the maximum temperature?
--   • How many pings failed?
-- ============================================================

SELECT
    shipmentid,
    total_pings,
    avg_temperature,
    max_temperature,
    failed_pings
FROM telemetry_audit
ORDER BY failed_pings DESC;


-- ============================================================
-- TELEMETRY — FAILED PING INVESTIGATION
-- ============================================================
--
-- Identifies shipments that experienced failed telemetry pings.
-- ============================================================

SELECT
    shipmentid,
    total_pings,
    failed_pings,
    avg_temperature,
    max_temperature
FROM telemetry_audit
WHERE failed_pings > 0
ORDER BY failed_pings DESC;


-- ============================================================
-- TELEMETRY — HIGHEST TEMPERATURE INVESTIGATION
-- ============================================================
--
-- Ranks shipments by maximum recorded temperature.
-- This identifies shipments requiring further investigation.
--
-- NOTE:
--   A high temperature is NOT automatically a breach.
--   It must be compared with the applicable cargo/storage
--   temperature requirement.
-- ============================================================

SELECT
    shipmentid,
    total_pings,
    avg_temperature,
    max_temperature,
    failed_pings
FROM telemetry_audit
WHERE max_temperature IS NOT NULL
ORDER BY max_temperature DESC;


-- ============================================================
-- TELEMETRY — OVERALL AUDIT SUMMARY
-- ============================================================

SELECT
    COUNT(*) AS total_shipments_audited,
    SUM(total_pings) AS total_pings,
    SUM(failed_pings) AS total_failed_pings,
    ROUND(AVG(avg_temperature), 2) AS overall_avg_temperature,
    MAX(max_temperature) AS highest_temperature
FROM telemetry_audit;


-- ============================================================
-- VIEW 3 — TARIFF EVASION ANALYSIS
-- ============================================================
--
-- Existing analytical view for Challenge 3.
--
-- Main forensic questions:
--   • Which HS codes were declared?
--   • What origin/destination information was declared?
--   • What tariff should have applied?
--   • Was customs payment consistent?
--   • Which shipments require investigation?
-- ============================================================

SELECT *
FROM tariff_evasion_analysis
LIMIT 20;


-- ============================================================
-- TARIFF — RECORD COUNT
-- ============================================================

SELECT
    COUNT(*) AS total_tariff_analysis_records
FROM tariff_evasion_analysis;


-- ============================================================
-- TARIFF — INVESTIGATION
-- ============================================================
--
-- IMPORTANT:
--   The exact filtering column depends on the columns in your
--   existing tariff_evasion_analysis view.
--
--   First inspect the columns using:
--
--   SELECT column_name
--   FROM information_schema.columns
--   WHERE table_name = 'tariff_evasion_analysis'
--   ORDER BY ordinal_position;
--
-- ============================================================


-- ============================================================
-- FINAL FORENSIC SUMMARY
-- ============================================================
--
-- Provides high-level counts from all three existing views.
-- ============================================================

SELECT
    (SELECT COUNT(*)
     FROM shipment_journey) AS journey_records,

    (SELECT COUNT(*)
     FROM telemetry_audit) AS telemetry_records,

    (SELECT COUNT(*)
     FROM tariff_evasion_analysis) AS tariff_records;
